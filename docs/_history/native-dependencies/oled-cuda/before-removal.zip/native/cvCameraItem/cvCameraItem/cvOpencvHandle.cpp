#include "stdafx.h"
#include "cvOpencvHandle.h"
#include <opencv2/opencv.hpp>
#include "cvCommonUtil.h"
#include "OpencvManager.h"
#include "ROIDetectManage.h"
#include "CMStruct.h"
#include "DataAnalyzer.h"
#include "LiuBing.hpp"
#include "json/json.h"
#include "CMMatch.h"
#include "BinocularFusion.h"
// #include "glog/logging.h"
// #include "ds_region.h"

extern bool gIsOpen;

#define MYDLL _declspec(dllexport)
#define EXPORTC extern "C"
#define STDCALL __stdcall

using namespace OpencvManager;
using namespace std;
BrightAreaParam m_tBrightAreaParam;
CROIDetectManage m_RoiMan;

EXPORTC MYDLL bool STDCALL GetMapTransformation(DPOINT* pMapSrc, DPOINT* pMapDst, DPOINT& TransIPOINT)
{
	std::vector<cv::Point2f> srcPoints;
	std::vector<cv::Point2f> dstPoints;

	for (int i = 0; i < 4; i++)
	{
		srcPoints.push_back(cv::Point2f((float)pMapSrc[i].x, (float)pMapSrc[i].y));
		dstPoints.push_back(cv::Point2f((float)pMapDst[i].x, (float)pMapDst[i].y));
	}

	cv::Mat mappingMatrix = cv::findHomography(srcPoints, dstPoints);

	cv::Point3d transformedCorner = cv::Point3d(cv::Mat(mappingMatrix * cv::Mat(cv::Point3d(TransIPOINT.x, TransIPOINT.y, 1.0))));
	cv::Point2f dataPoint = cv::Point2f(float(transformedCorner.x / transformedCorner.z), float(transformedCorner.y / transformedCorner.z));
	TransIPOINT.x = dataPoint.x;
	TransIPOINT.y = dataPoint.y;

	return true;
}

EXPORTC MYDLL bool STDCALL GetMapTransformationEx(DPOINT* pMapSrc, DPOINT* pMapDst, DPOINT* TransIPOINT, float* PointX, float* PointY, int nCount)
{
	std::vector<cv::Point2f> srcPoints;
	std::vector<cv::Point2f> dstPoints;

	for (int i = 0; i < 4; i++)
	{
		srcPoints.push_back(cv::Point2f((float)pMapSrc[i].x, (float)pMapSrc[i].y));
		dstPoints.push_back(cv::Point2f((float)pMapDst[i].x, (float)pMapDst[i].y));
	}

	cv::Mat mappingMatrix = cv::findHomography(srcPoints, dstPoints);

	for (int i = 0; i < nCount; i++)
	{
		cv::Point3d transformedCorner = cv::Point3d(cv::Mat(mappingMatrix * cv::Mat(cv::Point3d(TransIPOINT[i].x, TransIPOINT[i].y, 1.0))));
		cv::Point2f dataPoint = cv::Point2f(transformedCorner.x / transformedCorner.z, transformedCorner.y / transformedCorner.z);
		PointX[i] = dataPoint.x;
		PointY[i] = dataPoint.y;
	}

	return true;
}

EXPORTC MYDLL BOOL STDCALL SetBrightAreaParam(BrightAreaParam tBrightAreaParam)
{
	m_tBrightAreaParam = tBrightAreaParam;
	return TRUE;
}

std::vector<std::vector<cv::Point>> contours;

vector<RotatedRect> gvecRect;

EXPORTC MYDLL int STDCALL FindBrightArea(uint32_t w, uint32_t h, uint32_t bpp, uint32_t channels, uint8_t* imgdata)
{
	gvecRect.clear();

	BrightAreaParam tBrightAreaParam = m_tBrightAreaParam;

	int ntype = Gettype(bpp, channels);

	cv::Mat img = cv::Mat(h, w, ntype, imgdata);

	cv::Mat dst;

	dst = MatToCImage(img);							// ��������8λ�����ܶ���λ��ȥ

	if (channels == 3)
	{
		cv::Mat imgArr[3];
		split(dst, imgArr);							// ���ͨ��
		BOOL res = pickHighSaturationImage(imgArr, dst, 3);	// ɸѡ�����Ͷ���ߵ�,������������Ƿ�ʹ��
		if (res != CV_ERR_SUCCESS) {
			return res;
		}
	}

	if (tBrightAreaParam.bRoi)
	{
		int x = tBrightAreaParam.nleft;
		int y = tBrightAreaParam.ntop;

		int nWid = tBrightAreaParam.nright - tBrightAreaParam.nleft;
		int nHei = tBrightAreaParam.nbottom - tBrightAreaParam.ntop;

		if (nWid <= 0 || nHei <= 0 || x < 0 || x + nWid >= w || y < 0 || y + nHei > h)
		{
			LOGFMTW("ROI of crossing the line x: %d, y : %d, w: %d h : %d", x, y, nHei, nWid);
			return 0;
		}

		dst = dst(Rect(x, y, nWid, nHei)).clone();
	}
	if (tBrightAreaParam.bBlur)
	{
		blur(dst, dst, Size(tBrightAreaParam.nblur_size, tBrightAreaParam.nblur_size));
	}

	if (tBrightAreaParam.bDilate)
	{
		Dilate(dst, tBrightAreaParam.ndilate_size);
	}

	if (tBrightAreaParam.bErode)
	{
		Erode(dst, tBrightAreaParam.nerode_size);
	}

	if (tBrightAreaParam.bBinarize)
	{
		binarize(dst, tBrightAreaParam.nBinarizeThresh);
	}

	contours.clear();

	findContours(dst, contours, RETR_EXTERNAL, CHAIN_APPROX_NONE);

	imwrite("dst.tif", dst);

	if (contours.size() == 0)
	{
		LOGI("δ�ҵ�������");

		return 0;
	}

	for (int i = 0; i < contours.size(); i++)
	{
		if (tBrightAreaParam.bFilterArea)
		{
			double area = contourArea(contours[i]);

			if (area > tBrightAreaParam.nMax_area ||
				area < tBrightAreaParam.nMin_area)
			{
				continue;
			}
		}

		RotatedRect RotRect;

		RotRect = minAreaRect(contours[i]);

		if (tBrightAreaParam.bFilterRect)
		{
			if (RotRect.size.width < tBrightAreaParam.Widht ||
				RotRect.size.height < tBrightAreaParam.Height)
			{
				continue;
			}
		}

		gvecRect.push_back(RotRect);
	}

	LOGFMTI("����������%zd", gvecRect.size());

	return (int)gvecRect.size();
}

EXPORTC MYDLL BOOL STDCALL GetBrightArea(int nIndex, int* pnPointx, int* pnPointy)
{
	if (nIndex >= gvecRect.size())
	{
		LOGFMTI("����������%zd, ���%d �����������������ʷ�Χ", gvecRect.size(), nIndex);
		return false;
	}

	RotatedRect RotRect = gvecRect[nIndex];

	cv::Point2f vertex[4];
	RotRect.points(vertex);

	for (int i = 0; i < 4; i++)
	{
		pnPointx[i] = vertex[i].x;
		pnPointy[i] = vertex[i].y;
	}

	return true;
}

EXPORTC MYDLL HANDLE STDCALL CreateAOIDetector()
{
	return m_RoiMan.CreateAOIDetector();
}

EXPORTC MYDLL BOOL STDCALL CM_readImage(const char* fileName, HImage& Hi) {
	Mat src = imread(fileName, IMREAD_UNCHANGED);
	if (src.empty())
	{
		return FALSE;
	}
	Hi.iChls = src.channels();
	Hi.iHei = src.rows;
	Hi.iWid = src.cols;
	switch (src.depth())
	{
	case CV_8U:
		Hi.iBpp = 8;
		break;
	case CV_16U:
		Hi.iBpp = 16;
		break;
	case CV_32F:
		Hi.iBpp = 32;
		break;
	default:
		Hi.iBpp = 8;
		break;
	}

	int length = (Hi.iBpp / 8) * Hi.iHei * Hi.iWid * Hi.iChls;
	BYTE* pd = new BYTE[length];
	memcpy(pd, src.data, length);
	if (Hi.pData != nullptr)
	{
		delete[]Hi.pData;
	}
	Hi.pData = pd;
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL CM_releaseImage(HImage& Hi) {
	if (Hi.pData != nullptr)
	{
		delete[]Hi.pData;
		Hi.pData = nullptr;
	}
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL ReleaseAOIDetector(HANDLE handle)
{
	return m_RoiMan.ReleaseAOIDetector(handle);
}

EXPORTC MYDLL BOOL STDCALL AOIDetectorSetParam(HANDLE handle, AoiParam Aoicfg)
{
	AoiCfg cfg;

	cfg.filter_by_area = Aoicfg.filter_by_area;
	cfg.max_area = Aoicfg.max_area;
	cfg.min_area = Aoicfg.min_area;
	cfg.filter_by_contrast = Aoicfg.filter_by_contrast;
	cfg.max_contrast = Aoicfg.max_contrast;
	cfg.min_contrast = Aoicfg.min_contrast;
	cfg.contrast_brightness = Aoicfg.contrast_brightness;
	cfg.contrast_darkness = Aoicfg.contrast_darkness;
	cfg.blur_size = Aoicfg.blur_size;
	cfg.min_contour_size = Aoicfg.min_contour_size;
	cfg.erode_size = Aoicfg.erode_size;
	cfg.dilate_size = Aoicfg.dilate_size;

	cfg.find_roi.x = Aoicfg.left;
	cfg.find_roi.y = Aoicfg.top;
	cfg.find_roi.width = Aoicfg.right - Aoicfg.left;
	cfg.find_roi.height = Aoicfg.bottom - Aoicfg.top;

	LOGFMTD("�������ݵ���filter_by_area:%d", cfg.filter_by_area);
	LOGFMTD("�������ݵ���max_area:%d", cfg.max_area);
	LOGFMTD("�������ݵ���min_area:%d", cfg.min_area);
	LOGFMTD("�������ݵ���filter_by_contrast:%d", cfg.filter_by_contrast);
	LOGFMTD("�������ݵ���max_contrast:%f", cfg.max_contrast);
	LOGFMTD("�������ݵ���min_contrast:%f", cfg.min_contrast);
	LOGFMTD("�������ݵ���contrast_brightness:%f", cfg.contrast_brightness);
	LOGFMTD("�������ݵ���contrast_darkness:%f", cfg.contrast_darkness);
	LOGFMTD("�������ݵ���blur_size:%d", cfg.blur_size);
	LOGFMTD("�������ݵ���min_contour_size:%d", cfg.min_contour_size);
	LOGFMTD("�������ݵ���erode_size:%d", cfg.erode_size);
	LOGFMTD("�������ݵ���dilate_size:%d", cfg.dilate_size);
	LOGFMTD("�������ݵ���find_roi.x:%d", cfg.find_roi.x);
	LOGFMTD("�������ݵ���find_roi.y:%d", cfg.find_roi.y);
	LOGFMTD("�������ݵ���cfg.find_roi.width:%d", cfg.find_roi.width);
	LOGFMTD("�������ݵ���cfg.find_roi.height:%d", cfg.find_roi.height);

	return m_RoiMan.AOIDetectorSetParam(handle, cfg);
}

EXPORTC MYDLL int STDCALL AOIDetectorInput(HANDLE handle, int w, int h, int bpp, int channels, uint8_t* imgdata)
{
	return m_RoiMan.AOIDetectorInput(handle, w, h, bpp, channels, imgdata);
}

EXPORTC MYDLL BOOL STDCALL GetAoiDetectorBlob(HANDLE handle, int nIndex, PartiCle& tParticle)
{
	Particle temParticle;

	BOOL bRet = m_RoiMan.GetAoiDetectorBlob(handle, nIndex, temParticle);

	if (bRet)
	{
		tParticle.contrast = temParticle.contrast;
		tParticle.area = temParticle.area;
		tParticle.color = temParticle.color;
		tParticle.x = temParticle.center.x;
		tParticle.y = temParticle.center.y;
	}

	return bRet;
}

EXPORTC MYDLL BOOL STDCALL ImageRect(int w, int h, int bpp, int channels, uint8_t* imgdata, IRECT tIRECT, uint8_t* imgDstdata)
{
	uint8_t* pSrc;
	uint8_t* pDst;

	uint64_t x = tIRECT.x;
	uint64_t y = tIRECT.y;
	uint64_t nHei = tIRECT.cy;
	uint64_t nWid = tIRECT.cx;

	if (x < 0 || y < 0 || x + nWid >= w || y + nHei >= h)
	{
		LOGFMTI("RECT Խ�� x: %I64d, y : %I64d, w: %I64d h : %I64d", x, y, nHei, nWid);
	}

	uint64_t nSizeMenLenght = (bpp / 8);
	uint64_t nSrcWidthStep = nSizeMenLenght * channels * w;
	uint64_t nDstWidthStep = channels * nWid * nSizeMenLenght;

	pSrc = imgdata + (x + y * w) * channels * nSizeMenLenght;
	pDst = imgDstdata;

	for (int i = 0; i < nHei; ++i)
	{
		memcpy(pDst, pSrc, nDstWidthStep);

		pDst += nDstWidthStep;
		pSrc += nSrcWidthStep;
	}
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL ImageReSize(int w, int h, int bpp, int channels, uint8_t* imgdata, SIZE tsize, uint8_t* imgDstdata)
{
	int nType = Gettype(bpp, channels);

	Mat src(h, w, nType, imgdata);

	Mat dst(tsize.cy, tsize.cx, nType, imgDstdata);

	Size size(tsize.cx, tsize.cy);

	resize(src, dst, size);
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL SetLedParam(BrightAreaParam tBrightAreaParam)
{

	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL FindLenPosition(uint32_t w, uint32_t h, uint32_t bpp, uint32_t channels, uint8_t* imgdata)
{

	return TRUE;
}

Mat mat;

EXPORTC MYDLL HANDLE STDCALL ReadImage(const char* szFileName, uint& w, uint32_t& h, uint32_t& bpp, uint32_t& channels)
{
	mat = imread(szFileName, IMREAD_UNCHANGED);

	if (mat.empty() == true)
	{
		return 0;
	}

	w = mat.cols;
	h = mat.rows;
	channels = mat.channels();

	bpp = uint32_t(mat.step.buf[1] * 8);

	return (HANDLE)&mat;
}

EXPORTC MYDLL BOOL STDCALL GetImage(HANDLE handle, uint8_t* imgdata)
{
	if (handle == (HANDLE)&mat && mat.empty() == false)
	{
		memcpy(imgdata, mat.data, mat.total() * mat.elemSize());

		mat.release();

		return true;
	}

	return false;
}

EXPORTC MYDLL BOOL STDCALL FovCalculation(HImage tImg, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, float* coordinates, FovPattern pattern, FovType type) {

	if (gIsOpen == false)
	{
		LOGE("\ncamera is close,FovCalculation FAIL!");
		return FALSE;
	}
	if (pattern == FovCircle && type == Leaning)
	{
		return FovImgCentreEX(tImg, coordinates[0], coordinates[1], coordinates[2], coordinates[3], Radio, cameraDegrees, fovDegrees, thresholdValue, dFovDist, pattern, type);
	}
	else
	{
		return FovImgCentre(tImg, Radio, cameraDegrees, fovDegrees, thresholdValue, dFovDist, pattern, type);
	}
}
double* pFOV_parametersFlo = nullptr;
int* pFOV_parametersInt = nullptr;
HImage FOV_image;
EXPORTC MYDLL BOOL STDCALL FovSetParameters(HANDLE handle, const HImage tImg, const double* parametersFlo, const int* parametersInt) {
	FOV_image = tImg;
	int arrLength = int(Fov_parameters::FOV_END);
	if (pFOV_parametersFlo == nullptr)
	{
		pFOV_parametersFlo = new double[arrLength];
		pFOV_parametersInt = new int[arrLength];
	}
	for (int i = 0; i < arrLength; i++)
	{
		pFOV_parametersFlo[i] = parametersFlo[i];
		pFOV_parametersInt[i] = parametersInt[i];
	}
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL FovGetResults(HANDLE handle, double* resultsFlo, int* resultsInt) {
	Point ImageCenter;

	int ntype = Gettype(FOV_image.iBpp, FOV_image.iChls);

	cv::Mat src = cv::Mat(FOV_image.iHei, FOV_image.iWid, ntype, FOV_image.pData);

	cv::Mat srctemp;
	//ͼ��ҶȻ�
	if (src.channels() != 1)
	{
		//ת���ɻҶ�ͼ
		cvtColor(src, srctemp, COLOR_BGR2GRAY);
	}
	else
	{
		srctemp = src.clone();
	}

	if (srctemp.type() != CV_8UC1)
	{
		srctemp.convertTo(srctemp, CV_8UC1, 1.0 / 256);
	}
	LOGD("FovImgCentre convert the img success.");

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~���ֲ�����ֵ*/
	FovPattern pattern = FovPattern(pFOV_parametersInt[int(Fov_parameters::FOV_Pattern)]);
	double Radio = pFOV_parametersFlo[int(Fov_parameters::FOV_Radio)];
	double dFovDist = pFOV_parametersFlo[int(Fov_parameters::FOV_dDist)];
	double cameraDegrees = pFOV_parametersFlo[int(Fov_parameters::FOV_cameraDegrees)];

	int thresholdValue = pFOV_parametersInt[int(Fov_parameters::FOV_ThresholdValue)];

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~������ֵ����*/
	double fovResult = 0;

	//���Ƿ���Ҫ����Խ�FOV
	if (FovType(pFOV_parametersInt[int(Fov_parameters::FOV_Leaning)]) == 1)
	{
		if (pattern == FovRectangle)
		{
			vector<Point2f> RectConners;
			//��ȡ�ǵ�
			BOOL ret = getRectCorners(srctemp, thresholdValue, RectConners, Radio);
			if (ret != CV_ERR_SUCCESS)
			{
				LOGE("FovImgCentre getRectCorners model failed.");
				return ret;
			}
			LOGD("FovImgCentre getRectCorners model success.");

			Mat showExactConer = src;
			if (src.channels() == 1)
			{
				cvtColor(src, showExactConer, COLOR_GRAY2BGR);
			}
			/*for (int i = 0; i < 4; i++)
			{
				circle(showExactConer, RectConners[i], 3, Scalar(0, 0, 60000), -1);
			}*/
			//�ǵ㾫��λ
			findExactCornerPoint(srctemp, RectConners, pFOV_parametersFlo[int(Fov_parameters::FOV_CornerValue)], pFOV_parametersInt[int(Fov_parameters::FOV_CutPicSize)], 10);

			//��ͼ�����ǵ㣬������
			for (int i = 0; i < 4; i++)
			{
				circle(showExactConer, RectConners[i], 3, Scalar(0, 60000, 0), -1);
			}

			imwrite("TIFF\\showExactConer.tif", showExactConer);

			vector<cv::Point2f>leaning2Points;
			leaning2Points.resize(2);
			leaning2Points[0] = RectConners[0];
			leaning2Points[1] = RectConners[2];
			//�����Խ����꣬���ϣ����µ�
			resultsInt[0] = leaning2Points[1].x;
			resultsInt[1] = leaning2Points[1].y;
			resultsInt[2] = leaning2Points[0].x;
			resultsInt[3] = leaning2Points[0].y;
			//�������ϣ����µ�FOV
			calFOV(leaning2Points, dFovDist, pFOV_parametersFlo[int(Fov_parameters::FOV_cameraDegrees)], fovResult);
			resultsFlo[6] = fovResult;

			leaning2Points[0] = RectConners[1];
			leaning2Points[1] = RectConners[3];
			//�����Խ����꣬���£����ϵ�
			resultsInt[4] = leaning2Points[0].x;
			resultsInt[5] = leaning2Points[0].y;
			resultsInt[6] = leaning2Points[1].x;
			resultsInt[7] = leaning2Points[1].y;
			//�������£����ϵ�FOV
			calFOV(leaning2Points, dFovDist, pFOV_parametersFlo[int(Fov_parameters::FOV_cameraDegrees)], fovResult);
			resultsFlo[7] = fovResult;
		}
		if (pattern == FovCircle)
		{
			/*�����Բ�����ɴ�����������FOV*/
			vector<Point2f> border_Corners;
			const double gradient = 1.0;
			int x_c = pFOV_parametersInt[int(Fov_parameters::FOV_p1_x)];
			int y_c = pFOV_parametersInt[int(Fov_parameters::FOV_p1_y)];
			int x_p = pFOV_parametersInt[int(Fov_parameters::FOV_p2_x)];
			int y_p = pFOV_parametersInt[int(Fov_parameters::FOV_p2_y)];
			Point2f center(x_c, y_c);
			Point2f point(x_p, y_p);
			bool result = RoughBoundaryCircleDetection(srctemp, center, point, border_Corners, gradient, Radio);
			if (!result)
			{
				return FALSE;
			}
			calFOV(border_Corners, dFovDist, cameraDegrees, fovResult);
			resultsFlo[5] = fovResult;
		}
	}

	if (pattern == FovRectangle) {
		vector<Point2f> RectConners;
		BOOL ret = getRectCorners(srctemp, thresholdValue, RectConners, Radio);
		if (ret != CV_ERR_SUCCESS)
		{
			LOGE("FovImgCentre getRectCorners model failed.");
			return ret;
		}
		LOGD("FovImgCentre getRectCorners model success.");
		vector<Point2f> Conners;
		const double gradient = 1.0;
		//���Ƿ���Ҫ��ˮƽFOV
		if (FovType(pFOV_parametersInt[int(Fov_parameters::FOV_Horizontal)]) == 1)
		{
			RoughBoundaryRectDetection(srctemp, RectConners, Conners, gradient, Radio, Horizontal);

			calFOV(Conners, dFovDist, cameraDegrees, fovResult);
			resultsFlo[0] = fovResult;
		}

		//���Ƿ���Ҫ��ֱFOV
		if (FovType(pFOV_parametersInt[int(Fov_parameters::FOV_Vertical)]) == 1)
		{
			RoughBoundaryRectDetection(srctemp, RectConners, Conners, gradient, Radio, Vertical);
			calFOV(Conners, dFovDist, cameraDegrees, fovResult);
			resultsFlo[1] = fovResult;
		}
	}
	return CV_ERR_SUCCESS;
}

EXPORTC MYDLL BOOL STDCALL FovImgCentre(HImage tImg, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, FovPattern pattern, FovType type)
{
	/*if (gIsOpen == false)
	{
		return FALSE;
	}*/

	Point ImageCenter;

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat src = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	cv::Mat srctemp;
	//ͼ��ҶȻ�
	if (src.channels() != 1)
	{
		//ת���ɻҶ�ͼ
		cvtColor(src, srctemp, COLOR_BGR2GRAY);
	}
	else
	{
		srctemp = src.clone();
	}

	if (srctemp.type() != CV_8UC1)
	{
		srctemp.convertTo(srctemp, CV_8UC1, 1.0 / 256);
	}
	LOGD("FovImgCentre convert the img success.");

	if (pattern == FovRectangle)
	{
		vector<Point2f> RectConners;
		BOOL ret = getRectCorners(srctemp, thresholdValue, RectConners, Radio);
		if (ret != CV_ERR_SUCCESS)
		{
			LOGE("FovImgCentre getRectCorners model failed.");
			return ret;
		}
		LOGD("FovImgCentre getRectCorners model success.");
		vector<Point2f> Conners;
		const double gradient = 1.0;
		RoughBoundaryRectDetection(srctemp, RectConners, Conners, gradient, Radio, type);
		srctemp.release();
		calFOV(Conners, dFovDist, cameraDegrees, fovDegrees);
	}
	else
	{
		if (type == Leaning)
		{
			LOGE("FovImgCentre Circle do not have Leaning");
			return FALSE;
		}
		else
		{
			if (!getCirclePoint(srctemp, thresholdValue, ImageCenter, Radio))
			{
				LOGE("FovImgCentre getCirclePoint model failed.");
				return FALSE;
			}

			LOGD("FovImgCentre getCirclePoint model success.");
			vector<Point2f> border_Corners;
			vector<Point2f> Image_Borders;
			const double gradient = 1.0;
			if (ImageCenter.x <= 0 || ImageCenter.y <= 0)
			{
				LOGE("Wrong Center input.");
				return FALSE;
			}

			RoughBoundaryPointsDetection(srctemp, ImageCenter, border_Corners, gradient, Radio, type);
			srctemp.release();

			calFOV(border_Corners, dFovDist, cameraDegrees, fovDegrees);
		}
	}

	LOGD("FovImgCentre output data success.");
	return CV_ERR_SUCCESS;
}

EXPORTC MYDLL BOOL STDCALL FovImgCentre_Version01(HImage tImg, float& x_c, float& y_c, float& x_p, float& y_p, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, FovPattern pattern, FovType type)
{
	/*if (gIsOpen == false)
	{
		return FALSE;
	}*/

	Point ImageCenter;

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat src = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	cv::Mat srctemp;
	//ͼ��ҶȻ�
	if (src.channels() != 1)
	{
		//ת���ɻҶ�ͼ
		cvtColor(src, srctemp, COLOR_BGR2GRAY);
	}
	else
	{
		srctemp = src.clone();
	}

	if (srctemp.type() != CV_8UC1)
	{
		srctemp.convertTo(srctemp, CV_8UC1, 1.0 / 256);
	}
	LOGD("FovImgCentre convert the img success.");

	if (pattern == FovRectangle)
	{
		vector<Point2f> RectConners;
		BOOL ret = getRectCorners(srctemp, thresholdValue, RectConners, Radio);
		if (CV_ERR_SUCCESS != ret)
		{
			LOGE("FovImgCentre getRectCorners model failed.");
			return ret;
		}
		LOGD("FovImgCentre getRectCorners model success.");
		vector<Point2f> Conners;
		const double gradient = 1.0;
		RoughBoundaryRectDetection(srctemp, RectConners, Conners, gradient, Radio, type);
		srctemp.release();
		x_c = Conners[0].x;
		y_c = Conners[0].y;
		x_p = Conners[1].x;
		y_p = Conners[1].y;
		calFOV(Conners, dFovDist, cameraDegrees, fovDegrees);
	}
	else
	{
		if (type == Leaning)
		{
			LOGE("FovImgCentre Circle do not have Leaning");
			return FALSE;
		}
		else
		{
			if (!getCirclePoint(srctemp, thresholdValue, ImageCenter, Radio))
			{
				LOGE("FovImgCentre getCirclePoint model failed.");
				return FALSE;
			}
			LOGD("FovImgCentre getCirclePoint model success.");
			vector<Point2f> border_Corners;
			vector<Point2f> Image_Borders;
			const double gradient = 1.0;
			if (ImageCenter.x <= 0 || ImageCenter.y <= 0)
			{
				LOGE("Wrong Center input.");
				return FALSE;
			}

			RoughBoundaryPointsDetection(srctemp, ImageCenter, border_Corners, gradient, Radio, type);
			srctemp.release();
			x_c = border_Corners[0].x;
			y_c = border_Corners[0].y;
			x_p = border_Corners[1].x;
			y_p = border_Corners[1].y;

			calFOV(border_Corners, dFovDist, cameraDegrees, fovDegrees);
		}
	}

	LOGD("FovImgCentre output data success.");
	return CV_ERR_SUCCESS;
}

EXPORTC MYDLL BOOL STDCALL FovImgCentreEX_Version01(HImage tImg, float& x_c, float& y_c, float& x_p, float& y_p, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, FovPattern pattern, FovType type)
{
	/*if (gIsOpen == false)
	{
		LOGE("\ncamera is close,Fov FAIL!");
		return FALSE;
	}*/

	Point ImageCenter;

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat src = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	cv::Mat srctemp;
	//ͼ��ҶȻ�
	if (src.channels() != 1)
	{
		//ת���ɻҶ�ͼ
		cvtColor(src, srctemp, COLOR_BGR2GRAY);
	}
	else
	{
		srctemp = src.clone();
	}

	if (srctemp.type() != CV_8UC1)
	{
		srctemp.convertTo(srctemp, CV_8UC1, 1.0 / 256);
	}
	LOGD("FovImgCentreEX convert the right img.");

	if (type == Leaning && pattern == FovCircle)
	{
		vector<Point2f> border_Corners;
		const double gradient = 1.0;
		Point2f center(x_c, y_c);
		Point2f point(x_p, y_p);
		bool result = RoughBoundaryCircleDetection(srctemp, center, point, border_Corners, gradient, Radio);
		if (!result)
		{
			return FALSE;
		}
		x_c = border_Corners[0].x;
		y_c = border_Corners[0].y;
		x_p = border_Corners[1].x;
		y_p = border_Corners[1].y;
		calFOV(border_Corners, dFovDist, cameraDegrees, fovDegrees);
	}
	else
	{
		return FovImgCentre_Version01(tImg, x_c, y_c, x_p, y_p, Radio, cameraDegrees, fovDegrees, thresholdValue, dFovDist, pattern, type);
	}

	srctemp.release();
	LOGD("FovImgCentreEX output the data success.");
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL FovImgCentreEX(HImage tImg, float x_c, float y_c, float x_p, float y_p, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, FovPattern pattern, FovType type)
{
	/*if (gIsOpen == false)
	{
		LOGE("\ncamera is close,Fov FAIL!");
		return FALSE;
	}*/

	Point ImageCenter;

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat src = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	cv::Mat srctemp;
	//ͼ��ҶȻ�
	if (src.channels() != 1)
	{
		//ת���ɻҶ�ͼ
		cvtColor(src, srctemp, COLOR_BGR2GRAY);
	}
	else
	{
		srctemp = src.clone();
	}

	if (srctemp.type() != CV_8UC1)
	{
		srctemp.convertTo(srctemp, CV_8UC1, 1.0 / 256);
	}
	LOGD("FovImgCentreEX convert the right img.");

	if (type == Leaning && pattern == FovCircle)
	{
		vector<Point2f> border_Corners;
		const double gradient = 1.0;
		Point2f center(x_c, y_c);
		Point2f point(x_p, y_p);
		bool result = RoughBoundaryCircleDetection(srctemp, center, point, border_Corners, gradient, Radio);
		if (!result)
		{
			return FALSE;
		}
		calFOV(border_Corners, dFovDist, cameraDegrees, fovDegrees);
	}
	else
	{
		return FovImgCentre(tImg, Radio, cameraDegrees, fovDegrees, thresholdValue, dFovDist, pattern, type);
	}

	srctemp.release();
	LOGD("FovImgCentreEX output the data success.");
	return TRUE;
}

EXPORTC MYDLL int STDCALL SFRCalculation(HImage tImg, IRECT rtROI, double gamma, float* pdfrequency, float* pdomainSamplingData, int nLen)
{
	/*if (gIsOpen == false)
	{
		LOGE("\ncamera is close,SFRCalculation FAIL!");
		return FALSE;
	}*/

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat src = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	vector<double> OverSamplingData;
	if (src.empty())
	{
		//std::cerr << "Open the ROI image error" << std::endl;
		return -1;
	}

	cv::Rect rect;

	rect.x = rtROI.x;
	rect.y = rtROI.y;
	rect.width = rtROI.cx;
	rect.height = rtROI.cy;
	if (rect.width >= tImg.iWid || rect.height >= tImg.iHei)
	{
		return -1;
	}
	Mat ROI;
	Mat tempImg = src(rect).clone();
	if (CV_ERR_SUCCESS != TranspositionROI(tempImg, ROI))
	{
		return -1;
	}
	Mat testImg = ROI.clone();

	int height = testImg.rows, width = testImg.cols;
	//Do the gamma decoding to eliminate the gamma encoded by camera device 
	de_Gamma(testImg, gamma);
	int i;

	double slope = 0, intercept = 0;

	//Center centroid offset
	double CCoffset = 0;
	std::vector<double> y_shifts(height);

	////Calculate the shifts between Centroids and Centroid of image center	
	//vector<double> Cen_Shifts = CentroidFind(ROI, y_shifts, CCoffset);
	y_shifts = HammingWindows(y_shifts, height);  // compared with sfrmat3
	vector<double> Cen_Shifts = CentroidFind(testImg, y_shifts, CCoffset);
	if (Cen_Shifts.empty()) { return -2; }

	//simple linear regression for slanted edge fitting
	SLR(Cen_Shifts, y_shifts, intercept, slope);
	Point2i PointO(int(CCoffset - (intercept / slope)), height / 2);
	int x0 = int(CCoffset - (intercept / slope) - (height / (2 * slope)));
	vector<int> PointsYzero;
	PointsYzero.clear();
	if (x0 <= 0 || x0 >= width)
	{
		LOGE("wrong SLR !");
		//cout << "wrong SLR ! " << endl;
		return -3;
	}
	else if (x0 <= 0.25 * width)
	{
		for (int i = 0; i < x0 + 0.25 * width; i++)
		{
			int x = i;
			PointsYzero.push_back(x);
		}
	}
	else if (x0 >= 0.75 * width)
	{
		for (int i = x0 - 0.25 * width; i < width; i++)
		{
			int x = i;
			PointsYzero.push_back(x);
		}
	}
	else
	{
		for (int i = x0 - 0.25 * width; i < x0 + 0.25 * width; i++)
		{
			int x = i;
			PointsYzero.push_back(x);
		}
	}
	vector<GraySlop> sumVec;
	sumVec.clear();
	for (int n = 0; n < PointsYzero.size(); n++)
	{
		GraySlop tempGraySlop;
		tempGraySlop.m_y = 0;
		tempGraySlop.m_x = PointsYzero[n];
		vector<double> grayVec;
		for (int i = 0; i < height; i++)
		{
			int j = (int)(CCoffset - (intercept / slope) + (i - height * 0.5) * (PointsYzero[n] - CCoffset + (intercept / slope)) / (0 - height * 0.5));
			if (j < 1 || j >(width - 1)) break;
			double gray = (double)testImg.at<uchar>(i, j);
			grayVec.push_back(gray);
		}
		tempGraySlop.m_grayoffset = CalStd(grayVec);
		sumVec.push_back(tempGraySlop);
	}
	double temGrayoffset = 99999;
	int nCount = 0;
	for (int i = 0; i < sumVec.size(); i++)
	{
		if (sumVec[i].m_grayoffset < temGrayoffset)
		{
			temGrayoffset = sumVec[i].m_grayoffset;
			nCount = sumVec[i].m_x;
		}
	}
	slope = (0 - 0.5 * height) / (nCount - PointO.x);
	int x1 = 0;
	int y1 = x1 * slope - CCoffset * slope + intercept + height / 2;
	int x2 = width;
	int y2 = x2 * slope - CCoffset * slope + intercept + height / 2;

	//Truncate the number of rows of data to largest slope cycle which will have an integer number of full phase rotations
	ReduceRows(slope, height);
	//update the CCoffset to the offset between original mid point of image and reference mid point we calculated
	CCoffset = CCoffset + 0.5 + intercept - width / 2;
	//cout << "CCoffset: " << CCoffset << endl;

	//Mapping the pixel value of original image into a sampling data which the length is 4 times of original image width
	//This step is for concentrating the amount of change of original pixel values
	//int SamplingLen = width * 4;
	int SamplingLen = width * 4;//seems 4xsampling could involved the mistakes��
	OverSamplingData = OverSampling(ROI, slope, CCoffset, height, width, SamplingLen);

	//Using hamming window to filter the ripple signal of two side of data
	OverSamplingData = HammingWindows(OverSamplingData, SamplingLen);

	//decrete four transform
	for (i = 0; i <= width; ++i)
	{
		double frequency = (double)i / width;
	}
	DFT(OverSamplingData, SamplingLen);
	//width = int(SamplingLen / 1);
	width = int(SamplingLen / 4);
	double maxData = 0;
	for (i = 0; i < SamplingLen; ++i)
	{
		if (OverSamplingData[i] != 0)
		{
			maxData = OverSamplingData[i];
			break;
		}
	}
	for (int i = 0; i < SamplingLen; ++i) { OverSamplingData[i] /= maxData; }

	vector<double> domainSamplingData;
	vector<double> frequency;

	for (i = 0; i < width; ++i)
	{
		if (i >= nLen)
		{
			break;
		}

		pdfrequency[i] = (double)i / width;
		pdomainSamplingData[i] = OverSamplingData[i];
	}

	return 1;
}

EXPORTC MYDLL double STDCALL cvCalArticulation(EvaFunc type, HImage iImg, int dx, int dy, int ksize, double dRatio, int h, int nStep, int nMaxCount)
{
	/*if (gIsOpen == false)
	{
		LOGE("\ncamera is close,cvCalArticulation FAIL!");
		return FALSE;
	}*/
	int ntype = OpencvManager::Gettype(iImg.iBpp, iImg.iChls);

	Mat src(iImg.iHei, iImg.iWid, ntype, iImg.pData);

	double dvalue = 0;

	DataAnalyzer::CalArticulation(src, dvalue, type, dx, dy, ksize, dRatio, h, nStep, nMaxCount);

	return dvalue;
}

Eigen::VectorXd gcoeffs;

EXPORTC MYDLL BOOL STDCALL cvCalcFit(int nFit, double* pdX, double* pdY, int nDataSize)
{
	gcoeffs = DataAnalyzer::CalcFit(nFit, pdX, pdY, nDataSize);

	return gcoeffs.size() > 0 ? TRUE : FALSE;
}

EXPORTC MYDLL BOOL STDCALL cvGetFitFy(double dXvalue, double& dYvalue)
{
	return DataAnalyzer::GetFitFy(gcoeffs, dXvalue, dYvalue);
}

std::map<int, Eigen::VectorXd> gmapcoeffs;

EXPORTC MYDLL int WINAPI CM_CreateFit(int nId, int nFit, double* x, double* y, int nLength)
{
	Eigen::VectorXd coeffs = DataAnalyzer::CalcFit(nFit, x, y, nLength);

	if (coeffs.size() > 0)
	{
		gmapcoeffs[nId] = coeffs;
		return TRUE;
	}

	return FALSE;
}

EXPORTC MYDLL BOOL STDCALL CM_GetFitFy(int nId, double x, double& Y)
{
	if (gmapcoeffs.find(nId) != gmapcoeffs.end())
	{
		return DataAnalyzer::GetFitFy(gmapcoeffs[nId], x, Y);
	}

	return FALSE;
}

EXPORTC MYDLL BOOL STDCALL CM_ReleaseFit(int nId)
{
	if (gmapcoeffs.find(nId) != gmapcoeffs.end())
	{
		return gmapcoeffs.erase(nId);
	}

	return FALSE;
}

EXPORTC MYDLL float STDCALL CM_CalcRGBSaturation(HImage tImg, uint16_t maxSatVal, double maxPecentage)
{
	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat src = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	if (src.empty() == false)
	{
		return DataAnalyzer::CalcRGBSaturation(src, maxSatVal, maxPecentage);
	}

	return 0.0f;
}

bool CampAdd(Point a, Point b)
{
	return a.x + a.y > b.x + b.y;
}

bool CampSub(Point a, Point b)
{
	return a.x - a.y > b.x - b.y;
}

std::vector<std::vector<cv::Point>> contours_out;
std::vector<cv::Vec4i> hierarchy;

EXPORTC MYDLL BOOL STDCALL cvCalcFiveDot(HImage iImg, double* x, double* y, int nThreshold)
{
	int ntype = OpencvManager::Gettype(iImg.iBpp, iImg.iChls);

	Mat src(iImg.iHei, iImg.iWid, ntype, iImg.pData);

	src = MatToCImage(src);

	if (src.channels() == 3)
	{
		cv::cvtColor(src, src, cv::COLOR_BGR2GRAY);
	}

	blur(src, src, Size(9, 9));

	Mat kernel = getStructuringElement(MORPH_RECT, Size(9, 9));

	dilate(src, src, kernel);

	erode(src, src, kernel);

	cv::threshold(src, src, nThreshold, 255, THRESH_BINARY);

	//cv::imwrite("threshold.jpg", src);

	cv::findContours(src, contours_out, hierarchy, RETR_TREE, CHAIN_APPROX_NONE);

	std::vector<std::vector<cv::Point>> contoursTemp;

	for (size_t i(0); i < contours_out.size(); i++)
	{
		if (contourArea(contours_out[i]) > 5)
		{
			contoursTemp.push_back(contours_out[i]);
		}
	}

	if (contoursTemp.size() < 5)
	{
		return false;
	}

	vector<cv::Point2d> vcPoint;

	for (int i = 0; i < contoursTemp.size(); i++)
	{
		cv::Moments moment = cv::moments(contoursTemp.at(i));
		cv::Point2d midPoint = cv::Point2d(double(moment.m10 / moment.m00), double(moment.m01 / moment.m00));

		vcPoint.push_back(midPoint);
	}

	sort(vcPoint.begin(), vcPoint.end(), CampAdd);

	x[0] = vcPoint[0].x;
	y[0] = vcPoint[0].y;

	x[2] = vcPoint[4].x;
	y[2] = vcPoint[4].y;

	sort(vcPoint.begin(), vcPoint.end(), CampSub);

	x[3] = vcPoint[0].x;
	y[3] = vcPoint[0].y;

	x[1] = vcPoint[4].x;
	y[1] = vcPoint[4].y;

	for (size_t i = 0; i < vcPoint.size(); i++)
	{
		bool bFlag = false;

		for (int j = 0; j < 4; j++)
		{
			if (x[j] == vcPoint[i].x && y[j] == vcPoint[i].y)
			{
				bFlag = true;
				break;
			}
		}

		if (bFlag == false)
		{
			x[4] = vcPoint[i].x;
			y[4] = vcPoint[i].y;
		}
	}

	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL fcMrDownSampleSumByCols(uint32_t w, uint32_t h, uint32_t bpp, uint32_t channels, uint8_t* imgdata, uint8_t* imgdst, uint32_t nScale)
{
	if (channels != 1)
	{
		return FALSE;
	}

	int nType = Gettype(bpp, channels);

	Mat src(h, w, nType, imgdata);

	const int downsampleScale = nScale;

	int width_section = src.cols / downsampleScale;
	int height_section = src.rows / downsampleScale;

	int width = width_section * downsampleScale;
	int height = src.rows;

	vector<Mat> img_S;
	vector<Mat> img_SR;

	img_S.resize(downsampleScale);
	img_SR.resize(downsampleScale);

	for (int i = 0; i < downsampleScale; i++)
	{
		img_S[i] = Mat(height, width_section, CV_32FC1);
		img_SR[i] = Mat(height, width - downsampleScale + 1, CV_32FC1);
	}

	for (int i = 0; i < downsampleScale; i++)
	{
		float* pDstData = (float*)img_S[i].data;

		if (bpp == 8)
		{
			uint8_t* pSrcData = (uint8_t*)src.data;

			for (int h = 0; h < height; h++)
			{
				for (int w = 0; w < width_section; w++)
				{
					pDstData[h * width_section + w] = pSrcData[h * src.cols + w * downsampleScale + i];
				}
			}
		}
		else if (bpp == 16)
		{
			uint16_t* pSrcData = (uint16_t*)src.data;

			for (int h = 0; h < height; h++)
			{
				for (int w = 0; w < width_section; w++)
				{
					pDstData[h * width_section + w] = pSrcData[h * src.cols + w * downsampleScale + i];
				}
			}
		}
	}

	for (int i = 0; i < downsampleScale; i++)
	{
		resize(img_S[i], img_SR[i], Size(img_SR[i].cols, img_SR[i].rows));
	}

	Mat rebuild = Mat::zeros(height, width, CV_32FC1);

	for (int i = 0; i < downsampleScale; i++)
	{
		float* pDstData = (float*)rebuild.data;
		float* pSrcData = (float*)img_SR[i].data;

		for (int h = 0; h < rebuild.rows; h++)
		{
			for (int w = 0; w < rebuild.cols; w++)
			{
				pDstData[h * rebuild.cols + w + i] += pSrcData[h * img_SR[i].cols + w];
			}
		}
	}

	memcpy(imgdst, rebuild.data, rebuild.rows * rebuild.cols * 4);

	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL fcMrDownSampleSumByRows(uint32_t w, uint32_t h, uint32_t bpp, uint32_t channels, uint8_t* imgdata, uint8_t* imgdst, uint32_t nScale)
{
	if (channels != 1)
	{
		return FALSE;
	}

	int nType = Gettype(bpp, channels);

	Mat src(h, w, nType, imgdata);

	const int downsampleScale = nScale;

	int width_section = src.cols / downsampleScale;
	int height_section = src.rows / downsampleScale;

	int width = src.cols;
	int height = height_section * downsampleScale;

	vector<Mat> img_S;
	vector<Mat> img_SR;

	img_S.resize(downsampleScale);
	img_SR.resize(downsampleScale);

	for (int i = 0; i < downsampleScale; i++)
	{
		img_S[i] = Mat(height_section, width, CV_32FC1);
		img_SR[i] = Mat(height - downsampleScale + 1, width, CV_32FC1);
	}

	for (int i = 0; i < downsampleScale; i++)
	{
		float* pDstData = (float*)img_S[i].data;
		uint16_t* pSrcData = (uint16_t*)src.data;

		for (int h = 0; h < img_S[i].rows; h++)
		{
			for (int w = 0; w < img_S[i].cols; w++)
			{
				pDstData[h * img_S[i].cols + w] = pSrcData[(h * downsampleScale + i) * src.cols + w];
			}
		}
	}

	for (int i = 0; i < downsampleScale; i++)
	{
		resize(img_S[i], img_SR[i], Size(img_SR[i].cols, img_SR[i].rows));
	}

	Mat rebuild = Mat::zeros(height, width, CV_32FC1);

	for (int i = 0; i < downsampleScale; i++)
	{
		float* pDstData = (float*)rebuild.data;
		float* pSrcData = (float*)img_SR[i].data;

		for (int h = 0; h < img_SR[i].rows; h++)
		{
			for (int w = 0; w < rebuild.cols; w++)
			{
				pDstData[(h + i) * rebuild.cols + w] += pSrcData[h * img_SR[i].cols + w];
			}
		}
	}

	memcpy(imgdst, rebuild.data, rebuild.rows * rebuild.cols * 4);

	return TRUE;
}

template<class T>
BOOL T_polarizatie(uint w, uint h, uint bpp, const BYTE* srcimgdata, BYTE* PolarizatIntensity, BYTE* PolarizatAngle, uint& dstW, uint& dstH) {

	if (w % 4 != 0 || h % 2 != 0)
	{
		return FALSE;
	}

	int type = CV_16UC1;
	if (bpp == 8)
	{
		type = CV_8UC1;
	}

	T* imgData = (T*)srcimgdata;

	int index = 0;
	T* dataAngle_0 = new T[w * h / 4];
	T* dataAngle_45 = new T[w * h / 4];
	T* dataAngle_90 = new T[w * h / 4];
	T* dataAngle_135 = new T[w * h / 4];

	for (int i = 0; i < h; i += 2) {
		for (int j = 0; j < w; j += 2)
		{
			dataAngle_0[index] = imgData[i * w + j];
			index++;
		}
	}

	index = 0;
	for (int i = 0; i < h; i += 2) {
		for (int j = 1; j < w; j += 2)
		{
			dataAngle_45[index] = imgData[i * w + j];
			index++;
		}
	}

	index = 0;
	for (int i = 1; i < h; i += 2) {
		for (int j = 0; j < w; j += 2)
		{
			dataAngle_90[index] = imgData[i * w + j];
			index++;
		}
	}

	index = 0;
	for (int i = 1; i < h; i += 2) {
		for (int j = 1; j < w; j += 2)
		{
			dataAngle_90[index] = imgData[i * w + j];
			index++;
		}
	}

	dstH = h / 2;
	dstW = w / 2;
	cv::Mat image_Angle0(dstH, dstW, type, dataAngle_0);
	cv::Mat image_Angle45(dstH, dstW, type, dataAngle_45);
	cv::Mat image_Angle90(dstH, dstW, type, dataAngle_90);
	cv::Mat image_Angle135(dstH, dstW, type, dataAngle_135);


	//��Ȼ��
	Mat image_nature = image_Angle0 + image_Angle90;


	//ƫ��
	Mat image_polarizeteQ = image_Angle0 - image_Angle90;
	Mat image_polarizeteU = image_Angle45 - image_Angle135;

	//imwrite("TIFF\\image_Angle90.tif", image_Angle90);
	float* polarizatIntensityData = new float[dstH * dstW];

	for (int i = 0; i < dstH; i++)
	{
		for (int j = 0; j < dstW; j++)
		{
			int squareQ = pow(image_polarizeteQ.at<T>(i, j), 2);
			int squareU = pow(image_polarizeteU.at<T>(i, j), 2);
			polarizatIntensityData[i * dstW + j] = sqrt(squareQ + squareU) / image_nature.at<T>(i, j);
		}
	}

	memcpy(PolarizatIntensity, polarizatIntensityData, w * h);


	float* polarizatAngleData = new float[dstH * dstW];

	float base = 0;
	int meanValue_angle0 = cv::mean(image_Angle0)[0];
	int meanValue_angle45 = cv::mean(image_Angle45)[0];
	int meanValue_angle90 = cv::mean(image_Angle90)[0];

	const float  PI_angle = 180;
	const float  PI = 3.1415927;

	if (meanValue_angle90 < meanValue_angle0 && meanValue_angle0 < meanValue_angle45)
	{
		base = 0;
	}

	if (meanValue_angle90 < meanValue_angle0 && meanValue_angle0 > meanValue_angle45)
	{
		base += PI_angle;
	}

	else
	{
		base += 0.5 * PI_angle;
	}

	for (int i = 0; i < dstH; i++)
	{
		for (int j = 0; j < dstW; j++)
		{
			int QP = image_polarizeteQ.at<T>(i, j);
			if (QP > 0)
			{
				polarizatAngleData[i * dstW + j] = /*0.5 **/ atan(image_polarizeteU.at<T>(i, j) / QP) / PI * 90 + base;
			}
			else {
				polarizatAngleData[i * dstW + j] = 0;
			}

		}
	}


	memcpy(PolarizatAngle, polarizatAngleData, w * h);

	delete[]dataAngle_0;
	delete[]dataAngle_45;
	delete[]dataAngle_90;
	delete[]dataAngle_135;
	delete[]polarizatIntensityData;
	delete[]polarizatAngleData;
	return TRUE;
}

BOOL polarizatie(uint w, uint h, uint bpp, const BYTE* srcimgdata, BYTE* PolarizatIntensity, BYTE* PolarizatAngle, uint& dstW, uint& dstH) {

	if (bpp == 8) {
		return T_polarizatie<uchar>(w, h, bpp, srcimgdata, PolarizatIntensity, PolarizatAngle, dstW, dstH);
	}

	else if (bpp == 16) {
		return T_polarizatie<ushort>(w, h, bpp, srcimgdata, PolarizatIntensity, PolarizatAngle, dstW, dstH);
	}

	else
	{
		return FALSE;
	}
}
EXPORTC MYDLL BOOL STDCALL DistortionCalculation(HImage iImg, ISIZE iSize, BlobThreParams tBlobThreParams, float* finalPointsX, float* finalPointsY, double& pointx, double& pointy, double& maxErrorRatio, double& t, CornerType type, SlopeType sType, LayoutType lType, DistortionType dType, int timeoutNumLimit) {
	return DistortionCheck_Version01(iImg, iSize, tBlobThreParams, finalPointsX, finalPointsY, pointx, pointy, maxErrorRatio, t, type, sType, lType, dType, timeoutNumLimit);
}

EXPORTC MYDLL BOOL STDCALL DistortionCheck(HImage iImg, ISIZE iSize, BlobThreParams tBlobThreParams, float* finalPointsX, float* finalPointsY, double& pointx, double& pointy, double& maxErrorRatio, double& t, CornerType type /*= Circlepoint*/, SlopeType sType /*= CenterPoint*/, LayoutType lType /*= SlopeIN*/, DistortionType dType, int timeoutNumLimit)
{
	/*if (gIsOpen == false)
	{
		return FALSE;
	}*/

	Mat imageGray;
	Size PointsSize(iSize.cx, iSize.cy);

	int ntype = OpencvManager::Gettype(iImg.iBpp, iImg.iChls);

	Mat image(iImg.iHei, iImg.iWid, ntype, iImg.pData);

	if (image.empty())
	{
		LOGE("DistortionCheck No input image");
		return FALSE;
	}
	if (PointsSize.width < 3 || PointsSize.height < 3)
	{
		LOGE("DistortionCheck Wrong Size input");
		return FALSE;
	}
	if (image.channels() != 1)
	{
		cvtColor(image, imageGray, COLOR_BGR2GRAY);
	}
	else
	{
		imageGray = image.clone();
	}

	if (imageGray.depth() != CV_8U)
	{
		imageGray.convertTo(imageGray, CV_8UC1, 1.0 / 256, 0);
	}
	LOGD("DistortionCheck get promp img success.");
	int trans = PointsSize.width * (int)(PointsSize.height / 2) + (int)(PointsSize.width / 2); //1??����??����??DD?��?
	vector<Point2f> corners(PointsSize.width * PointsSize.height);	//??��?��?����?��
	switch (type)
	{
	case Circlepoint:
		if (false == getCirclesCorners(imageGray, PointsSize, corners, tBlobThreParams))
		{
			LOGE("DistortionCheck Circle corners collected failed");
			return FALSE;
		}
		else
		{
			LOGD("DistortionCheck collected circles success.");
		}
		break;
	case Checkerboard:
		if (false == getBoardsCorners(imageGray, PointsSize, corners, timeoutNumLimit))
		{
			LOGE("DistortionCheck Circle corners collected failed");
			return FALSE;
		}
		else
		{
			LOGD("DistortionCheck collected corners success.");
		}
		break;

	default:
		if (false == getCirclesCorners(imageGray, PointsSize, corners, tBlobThreParams))
		{
			LOGE("DistortionCheck Circle corners collected failed");
			return FALSE;
		}
		else
		{
			LOGD("DistortionCheck collected corners success.");
		}
		break;
	}
	//??D???D��??��?��?����????
	vector<Point2d> ComparePoints(PointsSize.width * PointsSize.height);	//??D???D��o����???��?��?����?��
	if (sortConers(corners, ComparePoints, PointsSize) != true)
	{
		LOGE("DistortionCheck sort corners/circles failed.");
		return FALSE;
	}
	else
	{
		LOGD("DistortionCheck sort corners/circles success.");
	}

	if (dType == OpticsDist)
	{
		bool result;
		double dFinalSlop = 0;	//��??��Dy��a��?D��?��
		switch (sType)
		{
		case CenterPoint:
			dFinalSlop = CalSlope(ComparePoints[trans].x - ComparePoints[trans - 1].x, ComparePoints[trans].y - ComparePoints[trans - 1].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + 1].x - ComparePoints[trans].x, ComparePoints[trans + 1].y - ComparePoints[trans].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width].x - ComparePoints[trans - 1 + PointsSize.width].x, ComparePoints[trans + PointsSize.width].y - ComparePoints[trans - 1 + PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + 1 + PointsSize.width].x - ComparePoints[trans + PointsSize.width].x, ComparePoints[trans + 1 + PointsSize.width].y - ComparePoints[trans + PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans - PointsSize.width].x - ComparePoints[trans - 1 - PointsSize.width].x, ComparePoints[trans - PointsSize.width].y - ComparePoints[trans - 1 - PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + 1 - PointsSize.width].x - ComparePoints[trans - PointsSize.width].x, ComparePoints[trans + 1 - PointsSize.width].y - ComparePoints[trans - PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans].x - ComparePoints[trans - PointsSize.width].x, ComparePoints[trans].y - ComparePoints[trans - PointsSize.width].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width].x - ComparePoints[trans].x, ComparePoints[trans + PointsSize.width].y - ComparePoints[trans].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + 1].x - ComparePoints[trans - PointsSize.width + 1].x, ComparePoints[trans + 1].y - ComparePoints[trans - PointsSize.width + 1].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width + 1].x - ComparePoints[trans + 1].x, ComparePoints[trans + PointsSize.width + 1].y - ComparePoints[trans + 1].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans - 1].x - ComparePoints[trans - PointsSize.width - 1].x, ComparePoints[trans - 1].y - ComparePoints[trans - PointsSize.width - 1].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width - 1].x - ComparePoints[trans - 1].x, ComparePoints[trans + PointsSize.width - 1].y - ComparePoints[trans - 1].y, 0, 50000);
			dFinalSlop /= 12;
			break;
		case lb_Variance:

			result = CalFinalSlope(ComparePoints, PointsSize, dFinalSlop);
			if (result == false) return FALSE;
			break;

		default:
			result = CalFinalSlope(ComparePoints, PointsSize, dFinalSlop);
			if (result == false) return FALSE;
			break;
		}
		LOGD("DistortionCheck cal corners/circles slop success.");
		//cout << "dFinalSlop = " << dFinalSlop << endl;
		Size SquareSize(30, 30);
		double dSlope = dFinalSlop;
		vector<Point2d> InitPoints(PointsSize.width * PointsSize.height);	//����??��??��?��
		InitPoints.clear();
		for (int i = 0; i < PointsSize.height; i++)	//��?D��?����?3?��??������??��?����?��
		{
			for (int j = 0; j < PointsSize.width; j++)
			{
				Point2d temppoint;
				temppoint.x = j * SquareSize.width * cos((-1.0) * dSlope) - i * SquareSize.height * sin((-1.0) * dSlope);
				temppoint.y = j * SquareSize.width * sin((-1.0) * dSlope) + i * SquareSize.height * cos((-1.0) * dSlope);
				InitPoints.push_back(temppoint);
			}
		}
		double dScalex = 0;
		double dScaley = 0;
		result = CalScale(InitPoints, ComparePoints, PointsSize, dScalex, dScaley);
		if (result == false)
		{
			LOGE("DistortionCheck cal scale failed.");
			return FALSE;
		}
		LOGD("DistortionCheck cal scale success.");

		double dTransX = 0;
		double dTransY = 0;
		vector<double> vSlop;
		vector<Point2d> tempPoints;
		for (int i = 0; i < InitPoints.size(); i++)
		{
			tempPoints.push_back(Point2d((InitPoints[i].x) * dScalex, (InitPoints[i].y) * dScaley));
		}
		dTransX = tempPoints[trans].x - ComparePoints[trans].x;
		dTransY = tempPoints[trans].y - ComparePoints[trans].y;
		vector<Point2f> finalPoints;
		for (int i = 0; i < InitPoints.size(); i++)
		{
			finalPointsX[i] = tempPoints[i].x - dTransX;
			finalPointsY[i] = tempPoints[i].y - dTransY;
			finalPoints.push_back(Point2d(tempPoints[i].x - dTransX, tempPoints[i].y - dTransY));
		}
		int count = 0;
		double maxError = 0.;
		for (int i = 0; i != finalPoints.size(); i++)
		{
			double tempError = sqrt((finalPoints[i].x - ComparePoints[i].x) * (finalPoints[i].x - ComparePoints[i].x) + (finalPoints[i].y - ComparePoints[i].y) * (finalPoints[i].y - ComparePoints[i].y));
			if (tempError > maxError)
			{
				double d1, d2;
				maxError = tempError;
				maxErrorRatio = maxError / sqrt((ComparePoints[trans].x - finalPoints[i].x) * (ComparePoints[trans].x - finalPoints[i].x) + (ComparePoints[trans].y - finalPoints[i].y) * (ComparePoints[trans].y - finalPoints[i].y));
				d1 = sqrt((ComparePoints[trans].x - finalPoints[i].x) * (ComparePoints[trans].x - finalPoints[i].x) + (ComparePoints[trans].y - finalPoints[i].y) * (ComparePoints[trans].y - finalPoints[i].y));
				d2 = sqrt((ComparePoints[trans].x - ComparePoints[i].x) * (ComparePoints[trans].x - ComparePoints[i].x) + (ComparePoints[trans].y - ComparePoints[i].y) * (ComparePoints[trans].y - ComparePoints[i].y));
				count = i;
				if (d1 > d2)
				{
					maxErrorRatio = -maxErrorRatio;
				}
				else
				{
					maxErrorRatio = maxErrorRatio;
				}
			}
		}
		pointx = ComparePoints[count].x;
		pointy = ComparePoints[count].y;
		double reves = dFinalSlop * 57.3;
		if (reves < -90)
		{
			t = reves;
		}
		else if (reves > 90)
		{
			t = reves;
		}
		else
		{
			t = reves;
		}

		if (lType == SlopeOUT)
		{
			finalPoints.clear();
			for (int i = 0; i < PointsSize.height; i++)	//��?D��?����?3?��??������??��?����?��
			{
				for (int j = 0; j < PointsSize.width; j++)
				{
					Point2d temppoint;
					temppoint.x = j * SquareSize.width;
					temppoint.y = i * SquareSize.height;
					temppoint.x *= dScalex;
					temppoint.y *= dScaley;
					temppoint.x -= dTransX;
					temppoint.y -= dTransY;
					finalPoints.push_back(temppoint);
				}
			}
			for (int k = 0; k < InitPoints.size(); k++)
			{
				finalPointsX[k] = finalPoints[k].x;
				finalPointsY[k] = finalPoints[k].y;
			}
		}
		return TRUE;
	}
	if (dType == TVDistH)
	{
		float midDis = 0.;
		float leftDis = 0.;
		float rightDis = 0.;
		if (PointsSize.width % 2 == 0)
		{
			leftDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y));
			rightDis = sqrt((ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = 0.5 * sqrt((ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].x)
				* (ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].x)
				+ (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].y)
				* (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].y))
				+
				0.5 * sqrt((ComparePoints[PointsSize.width / 2 - 1].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
					* (ComparePoints[PointsSize.width / 2 - 1].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
					+ (ComparePoints[PointsSize.width / 2 - 1].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y)
					* (ComparePoints[PointsSize.width / 2 - 1].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y));
		}
		else if (PointsSize.width % 2 == 1)
		{
			leftDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y));
			rightDis = sqrt((ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = sqrt((ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
				* (ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
				+ (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y)
				* (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y));
		}
		else
		{
			LOGE("DistortionCheck get WRONG board_size input.");
			return FALSE;
		}

		maxErrorRatio = 1.0 - (leftDis + rightDis) / (2 * midDis);
		for (int i = 0; i < ComparePoints.size(); i++)
		{
			finalPointsX[i] = (float)ComparePoints[i].x;
			finalPointsY[i] = (float)ComparePoints[i].y;
		}
		return TRUE;
	}
	if (dType == TVDistV)
	{
		float upDis = 0.;
		float downDis = 0.;
		float midDis = 0.;
		if (PointsSize.height % 2 == 0)
		{
			upDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y));
			downDis = sqrt((ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = 0.5 * sqrt((ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				+ (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y))
				+
				0.5 * sqrt((ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].x - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].x)
					* (ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].x - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].x)
					+ (ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].y - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].y)
					* (ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].y - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].y));
		}
		else if (PointsSize.height % 2 == 1)
		{
			upDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y));
			downDis = sqrt((ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = sqrt((ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				+ (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y));
		}
		else
		{
			LOGE("DistortionCheck get WRONG board_size input.");
			return FALSE;
		}

		maxErrorRatio = 1.0 - (upDis + downDis) / (2 * midDis);
		for (int i = 0; i < ComparePoints.size(); i++)
		{
			finalPointsX[i] = (float)ComparePoints[i].x;
			finalPointsY[i] = (float)ComparePoints[i].y;
		}
		LOGD("DistortionCheck output data success.");
		return TRUE;
	}

	LOGE("DistortionCheck NOT choose the right Distortion-Check Type.");
	return FALSE;
}

EXPORTC MYDLL BOOL STDCALL DistortionCheck_Version01(HImage iImg, ISIZE iSize, BlobThreParams tBlobThreParams, float* finalPointsX, float* finalPointsY, double& pointx, double& pointy, double& maxErrorRatio, double& t, CornerType type /*= Circlepoint*/, SlopeType sType /*= CenterPoint*/, LayoutType lType /*= SlopeIN*/, DistortionType dType, int timeoutNumLimit)
{
	if (gIsOpen == false)
	{
		LOGE("\ncamera is close,DistortionCheck FAIL!");
		return FALSE;
	}

	Size PointsSize(iSize.cx, iSize.cy);

	int ntype = OpencvManager::Gettype(iImg.iBpp, iImg.iChls);

	Mat image(iImg.iHei, iImg.iWid, ntype, iImg.pData);

	if (image.empty())
	{
		LOGE("DistortionCheck No input image");
		return FALSE;
	}
	if (PointsSize.width < 3 || PointsSize.height < 3)
	{
		LOGE("DistortionCheck Wrong Size input");
		return FALSE;
	}
	int trans = PointsSize.width * (int)(PointsSize.height / 2) + (int)(PointsSize.width / 2); //1??����??����??DD?��?
	vector<Point2f> corners(PointsSize.width * PointsSize.height);	//??��?��?����?��
	switch (type)
	{
	case Circlepoint:
		if (false == getCirclesCorners_Version01(image, PointsSize, corners, tBlobThreParams))
		{
			LOGE("DistortionCheck Circle corners collected failed");
			return FALSE;
		}
		else
		{
			LOGD("DistortionCheck collected circles success.");
		}
		break;
	case Checkerboard:
		if (false == getBoardsCorners(image, PointsSize, corners, timeoutNumLimit))
		{
			LOGE("DistortionCheck Circle corners collected failed");
			return FALSE;
		}
		else
		{
			LOGD("DistortionCheck collected corners success.");
		}
		break;

	default:
		if (false == getCirclesCorners_Version01(image, PointsSize, corners, tBlobThreParams))
		{
			LOGE("DistortionCheck Circle corners collected failed");
			return FALSE;
		}
		else
		{
			LOGD("DistortionCheck collected corners success.");
		}
		break;
	}
	//??D???D��??��?��?����????
	vector<Point2d> ComparePoints(PointsSize.width * PointsSize.height);	//??D???D��o����???��?��?����?��
	if (sortConers(corners, ComparePoints, PointsSize) != true)
	{
		LOGE("DistortionCheck sort corners/circles failed.");
		return FALSE;
	}
	else
	{
		LOGD("DistortionCheck sort corners/circles success.");
	}

	if (dType == OpticsDist)
	{
		bool result;
		double dFinalSlop = 0;	//��??��Dy��a��?D��?��
		switch (sType)
		{
		case CenterPoint:
			dFinalSlop = CalSlope(ComparePoints[trans].x - ComparePoints[trans - 1].x, ComparePoints[trans].y - ComparePoints[trans - 1].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + 1].x - ComparePoints[trans].x, ComparePoints[trans + 1].y - ComparePoints[trans].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width].x - ComparePoints[trans - 1 + PointsSize.width].x, ComparePoints[trans + PointsSize.width].y - ComparePoints[trans - 1 + PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + 1 + PointsSize.width].x - ComparePoints[trans + PointsSize.width].x, ComparePoints[trans + 1 + PointsSize.width].y - ComparePoints[trans + PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans - PointsSize.width].x - ComparePoints[trans - 1 - PointsSize.width].x, ComparePoints[trans - PointsSize.width].y - ComparePoints[trans - 1 - PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans + 1 - PointsSize.width].x - ComparePoints[trans - PointsSize.width].x, ComparePoints[trans + 1 - PointsSize.width].y - ComparePoints[trans - PointsSize.width].y, 50000, 0);
			dFinalSlop += CalSlope(ComparePoints[trans].x - ComparePoints[trans - PointsSize.width].x, ComparePoints[trans].y - ComparePoints[trans - PointsSize.width].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width].x - ComparePoints[trans].x, ComparePoints[trans + PointsSize.width].y - ComparePoints[trans].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + 1].x - ComparePoints[trans - PointsSize.width + 1].x, ComparePoints[trans + 1].y - ComparePoints[trans - PointsSize.width + 1].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width + 1].x - ComparePoints[trans + 1].x, ComparePoints[trans + PointsSize.width + 1].y - ComparePoints[trans + 1].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans - 1].x - ComparePoints[trans - PointsSize.width - 1].x, ComparePoints[trans - 1].y - ComparePoints[trans - PointsSize.width - 1].y, 0, 50000);
			dFinalSlop += CalSlope(ComparePoints[trans + PointsSize.width - 1].x - ComparePoints[trans - 1].x, ComparePoints[trans + PointsSize.width - 1].y - ComparePoints[trans - 1].y, 0, 50000);
			dFinalSlop /= 12;
			break;
		case lb_Variance:

			result = CalFinalSlope(ComparePoints, PointsSize, dFinalSlop);
			if (result == false) return FALSE;
			break;

		default:
			result = CalFinalSlope(ComparePoints, PointsSize, dFinalSlop);
			if (result == false) return FALSE;
			break;
		}
		LOGD("DistortionCheck cal corners/circles slop success.");
		//cout << "dFinalSlop = " << dFinalSlop << endl;
		Size SquareSize(30, 30);
		double dSlope = dFinalSlop;
		vector<Point2d> InitPoints(PointsSize.width * PointsSize.height);	//����??��??��?��
		InitPoints.clear();
		for (int i = 0; i < PointsSize.height; i++)	//��?D��?����?3?��??������??��?����?��
		{
			for (int j = 0; j < PointsSize.width; j++)
			{
				Point2d temppoint;
				temppoint.x = j * SquareSize.width * cos((-1.0) * dSlope) - i * SquareSize.height * sin((-1.0) * dSlope);
				temppoint.y = j * SquareSize.width * sin((-1.0) * dSlope) + i * SquareSize.height * cos((-1.0) * dSlope);
				InitPoints.push_back(temppoint);
			}
		}
		double dScalex = 0;
		double dScaley = 0;
		result = CalScale(InitPoints, ComparePoints, PointsSize, dScalex, dScaley);
		if (result == false)
		{
			LOGE("DistortionCheck cal scale failed.");
			return FALSE;
		}
		LOGD("DistortionCheck cal scale success.");

		double dTransX = 0;
		double dTransY = 0;
		vector<double> vSlop;
		vector<Point2d> tempPoints;
		for (int i = 0; i < InitPoints.size(); i++)
		{
			tempPoints.push_back(Point2d((InitPoints[i].x) * dScalex, (InitPoints[i].y) * dScaley));
		}
		dTransX = tempPoints[trans].x - ComparePoints[trans].x;
		dTransY = tempPoints[trans].y - ComparePoints[trans].y;
		vector<Point2f> finalPoints;
		for (int i = 0; i < InitPoints.size(); i++)
		{
			finalPointsX[i] = tempPoints[i].x - dTransX;
			finalPointsY[i] = tempPoints[i].y - dTransY;
			finalPoints.push_back(Point2d(tempPoints[i].x - dTransX, tempPoints[i].y - dTransY));
		}
		int count = 0;
		double maxError = 0.;
		for (int i = 0; i != finalPoints.size(); i++)
		{
			double tempError = sqrt((finalPoints[i].x - ComparePoints[i].x) * (finalPoints[i].x - ComparePoints[i].x) + (finalPoints[i].y - ComparePoints[i].y) * (finalPoints[i].y - ComparePoints[i].y));
			if (tempError > maxError)
			{
				double d1, d2;
				maxError = tempError;
				maxErrorRatio = maxError / sqrt((ComparePoints[trans].x - finalPoints[i].x) * (ComparePoints[trans].x - finalPoints[i].x) + (ComparePoints[trans].y - finalPoints[i].y) * (ComparePoints[trans].y - finalPoints[i].y));
				d1 = sqrt((ComparePoints[trans].x - finalPoints[i].x) * (ComparePoints[trans].x - finalPoints[i].x) + (ComparePoints[trans].y - finalPoints[i].y) * (ComparePoints[trans].y - finalPoints[i].y));
				d2 = sqrt((ComparePoints[trans].x - ComparePoints[i].x) * (ComparePoints[trans].x - ComparePoints[i].x) + (ComparePoints[trans].y - ComparePoints[i].y) * (ComparePoints[trans].y - ComparePoints[i].y));
				count = i;
				if (d1 > d2)
				{
					maxErrorRatio = -maxErrorRatio;
				}
				else
				{
					maxErrorRatio = maxErrorRatio;
				}
			}
		}
		pointx = ComparePoints[count].x;
		pointy = ComparePoints[count].y;
		double reves = dFinalSlop * 57.3;
		if (reves < -90)
		{
			t = reves;
		}
		else if (reves > 90)
		{
			t = reves;
		}
		else
		{
			t = reves;
		}

		if (lType == SlopeOUT)
		{
			finalPoints.clear();
			for (int i = 0; i < PointsSize.height; i++)	//��?D��?����?3?��??������??��?����?��
			{
				for (int j = 0; j < PointsSize.width; j++)
				{
					Point2d temppoint;
					temppoint.x = j * SquareSize.width;
					temppoint.y = i * SquareSize.height;
					temppoint.x *= dScalex;
					temppoint.y *= dScaley;
					temppoint.x -= dTransX;
					temppoint.y -= dTransY;
					finalPoints.push_back(temppoint);
				}
			}
			for (int k = 0; k < InitPoints.size(); k++)
			{
				finalPointsX[k] = finalPoints[k].x;
				finalPointsY[k] = finalPoints[k].y;
			}
		}
		return TRUE;
	}
	if (dType == TVDistH)
	{
		float midDis = 0.;
		float leftDis = 0.;
		float rightDis = 0.;
		if (PointsSize.width % 2 == 0)
		{
			leftDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y));
			rightDis = sqrt((ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = 0.5 * sqrt((ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].x)
				* (ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].x)
				+ (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].y)
				* (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2].y))
				+
				0.5 * sqrt((ComparePoints[PointsSize.width / 2 - 1].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
					* (ComparePoints[PointsSize.width / 2 - 1].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
					+ (ComparePoints[PointsSize.width / 2 - 1].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y)
					* (ComparePoints[PointsSize.width / 2 - 1].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y));
		}
		else if (PointsSize.width % 2 == 1)
		{
			leftDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width * (PointsSize.height - 1)].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width * (PointsSize.height - 1)].y));
			rightDis = sqrt((ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[PointsSize.width - 1].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[PointsSize.width - 1].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = sqrt((ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
				* (ComparePoints[PointsSize.width / 2].x - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].x)
				+ (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y)
				* (ComparePoints[PointsSize.width / 2].y - ComparePoints[PointsSize.height * PointsSize.width - PointsSize.width / 2 - 1].y));
		}
		else
		{
			LOGE("DistortionCheck get WRONG board_size input.");
			return FALSE;
		}

		/*maxErrorRatio = 1.0 - (leftDis + rightDis) / (2 * midDis);*/
		maxErrorRatio = (leftDis + rightDis) / (2 * midDis) - 1.0;
		for (int i = 0; i < ComparePoints.size(); i++)
		{
			finalPointsX[i] = (float)ComparePoints[i].x;
			finalPointsY[i] = (float)ComparePoints[i].y;
		}
		return TRUE;
	}
	if (dType == TVDistV)
	{
		float upDis = 0.;
		float downDis = 0.;
		float midDis = 0.;
		if (PointsSize.height % 2 == 0)
		{
			upDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y));
			downDis = sqrt((ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = 0.5 * sqrt((ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				+ (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y))
				+
				0.5 * sqrt((ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].x - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].x)
					* (ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].x - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].x)
					+ (ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].y - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].y)
					* (ComparePoints[(PointsSize.height / 2 - 1) * PointsSize.width].y - ComparePoints[(PointsSize.height / 2) * PointsSize.width - 1].y));
		}
		else if (PointsSize.height % 2 == 1)
		{
			upDis = sqrt((ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				* (ComparePoints[0].x - ComparePoints[PointsSize.width - 1].x)
				+ (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y)
				* (ComparePoints[0].y - ComparePoints[PointsSize.width - 1].y));
			downDis = sqrt((ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].x - ComparePoints[PointsSize.width * PointsSize.height - 1].x)
				+ (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y)
				* (ComparePoints[(PointsSize.height - 1) * PointsSize.width].y - ComparePoints[PointsSize.width * PointsSize.height - 1].y));
			midDis = sqrt((ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].x - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].x)
				+ (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y)
				* (ComparePoints[(PointsSize.height / 2) * PointsSize.width].y - ComparePoints[(1 + PointsSize.height / 2) * PointsSize.width - 1].y));
		}
		else
		{
			LOGE("DistortionCheck get WRONG board_size input.");
			return FALSE;
		}

		/*maxErrorRatio = 1.0 - (upDis + downDis) / (2 * midDis);*/
		maxErrorRatio = (upDis + downDis) / (2 * midDis) - 1.0;

		for (int i = 0; i < ComparePoints.size(); i++)
		{
			finalPointsX[i] = (float)ComparePoints[i].x;
			finalPointsY[i] = (float)ComparePoints[i].y;
		}

		LOGD("DistortionCheck output data success.");
		return TRUE;
	}

	LOGE("DistortionCheck NOT choose the right Distortion-Check Type.");
	return FALSE;
}

/*
The function:LcaMeasure is cal the colour aberration between RGB channels.
	@param iImg input �����ͼƬ
	@param iSize input ����Ĵ���㼯SIZE(������X������)
	@param tBlobThreParams input ��ʹ��Բ����ʱ��Բ����ļ��ϵ��
	@param greenR output �������ɫͨ���Ľǵ���ԭ��İ뾶���鼯
	@param BG_diff output ���������ͨ���İ뾶�
	@param RB_diff output ����ĺ���ͨ���İ뾶�
	@param RG_diff output ����ĺ���ͨ���İ뾶�
	@param blueCornersX output �������ɫͨ���Ľǵ�X���꼯
	@param blueCornersY output �������ɫͨ���Ľǵ�Y���꼯
	@param greenCornersX output �������ɫͨ���Ľǵ�X���꼯
	@param greenCornersY output �������ɫͨ���Ľǵ�Y���꼯
	@param redCornersX output ����ĺ�ɫͨ���Ľǵ�X���꼯
	@param redCornersY output ����ĺ�ɫͨ���Ľǵ�Y���꼯
	@param type input ������ǵ�ķ�����Ĭ����Բ���ⷨ
*/
EXPORTC MYDLL BOOL STDCALL LcaMeasure(HImage iImg, ISIZE iSize, BlobThreParams tBlobThreParams, double* greenR, double* BG_diff, double* RB_diff, double* RG_diff, float* blueCornersX, float* blueCornersY, float* greenCornersX, float* greenCornersY, float* redCornersX, float* redCornersY, CornerType type /*= Circlepoint*/, bool exLCA /*= false*/)
{
	if (gIsOpen == false)
	{
		return FALSE;
	}
	if (exLCA == true)
	{
		return LcaExMeasure(iImg, iSize, tBlobThreParams, greenR, BG_diff, RB_diff, RG_diff, blueCornersX, blueCornersY, greenCornersX, greenCornersY, redCornersX, redCornersY, type);
	}
	int ntype = OpencvManager::Gettype(iImg.iBpp, iImg.iChls);

	Mat image(iImg.iHei, iImg.iWid, ntype, iImg.pData);
	if (image.channels() != 3)
	{
		LOGE("LcaMeasure Cal LCA need 3 channels!");
		//cout << "Cal LCA need 3 channels!" << endl;
		return FALSE;
	}

	Size board_size = Size(iSize.cx, iSize.cy);	//?2D???��D
	vector<Point2f> blueCorners(board_size.height * board_size.width);
	vector<Point2f> greenCorners(board_size.height * board_size.width);
	vector<Point2f> redCorners(board_size.height * board_size.width);
	vector<Mat> channels;

	split(image, channels);

	Mat tBlueImage = channels[0];
	Mat tGreenImage = channels[1];
	Mat tRedImage = channels[2];
	Mat blueImage;
	Mat greenImage;
	Mat redImage;

	if (tBlueImage.depth() != CV_8U)
	{
		tBlueImage.convertTo(blueImage, CV_8UC1, 1.0 / 256, 0);
	}
	if (tGreenImage.depth() != CV_8U)
	{
		tGreenImage.convertTo(greenImage, CV_8UC1, 1.0 / 256, 0);
	}
	if (tRedImage.depth() != CV_8U)
	{
		tRedImage.convertTo(redImage, CV_8UC1, 1.0 / 256, 0);
	}

	vector<Point2f> corners;
	LOGE("LcaMeasure split img into 3 channels!");


	switch (type)
	{
	case Circlepoint:
		if (false == getCirclesCorners(blueImage, board_size, blueCorners, tBlobThreParams))
		{
			LOGE("LcaMeasure get Circle blue_circles collected failed");
			//cout << "Circle blue_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle blue_corners collected success");
		}
		if (false == getCirclesCorners(greenImage, board_size, greenCorners, tBlobThreParams))
		{
			LOGE("LcaMeasure get Circle green_circles collected failed");
			//cout << "Circle green_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle green_circles collected success");
		}
		if (false == getCirclesCorners(redImage, board_size, redCorners, tBlobThreParams))
		{
			LOGE("LcaMeasure get Circle red_circles collected failed");
			//cout << "Circle red_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle red_circles collected success");
		}
		break;
	case Checkerboard:
		if (false == getBoardsCorners(blueImage, board_size, blueCorners))
		{
			LOGE("LcaMeasure get Checkboard blue_corners collected failed");
			//cout << "Checkboard blue_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle blue_corners collected success");
		}
		if (false == getBoardsCorners(greenImage, board_size, greenCorners))
		{
			LOGE("LcaMeasure get Checkboard green_corners collected failed");
			//cout << "Checkboard green_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle green_corners collected success");
		}
		if (false == getBoardsCorners(redImage, board_size, redCorners))
		{
			LOGE("LcaMeasure get Checkboard red_corners collected failed");
			//cout << "Checkboard red_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle red_corners collected success");
		}
		break;

	default:
		if (false == getCirclesCorners(blueImage, board_size, blueCorners, tBlobThreParams))
		{
			LOGE("LcaMeasure get Circle blue_circles collected failed");
			//cout << "Circle blue_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle blue_corners collected success");
		}
		if (false == getCirclesCorners(greenImage, board_size, greenCorners, tBlobThreParams))
		{
			LOGE("LcaMeasure get Circle green_circles collected failed");
			//cout << "Circle green_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle green_circles collected success");
		}
		if (false == getCirclesCorners(redImage, board_size, redCorners, tBlobThreParams))
		{
			LOGE("LcaMeasure get Circle red_circles collected failed");
			//cout << "Circle red_corners collected failed" << endl;
			return FALSE;
		}
		else
		{
			LOGD("LcaMeasure get Circle red_circles collected success");
		}
		break;
	}

	if (true != PointsMatching(greenCorners, blueCorners, redCorners, 30))	//��?��???��|��y�����̨���?��?��?��?o����??�̨�y��?????��???��?D��3��minDistBetweenBlobs��?20%
	{
		LOGE("LcaMeasure match 3 channels Circles failed.");
		return FALSE;
	}
	LOGD("LcaMeasure match 3 channels Circles success.");
	vector<double> BG_diff_dist(greenCorners.size());
	vector<double> RB_diff_dist(greenCorners.size());
	vector<double> RG_diff_dist(greenCorners.size());
	BG_diff_dist.clear();
	RB_diff_dist.clear();
	RG_diff_dist.clear();
	CalLCA(image, blueCorners, greenCorners, BG_diff_dist);//��Y?��?D��?��?D����a��?��???��|
	CalLCA(image, blueCorners, redCorners, RB_diff_dist);
	CalLCA(image, redCorners, greenCorners, RG_diff_dist);
	for (int i = 0; i < greenCorners.size(); i++)
	{
		double temp = 0.0;;
		temp = sqrt((greenCorners[i].x - image.cols / 2) * (greenCorners[i].x - image.cols / 2) + (greenCorners[i].y - image.rows / 2) * (greenCorners[i].y - image.rows / 2));
		greenR[i] = temp;
	}

	for (int i = 0; i < greenCorners.size(); ++i)
	{
		BG_diff[i] = BG_diff_dist[i];
		RB_diff[i] = RB_diff_dist[i];
		RG_diff[i] = RG_diff_dist[i];
		blueCornersX[i] = blueCorners[i].x;
		blueCornersY[i] = blueCorners[i].y;
		greenCornersX[i] = greenCorners[i].x;
		greenCornersY[i] = greenCorners[i].y;
		redCornersX[i] = redCorners[i].x;
		redCornersY[i] = redCorners[i].y;
	}
	LOGD("LcaMeasure output data success.");
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL LcaExMeasure(HImage iImg, ISIZE iSize, BlobThreParams tBlobThreParams, double* redR, double* BG_diff, double* RB_diff, double* RG_diff, float* blueCornersX, float* blueCornersY, float* greenCornersX, float* greenCornersY, float* redCornersX, float* redCornersY, CornerType type /*= Circlepoint*/)
{
	if (gIsOpen == false)
	{
		return FALSE;
	}
	if (type != Circlepoint)
	{
		LOGE("LCA_EX just support Circlepoint model. ");
		return FALSE;
	}
	int ntype = OpencvManager::Gettype(iImg.iBpp, iImg.iChls);

	Mat Opic(iImg.iHei, iImg.iWid, ntype, iImg.pData);
	if (Opic.channels() != 3)
	{
		LOGE("Cal LCA need 3 channels!");
		//cout << "Cal LCA need 3 channels!" << endl;
		return FALSE;
	}
	Size board_size = Size(iSize.cx, iSize.cy);
	vector<Mat> channels;
	split(Opic, channels);
	Mat blueImage = channels[0];
	Mat greenImage = channels[1];
	Mat redImage = channels[2];
	if (blueImage.depth() != CV_8U)
	{
		blueImage.convertTo(blueImage, CV_8UC1, 1.0 / 256, 0);
	}
	if (greenImage.depth() != CV_8U)
	{
		greenImage.convertTo(greenImage, CV_8UC1, 1.0 / 256, 0);
	}
	if (redImage.depth() != CV_8U)
	{
		redImage.convertTo(redImage, CV_8UC1, 1.0 / 256, 0);
	}

	vector<GridArray> sequentialGreenCenters;
	vector<Point2f> greenCenters;

	if (getCirclesCenters(greenImage, tBlobThreParams, greenCenters))
	{
		LOGD("LcaExMeasure get the green circles success.");
		bool result = sortCenters(greenCenters, board_size, sequentialGreenCenters);
		if (result == false)
		{
			LOGE("LcaExMeasure sort the green circles fail.");
			return FALSE;
		}
		else
		{
			LOGD("LcaExMeasure sort the blue circles success.");
		}
	}
	else
	{
		LOGE("LcaExMeasure get the green circles fail.");
		return FALSE;
	}
	vector<GridArray> sequentialBlueCenters;
	vector<Point2f> blueCenters;
	if (getCirclesCenters(blueImage, tBlobThreParams, blueCenters))
	{
		LOGD("LcaExMeasure get the blue circles success.");
		bool result = sortCenters(blueCenters, board_size, sequentialBlueCenters);
		if (result == false)
		{
			LOGE("LcaExMeasure sort the blue circles fail.");
			return FALSE;
		}
		else
		{
			LOGD("LcaExMeasure sort the blue circles success.");
		}
	}
	else
	{
		LOGE("LcaExMeasure get the blue circles fail.");
		return FALSE;
	}
	vector<GridArray> sequentialRedCenters;
	vector<Point2f> redCenters;
	if (getCirclesCenters(redImage, tBlobThreParams, redCenters))
	{
		LOGD("LcaExMeasure get the red circles success.");
		bool result = sortCenters(redCenters, board_size, sequentialRedCenters);
		if (result == false)
		{
			return FALSE;
		}
		else
		{
			LOGD("LcaExMeasure sort the red circles success.");
		}
	}
	else
	{
		LOGE("LcaExMeasure get the red circles fail.");
		return FALSE;
	}
	if (sequentialGreenCenters.size() > board_size.width * board_size.height || sequentialBlueCenters.size() > board_size.width * board_size.height || sequentialRedCenters.size() > board_size.width * board_size.height)
	{
		LOGE("Not get the right circle points. ");
		return FALSE;
	}

	vector<Point2f> blueCorners;
	vector<Point2f> greenCorners;
	vector<Point2f> redCorners;
	vector<bool> greenVec;
	for (int i = 0; i < board_size.height; i++)
	{
		for (int j = 0; j < board_size.width; j++)
		{
			for (int n = 0; n < sequentialGreenCenters.size(); n++)
			{
				if (sequentialGreenCenters[n].rows == i && sequentialGreenCenters[n].cols == j)
				{
					greenCorners.push_back(sequentialGreenCenters[n].point);
					greenVec.push_back(sequentialGreenCenters[n].exist);
					break;
				}
			}
		}
	}
	vector<bool> blueVec;
	for (int i = 0; i < board_size.height; i++)
	{
		for (int j = 0; j < board_size.width; j++)
		{
			for (int n = 0; n < sequentialBlueCenters.size(); n++)
			{
				if (sequentialBlueCenters[n].rows == i && sequentialBlueCenters[n].cols == j)
				{
					blueCorners.push_back(sequentialBlueCenters[n].point);
					blueVec.push_back(sequentialBlueCenters[n].exist);
					break;
				}
			}
		}
	}
	vector<bool> redVec;
	for (int i = 0; i < board_size.height; i++)
	{
		for (int j = 0; j < board_size.width; j++)
		{
			for (int n = 0; n < sequentialRedCenters.size(); n++)
			{
				if (sequentialRedCenters[n].rows == i && sequentialRedCenters[n].cols == j)
				{
					redCorners.push_back(sequentialRedCenters[n].point);
					redVec.push_back(sequentialRedCenters[n].exist);
					break;
				}
			}
		}
	}

	if (greenCorners.size() != redCorners.size() || greenCorners.size() != blueCorners.size())
	{
		LOGE("The ideal conners vectors have diff size.");
		//cout << "The ideal conners vectors have diff size." << endl;
		return FALSE;
	}
	Point2f center;
	center.x = Opic.cols / 2;
	center.y = Opic.rows / 2;
	vector<float> BG_diff_dist(greenCorners.size());
	vector<float> RB_diff_dist(greenCorners.size());
	vector<float> RG_diff_dist(greenCorners.size());
	CalEXLCA(center, blueCorners, greenCorners, BG_diff_dist);
	CalEXLCA(center, blueCorners, redCorners, RB_diff_dist);
	CalEXLCA(center, redCorners, greenCorners, RG_diff_dist);

	int nCount = 0;
	for (int i = 0; i < greenCorners.size(); i++)
	{
		if (redVec[i] == true && blueVec[i] == true && greenVec[i] == true)
		{
			float temp = 0.0;;
			temp = sqrt((greenCorners[i].x - Opic.cols / 2) * (greenCorners[i].x - Opic.cols / 2) + (greenCorners[i].y - Opic.rows / 2) * (greenCorners[i].y - Opic.rows / 2));
			redR[nCount] = (double)temp;
			nCount++;
		}
	}

	nCount = 0;
	for (int i = 0; i < greenCorners.size(); ++i)
	{
		if (redVec[i] == true && blueVec[i] == true && greenVec[i] == true)
		{
			BG_diff[nCount] = (double)BG_diff_dist[i];
			RB_diff[nCount] = (double)RB_diff_dist[i];
			RG_diff[nCount] = (double)RG_diff_dist[i];
			blueCornersX[nCount] = blueCorners[i].x;
			blueCornersY[nCount] = blueCorners[i].y;
			greenCornersX[nCount] = greenCorners[i].x;
			greenCornersY[nCount] = greenCorners[i].y;
			redCornersX[nCount] = redCorners[i].x;
			redCornersY[nCount] = redCorners[i].y;
			nCount++;
		}
	}

	LOGD("LcaExMeasure output data success.");
	return TRUE;
}

vector<vector<Point>> gCountContours_centreLineDetect;
EXPORTC MYDLL BOOL STDCALL centreLineDetect(HImage tImg, const int iThresh, const int minSize, const int minCentresSize, const int lineWidth, const int LENGTH, int& memSize, int& numArr, int* arr, int* dataX, int* dataY, bool ifDebug, bool useContrast, float threRatio, float contrastRatio, int blur_size)
{
	if (gIsOpen == false)
	{
		return FALSE;
	}

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat img = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);
	bool result = false;
	Mat src_img;
	if (useContrast == false)
	{
		src_img = img.clone();
		result = imgConvertTo8bit(src_img);
		if (!result) return FALSE;
		src_img = (src_img >= iThresh);
	}
	else
	{
		Mat greenImage;
		if (img.channels() == 3)
		{
			vector<Mat> channelsY;
			split(img, channelsY);
			greenImage = channelsY[1];
		}
		else
		{
			greenImage = img.clone();
		}
		resize(greenImage, greenImage, Size(0, 0), 0.5, 0.5, cv::INTER_LINEAR);
		GaussianBlur(greenImage, greenImage, Size(5, 5), 0);
		resize(greenImage, greenImage, Size(0, 0), 0.5, 0.5, cv::INTER_LINEAR);
		GaussianBlur(greenImage, greenImage, Size(3, 3), 0);
		resize(greenImage, greenImage, Size(0, 0), 4, 4, cv::INTER_LINEAR);
		double minVal = 0, maxVal = 0;
		minMaxIdx(greenImage, &minVal, &maxVal);
		if (blur_size <= 0)
		{
			blur_size = 2 * lineWidth * 1.732;
		}
		Mat ref, img_contrast;
		blur(greenImage, ref, cv::Size(blur_size, blur_size));
		img_contrast = Mat(greenImage.size(), CV_32FC1, Scalar(0));

		if (greenImage.type() == CV_16UC1)
		{
			uint16_t* img_ptr = greenImage.ptr<uint16_t>(0);
			uint16_t* ref_ptr = ref.ptr<uint16_t>(0);
			float* result_ptr = img_contrast.ptr<float>(0);
			for (int i = 0; i < greenImage.rows; i++)
			{
				img_ptr = greenImage.ptr<uint16_t>(i);
				ref_ptr = ref.ptr<uint16_t>(i);
				result_ptr = img_contrast.ptr<float>(i);
				for (int j = 0; j < greenImage.cols; j++)
				{
					if (ref_ptr[j] != 0)
					{
						if ((float)(img_ptr[j]) < (float)(threRatio * maxVal))
						{
							result_ptr[j] = 0;
						}
						else
						{
							result_ptr[j] = (float)((img_ptr[j] - ref_ptr[j]) / (float)(img_ptr[j] + ref_ptr[j]));
						}
					}
					else
						result_ptr[j] = 0;
				}
			}
		}

		else if (greenImage.type() == CV_32FC1)
		{
			float* img_ptr = greenImage.ptr<float>(0);
			float* ref_ptr = ref.ptr<float>(0);
			float* result_ptr = img_contrast.ptr<float>(0);
			for (int i = 0; i < greenImage.rows; i++)
			{
				img_ptr = greenImage.ptr<float>(i);
				ref_ptr = ref.ptr<float>(i);
				result_ptr = img_contrast.ptr<float>(i);
				for (int j = 0; j < greenImage.cols; j++)
				{
					if (ref_ptr[j] != 0)
					{
						if (img_ptr[j] < threRatio * maxVal)
						{
							result_ptr[j] = 0;
						}
						else
						{
							result_ptr[j] = (float)((img_ptr[j] - ref_ptr[j]) / (float)(img_ptr[j] + ref_ptr[j]));
						}
					}
					else
						result_ptr[j] = 0;
				}
			}
		}
		else
		{
			uint8_t* img_ptr = greenImage.ptr<uint8_t>(0);
			uint8_t* ref_ptr = ref.ptr<uint8_t>(0);
			float* result_ptr = img_contrast.ptr<float>(0);
			for (int i = 0; i < greenImage.rows; i++)
			{
				img_ptr = greenImage.ptr<uint8_t>(i);
				ref_ptr = ref.ptr<uint8_t>(i);
				result_ptr = img_contrast.ptr<float>(i);
				for (int j = 0; j < greenImage.cols; j++)
				{
					if (ref_ptr[j] != 0)
					{
						if ((float)(img_ptr[j]) < (float)(threRatio * maxVal))
						{
							result_ptr[j] = 0;
						}
						else
						{
							result_ptr[j] = (float)((img_ptr[j] - ref_ptr[j]) / (float)(img_ptr[j] + ref_ptr[j]));
						}
					}
					else
						result_ptr[j] = 0;
				}
			}
		}
		src_img = (img_contrast > (float)(contrastRatio));
	}
	if (ifDebug == true)
	{
		imwrite("CentreLineDebug.tif", src_img);
	}

	gCountContours_centreLineDetect.clear();
	findContours(src_img, gCountContours_centreLineDetect, RETR_LIST, CHAIN_APPROX_NONE);

	vector<vector<Point>> srcContours;
	if (gCountContours_centreLineDetect.size() == 0)
	{
		LOGE("centreLineDetect get None contours in this pic.");
		return FALSE;
	}
	LOGD("centreLineDetect get contours success.");
	int maxSize = gCountContours_centreLineDetect[0].size();

	//ɸѡ������minSize��contours
	for (int i = 0; i < gCountContours_centreLineDetect.size(); i++)
	{
		if (gCountContours_centreLineDetect[i].size() > minSize)
		{
			srcContours.push_back(gCountContours_centreLineDetect[i]);
		}
	}

	vector<vector<Point>> dstPoints;
	result = getContourCentres(src_img, lineWidth, LENGTH, minCentresSize, srcContours, dstPoints);

	if (result)
	{
		int totalSUM = 0;
		numArr = dstPoints.size();
		for (int i = 0; i < dstPoints.size(); i++)
		{
			arr[i] = dstPoints[i].size();
			totalSUM += dstPoints[i].size();
		}

		if (totalSUM <= memSize)
		{
			int k = 0;
			for (int m = 0; m < dstPoints.size(); m++)
			{
				vector<Point> temPoints = dstPoints[m];
				for (int n = 0; n < temPoints.size(); n++)
				{
					dataX[k] = temPoints[n].x;
					dataY[k] = temPoints[n].y;
					k++;
				}
			}
			LOGD("centreLineDetect output data success.");
			return TRUE;
		}
		else
		{
			memSize = totalSUM;
			LOGD("centreLineDetect get contours line centers success.");
			return FALSE;
		}

	}
	else
	{
		LOGD("centreLineDetect output data failed, not enough input memory.");
		return FALSE;
	}
}


vector<vector<Point>> contours_second_;
EXPORTC MYDLL BOOL STDCALL GhostGlareDectect_old(HImage tImg, const int radius, int pointsXnum, int pointsYnum, float ratioH, float ratioL, char* path, float* centersX, float* centersY, float* blobGray,
	float* dstGray, int& memSizeH, int& numArrH, int* arrH, int* dataH_X, int* dataH_Y, int& memSizeL, int& numArrL, int* arrL, int* dataL_X, int* dataL_Y) {
	if (gIsOpen == false) {
		return FALSE;
	}

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	cv::Mat image = cv::Mat(tImg.iHei, tImg.iWid, ntype, tImg.pData);
	if (true == image.empty()) {
		return FALSE;
	}

	Size cirSize(pointsXnum, pointsYnum);

	Mat typeImage;
	int imgType = 0;

	if (image.type() == CV_32FC1) {
		imgType = 2;
	}
	else {
		LOGE("Not support this img format.");
		cout << "Not support this img format: " << image.type();
		return FALSE;
	}

	Mat imageGray;
	if (image.channels() != 1) {
		cvtColor(image, imageGray, COLOR_BGR2GRAY);
	}
	else {
		imageGray = image.clone();
	}

	typeImage = imageGray.clone();
	if (imgType == 2) {
		normalize(imageGray, imageGray, 0, 255, NORM_MINMAX, CV_8UC1);
		LOGD("Ghost mode convert map format success.");
	}

	if (imageGray.type() != CV_8UC1) {
		imageGray.convertTo(imageGray, CV_8UC1, 1.0 / 256);
	}
	Mat varImage;
	varImage = imageGray.clone();
	int iTesh = OtsuAlgThreshold_Local(varImage);
	varImage = (varImage >= (iTesh));
	//imwrite(".\\ghost.tif", varImage);
	vector<vector<Point>> calContours;
	int dir = 0;

	SimpleBlobDetector::Params params;

	params.filterByColor = true;
	params.blobColor = 255;
	params.minThreshold = 200;
	params.thresholdStep = 10;
	params.maxThreshold = 255;
	params.minDistBetweenBlobs = 2.5 * radius;
	params.filterByArea = true;
	params.minArea = 1.5 * radius * radius;
	params.maxArea = 3 * radius * radius * 4;
	params.minRepeatability = 2;
	params.filterByCircularity = false;
	params.minCircularity = 0.5f;
	params.maxCircularity = (float)1e37;
	params.filterByConvexity = false;
	params.minConvexity = 0.9f;
	params.maxConvexity = (float)1e37;
	params.filterByInertia = false;
	params.minInertiaRatio = 0.1f;
	params.maxInertiaRatio = (float)1e37;

	vector<vector<Point>> contours_first;
	findContours(varImage, contours_first, RETR_CCOMP, CHAIN_APPROX_NONE, Point2f(0, 0));

	for (int i = 0; i < contours_first.size(); i++) {
		// LOG(INFO) << "contours size: " << contours_first[i].size();
		// LOG(INFO) << "radius: " << radius;
		if (contours_first[i].size() > cvRound(2 * radius) && contours_first[i].size() < cvRound(12 * radius)) {
			calContours.push_back(contours_first[i]);
		}
	}

	cout << "cal contours size: " << calContours.size();
	cout << "cirSize width: " << cirSize.width;
	cout << "cirSize height: " << cirSize.height;

	if (calContours.size() >= cvRound(2 * cirSize.width * cirSize.height)) {
		dir = 1;
	}
	else if (calContours.size() < cvRound(cirSize.width * cirSize.height)) {
		dir = -1;
	}
	else if (calContours.size() >= cvRound(cirSize.width * cirSize.height) &&
		calContours.size() < cvRound(2 * cirSize.width * cirSize.height)) {
		dir = 0;
	}
	else {
		return FALSE;
	}

	cout << "result dir: " << dir;

	int circleNUM = 0;
	vector<Point2f> circlePoints;
	vector<vector<Point>> paintContours;
	if (dir == 0) {
		paintContours.clear();
		Point center;
		varImage = imageGray.clone();
		for (int i = 0; i < calContours.size(); i++) {
			if (calContours[i].size() < cvRound(2 * radius) || calContours[i].size() < 10) {
				continue;
			}

			Moments mom;
			mom = moments(calContours[i]);
			center.x = cvRound(mom.m10 / mom.m00);
			center.y = cvRound(mom.m01 / mom.m00);
			Mat ROI;
			Rect rect(center.x - 2 * radius, center.y - 2 * radius, 4 * radius,
				4 * radius);
			if (center.x - 2 * radius <= 0) {
				rect.x = 1;
			}
			if (center.y - 2 * radius <= 0) {
				rect.y = 1;
			}
			if (center.x + 2 * radius > varImage.cols - 1) {
				rect.width = (int)((varImage.cols - 2 - center.x) / 2);
			}
			if (center.y + 2 * radius > varImage.rows - 1) {
				rect.height = (int)((varImage.rows - 2 - center.y) / 2);
			}
			ROI = varImage(rect);
			// ROI = varImage(Rect(center.x - 2 * radius, center.y - 2 * radius, 4 *
			// radius, 4 * radius));
			vector<Point> circlecPoints;
			if (checkRoiCircles(ROI, radius, circlecPoints)) {
				contoursCoordTrans(circlecPoints, Point(center.x - 2 * radius, center.y - 2 * radius));
				paintContours.push_back(circlecPoints);
				circleNUM++;
			}

		}
		varImage.release();
		Mat varMat(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));
		if (circleNUM >= cirSize.width * cirSize.height) {
			for (int i = 0; i < paintContours.size(); i++)
			{
				drawContours(varMat, paintContours, i, Scalar(255), -1, 8, noArray(), INT_MAX, Point());
			}

			//imwrite(".\\image_process.tif", varMat);

			/*
			std::vector<std::vector<cv::Point>> contours;
			std::vector<cv::Vec4i> heri;
			cv::findContours(varMat, contours, RETR_LIST, CHAIN_APPROX_NONE);
			for (size_t i = 0; i < contours.size(); i++) {
				double area = contourArea(contours[i]);
				if (area < 2000.0)
				{
					continue;
				}

				std::vector<cv::Point> points = contours[i];
				int size = points.size();
				cv::Mat data_pts = cv::Mat(size, 2, CV_64FC1);
				for (int i = 0; i < size; i++) {
					data_pts.at<double>(i, 0) = points[i].x;
					data_pts.at<double>(i, 1) = points[i].y;
				}
				cv::PCA pca_analyze(data_pts, cv::Mat(), cv::PCA::DATA_AS_ROW);
				cv::Point2f center =cv::Point2f((float)pca_analyze.mean.at<double>(0, 0),(float)pca_analyze.mean.at<double>(0, 1));
				circlePoints.emplace_back(center);
			}
			*/

			Ptr<SimpleBlobDetector> detector = SimpleBlobDetector::create(params);
			vector<KeyPoint> corners;
			detector->detect(varMat, corners);
			cout << "corners.size() :" << corners.size() << endl;

			/*
			bool result = findCirclesGrid(
				varMat, cirSize, circlePoints,
				CALIB_CB_SYMMETRIC_GRID | CALIB_CB_CLUSTERING, detector);
			varMat.release();
			if (!result) {
			  dir = -1;
			  // return FALSE;
			}
			*/
		}
		else {
			dir = -1;
			// return FALSE;
		}
	}
	else if (dir == 1) {
		int m = 0;
		for (int i = 1; i <= 5; i++) {
			varImage = imageGray.clone();
			int thres = iTesh;
			thres += 10 * i;
			if (thres >= 255) {
				LOGE("Not suitable threshold.");
				// cout << "Not suitable threshold." << endl;
				return FALSE;
			}
			else {
				Mat tempImage;
				tempImage = imageGray.clone();
				tempImage = (tempImage >= (thres));
				contours_second_.clear();
				findContours(tempImage, contours_second_, RETR_CCOMP, CHAIN_APPROX_NONE,
					Point2f(0, 0));
				int temCount = 0;
				for (int n = 0; n < contours_second_.size(); n++) {
					if (contours_second_[n].size() > 2 * radius) {
						temCount++;
					}
				}
				if (temCount >= cirSize.width * cirSize.height &&
					temCount < 2 * cirSize.width * cirSize.height) {
					paintContours.clear();
					Point center;
					for (int i = 0; i < contours_second_.size(); i++) {
						if (contours_second_[i].size() < cvRound(2 * radius) ||
							contours_second_[i].size() < 10)
							continue;
						Moments mom;
						mom = moments(contours_second_[i]);
						center.x = cvRound(mom.m10 / mom.m00);
						center.y = cvRound(mom.m01 / mom.m00);
						if ((center.x - 2 * radius <= 0) || (center.y - 2 * radius) <= 0 ||
							(center.x + 2 * radius >= imageGray.cols) ||
							(center.y + 2 * radius >= imageGray.cols - 1)) {
							continue;
						}
						Mat ROI;
						Rect rect(center.x - 2 * radius, center.y - 2 * radius, 4 * radius,
							4 * radius);
						if (center.x - 2 * radius <= 0) {
							rect.x = 1;
						}
						if (center.y - 2 * radius <= 0) {
							rect.y = 1;
						}
						if (center.x + 2 * radius > varImage.cols - 1) {
							rect.width = (int)((varImage.cols - 2 - center.x) / 2);
						}
						if (center.y + 2 * radius > varImage.rows - 1) {
							rect.height = (int)((varImage.rows - 2 - center.y) / 2);
						}
						ROI = varImage(rect).clone();
						// ROI = varImage(Rect(center.x - 2 * radius, center.y - 2 * radius,
						// 4 * radius, 4 * radius));
						vector<Point> circlecPoints;
						if (checkRoiCircles(ROI, radius, circlecPoints)) {
							contoursCoordTrans(circlecPoints, Point(center.x - 2 * radius,
								center.y - 2 * radius));
							paintContours.push_back(circlecPoints);
							circleNUM++;
						}
						else {
							continue;
						}
					}
					Mat varMat(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));
					if (circleNUM >= cirSize.width * cirSize.height) {
						for (int i = 0; i < paintContours.size(); i++) {
							drawContours(varMat, paintContours, i, Scalar(255), -1, 8,
								noArray(), INT_MAX, Point());
						}
						imwrite(".\\image_process.tif", varMat);

						/*
						std::vector<std::vector<cv::Point>> contours;
						std::vector<cv::Vec4i> heri;
						cv::findContours(varMat, contours, RETR_LIST, CHAIN_APPROX_NONE);
						for (size_t i = 0; i < contours.size(); i++) {
							double area = contourArea(contours[i]);
							if (area < 2000.0) continue;

							std::vector<cv::Point> points = contours[i];
							int size = points.size();
							cv::Mat data_pts = cv::Mat(size, 2, CV_64FC1);
							for (int i = 0; i < size; i++) {
								data_pts.at<double>(i, 0) = points[i].x;
								data_pts.at<double>(i, 1) = points[i].y;
							}
							cv::PCA pca_analyze(data_pts, cv::Mat(), cv::PCA::DATA_AS_ROW);
							cv::Point2f center =
								cv::Point2f((float)pca_analyze.mean.at<double>(0, 0),
									(float)pca_analyze.mean.at<double>(0, 1));
							circlePoints.emplace_back(center);
						}
						*/

						Ptr<SimpleBlobDetector> detector =
							SimpleBlobDetector::create(params);
						vector<KeyPoint> corners;
						detector->detect(varMat, corners);
						cout << "corners.size() :" << corners.size() << endl;

						/*
						bool result = findCirclesGrid(
							varMat, cirSize, circlePoints,
							CALIB_CB_SYMMETRIC_GRID | CALIB_CB_CLUSTERING, detector);
						*/

						/*
						if (!result) {
						  m++;
						  continue;
						} else {
						  break;
						}
						*/
					}
					else {
						tempImage.release();
						m++;
						continue;
					}

				}
				else {
					tempImage.release();
					m++;
					continue;
				}
			}
		}
		if (m >= 5) {
			LOGE("Not find the right circles.");
			// cout << "Not find the right circles." << endl;
			return FALSE;
		}
	}
	else if (dir == -1) {
		int m = 0;
		for (int i = 1; i <= 5; i++) {
			int thres = iTesh;
			thres -= 10 * i;
			varImage = imageGray.clone();
			if (thres <= 0) {
				LOGE("Not suitable threshold.");
				cout << "Not suitable threshold.";
				return FALSE;
			}
			else {
				Mat tempImage;
				tempImage = imageGray.clone();
				tempImage = (tempImage >= (thres));
				cout << "thres: " << thres;
				//cv::imwrite(".\\ghostTST.tif", tempImage);
				contours_second_.clear();
				findContours(tempImage, contours_second_, RETR_CCOMP, CHAIN_APPROX_NONE,
					Point2f(0, 0));
				cout << "contourrs_second_.size() = " << contours_second_.size();
				int temCount = 0;
				for (int n = 0; n < contours_second_.size(); n++) {
					if (contours_second_[n].size() > 2 * radius) {
						temCount++;
					}
				}

				cout << "tempCount: " << temCount;
				cout << "cirSize width: " << cirSize.width;
				cout << "cirSize height: " << cirSize.height;

				if (temCount >= cirSize.width * cirSize.height &&
					temCount < 2 * cirSize.width * cirSize.height) {
					cout << "CCCCCC: " << contours_second_.size();
					paintContours.clear();
					Point center;
					cv::Mat disp(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));
					for (int i = 0; i < contours_second_.size(); i++) {
						if (contours_second_[i].size() < cvRound(2 * radius) ||
							contours_second_[i].size() < 10)
							continue;
						Moments mom;
						mom = moments(contours_second_[i]);
						center.x = cvRound(mom.m10 / mom.m00);
						center.y = cvRound(mom.m01 / mom.m00);
						if ((center.x - 2 * radius <= 0) || (center.y - 2 * radius) <= 0 ||
							(center.x + 2 * radius >= imageGray.cols) ||
							(center.y + 2 * radius >= imageGray.cols - 1)) {
							continue;
						}
						Mat ROI;
						Rect rect(center.x - 2 * radius, center.y - 2 * radius, 4 * radius,
							4 * radius);
						if (center.x - 2 * radius <= 0) {
							rect.x = 1;
						}
						if (center.y - 2 * radius <= 0) {
							rect.y = 1;
						}
						if (center.x + 2 * radius > varImage.cols - 1) {
							rect.width = (int)((varImage.cols - 2 - center.x) / 2);
						}
						if (center.y + 2 * radius > varImage.rows - 1) {
							rect.height = (int)((varImage.rows - 2 - center.y) / 2);
						}
						ROI = varImage(rect);
						// cout << "1 = " << center.x - 2 * radius << endl;
						// cout << "2 = " << center.y - 2 * radius << endl;
						// ROI = varImage(Rect(center.x - 2 * radius, center.y - 2 * radius,
						// 4 * radius, 4 * radius));
						// imwrite(".\\ghost_roi_" + std::to_string(i) + ".tif", ROI);
						vector<Point> circlecPoints;
						if (checkRoiCircles(ROI, radius, circlecPoints)) {
							contoursCoordTrans(circlecPoints, Point(center.x - 2 * radius,
								center.y - 2 * radius));
							paintContours.push_back(circlecPoints);
							circleNUM++;
						}
						else {
							continue;
						}
					}
					if (circleNUM >= cirSize.width * cirSize.height) {
						for (int i = 0; i < paintContours.size(); i++) {
							drawContours(disp, paintContours, i, Scalar(255), -1, 8,
								noArray(), INT_MAX, Point());
						}
						imwrite(".\\image_process.png", disp);

						/*
						ds::DsRegion region;
						ds::DsGenRegionByBinary(disp, &region);

						std::vector<ds::DsRegion> regions;
						ds::Connection8(region, &regions);

						for (auto reg : regions) {
						  circlePoints.emplace_back(reg.Center());
						}
						*/

						std::vector<std::vector<cv::Point>> contours;
						std::vector<cv::Vec4i> heri;
						cv::findContours(disp, contours, RETR_LIST, CHAIN_APPROX_NONE);
						for (size_t i = 0; i < contours.size(); i++) {
							double area = contourArea(contours[i]);
							if (area < 2000.0) continue;

							std::vector<cv::Point> points = contours[i];
							int size = points.size();
							cv::Mat data_pts = cv::Mat(size, 2, CV_64FC1);
							for (int i = 0; i < size; i++) {
								data_pts.at<double>(i, 0) = points[i].x;
								data_pts.at<double>(i, 1) = points[i].y;
							}
							cv::PCA pca_analyze(data_pts, cv::Mat(), cv::PCA::DATA_AS_ROW);
							cv::Point2f center =
								cv::Point2f((float)pca_analyze.mean.at<double>(0, 0),
									(float)pca_analyze.mean.at<double>(0, 1));
							circlePoints.emplace_back(center);
						}

						/*
						Ptr<SimpleBlobDetector> detector =
							SimpleBlobDetector::create(params);
						vector<KeyPoint> corners;
						detector->detect(disp, corners);
						cout << "corners.size() : " << corners.size() << endl;
						cout << "WWWWWWWWWWWWWW : " << corners.size() << endl;
						*/

						/*
						bool result = findCirclesGrid(
							disp, cirSize, circlePoints,
							CALIB_CB_SYMMETRIC_GRID | CALIB_CB_CLUSTERING, detector);
						*/

						/*
						if (!result) {
						  m++;
						  continue;
						} else {
						  break;
						}
						*/
					}
					else {
						tempImage.release();
						m++;
						continue;
					}

				}
				else {
					cout << "DDDDDD";
					tempImage.release();
					m++;
					continue;
				}
			}
		}

		if (m >= 5) {
			LOGE("Not find the right circles.");
			cout << "Not find the right circles.";
			// cout << "Not find the right circles." << endl;
			return FALSE;
		}
	}

	LOGD("Ghost mode get the demand circles.");
	cout << "Ghost mode get the demand circles.";

	cout << "Circle points count: " << circlePoints.size();

	if (!calCornersPos(circlePoints))
	{
		return FALSE;
	}


	int stepWidth = abs(cvRound((circlePoints[3].x - circlePoints[4].x) - 20));
	int stepHeight = abs(cvRound((circlePoints[4].y - circlePoints[7].y) - 20));
	vector<float> rangeLum;
	vector<float> blobLum;

	vector<vector<Point>> dstCirclesH;
	vector<vector<Point>> dstCirclesL;
	Mat dst(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));
	for (int i = 0; i < circlePoints.size(); i++) {
		Mat temImg = imageGray.clone();
		Mat temTypeImg = typeImage.clone();
		vector<Point> dstPointsH;
		vector<vector<Point>> dstPointsL;
		float aveGray = 0;
		float baveGray = 0;
		Rect rect(cvRound(circlePoints[i].x - (stepWidth / 2)), cvRound(circlePoints[i].y - (stepHeight / 2)), stepWidth, stepHeight);
		if (circlePoints[i].x - (stepWidth / 2) <= 0) {
			rect.x = 1;
		}
		if (circlePoints[i].y - (stepHeight / 2) <= 0) {
			rect.y = 1;
		}
		if (circlePoints[i].x + stepWidth / 2 > image.cols - 1) {
			rect.width = (int)((image.cols - 2 - circlePoints[i].x) * 2);
		}
		if (circlePoints[i].y + stepHeight / 2 > image.rows - 1) {
			rect.height = (int)((image.rows - 2 - circlePoints[i].y) * 2);
		}
		// cout << "rect.x = " << rect.x << endl;
		// cout << "rect.y = " << rect.y << endl;
		// cout << "rect.width = " << rect.width << endl;
		// cout << "rect.height = " << rect.height << endl;
		Mat ROI = temImg(rect);
		Mat TypeROI = temTypeImg(rect);
		// imwrite("C:\\Users\\ColorVision\\Desktop\\tst8.tif", ROI);
		bool result = getRangeRoiPoints(ROI, TypeROI, imgType, radius, ratioH, ratioL, baveGray, aveGray, dstPointsH, dstPointsL);
		if (result) {
			rangeLum.push_back(aveGray);
			blobLum.push_back(baveGray);
			for (int j = 0; j < dstPointsH.size(); j++) {
				dstPointsH[j].x += cvRound(circlePoints[i].x - (stepWidth / 2));
				dstPointsH[j].y += cvRound(circlePoints[i].y - (stepHeight / 2));
			}
			for (int j = 0; j < dstPointsL.size(); j++) {
				vector<Point> temPointsL;
				temPointsL = dstPointsL[j];
				for (int n = 0; n < temPointsL.size(); n++) {
					temPointsL[n].x += cvRound(circlePoints[i].x - (stepWidth / 2));
					temPointsL[n].y += cvRound(circlePoints[i].y - (stepHeight / 2));
				}
				// dstPointsL[j].x += cvRound(circlePoints[i].x - (stepWidth / 2));
				// dstPointsL[j].y += cvRound(circlePoints[i].y - (stepHeight / 2));
				dstCirclesL.push_back(temPointsL);
			}
			dstCirclesH.push_back(dstPointsH);
		}
		else {
			return FALSE;
		}
		ROI.release();
		TypeROI.release();
		temImg.release();
		temTypeImg.release();
	}
	LOGD("Ghost mode run getRangeRoiPoints model success.");

	cout << "Ghost mode run getRangeRoiPoints model success.";

	// for (int i = 0; i < rangeLum.size(); i++)
	//{
	//	cout << "rangeLum[i] = " << rangeLum[i] << endl;
	//  dstGray[i] = rangeLum[i];
	//  blobGray[i] = blobLum[i];
	//}

	Mat mixImg = Mat::zeros(imageGray.rows, imageGray.cols, CV_8UC3);
	vector<Mat> channels;
	for (int i = 0; i < 3; i++) {
		channels.push_back(imageGray);
	}
	merge(channels, mixImg);
	for (int i = 0; i < cirSize.width * cirSize.height; i++) {
		drawContours(mixImg, dstCirclesH, i, Scalar(50, 255, 50), 1, LINE_8,
			noArray(), INT_MAX, Point());
	}
	for (int i = 0; i < dstCirclesL.size(); i++) {
		drawContours(mixImg, dstCirclesL, i, Scalar(50, 50, 255), 1, LINE_8,
			noArray(), INT_MAX, Point());
	}

	std::string outpath;
	stringstream stream;
	stream << path;
	outpath = stream.str();
	outpath += "ghost.tif";
	LOGFMTD("image input success the outpath is %s", outpath.c_str());
	//cout << "image outpath is result.tif";
	cv::imwrite(outpath, mixImg);
	LOGD("Ghost mode save img success.");

	bool result_H = true;
	if (1) {
		int totalSUM = 0;
		numArrH = dstCirclesH.size();
		for (int i = 0; i < dstCirclesH.size(); i++) {
			arrH[i] = dstCirclesH[i].size();
			totalSUM += dstCirclesH[i].size();
		}

		if (totalSUM <= memSizeH) {
			int k = 0;
			for (int m = 0; m < dstCirclesH.size(); m++) {
				vector<Point> temPoints = dstCirclesH[m];
				for (int n = 0; n < temPoints.size(); n++) {
					dataH_X[k] = temPoints[n].x;
					dataH_Y[k] = temPoints[n].y;
					k++;
				}
			}
		}
		else {
			memSizeH = totalSUM;
			result_H = false;
		}
	}

	bool result_L = true;
	if (1) {
		int totalSUM = 0;
		numArrL = dstCirclesL.size();
		for (int i = 0; i < dstCirclesL.size(); i++) {
			arrL[i] = dstCirclesL[i].size();
			totalSUM += dstCirclesL[i].size();
		}

		if (totalSUM <= memSizeL) {
			int k = 0;
			for (int m = 0; m < dstCirclesL.size(); m++) {
				vector<Point> temPoints = dstCirclesL[m];
				for (int n = 0; n < temPoints.size(); n++) {
					dataL_X[k] = temPoints[n].x;
					dataL_Y[k] = temPoints[n].y;
					k++;
				}
			}
		}
		else {
			memSizeL = totalSUM;
			result_L = false;
		}
	}
	if (result_H && result_L) {
		for (int i = 0; i < pointsXnum * pointsYnum; i++) {
			centersX[i] = circlePoints[i].x;
			centersY[i] = circlePoints[i].y;
			dstGray[i] = rangeLum[i];
			blobGray[i] = blobLum[i];
		}
		LOGD("Ghost mode output data success.");
		return TRUE;
	}
	else {
		LOGE("Ghost mode output data fail.");
		return FALSE;
	}
}



//��Ӱ����

BOOL GHOST_SUCCESS = FALSE;
int LED_NUM_X = 0;
int LED_NUM_Y = 0;

//LED�����������ģ�
vector<Point2f> circlePoints;

vector<float> GHOST_LUM;
vector<float> LED_LUM;
vector<vector<Point>> contours_first;
vector<vector<Point>> LED_contours;
vector<vector<Point>> Ghost_contours;
vector<vector<Point>> contours_second_qk;
EXPORTC MYDLL BOOL STDCALL GhostGlareDectect(HImage tImg, const int radius, int LedNums_X, int LedNums_Y, float ratioH, float ratioL, const char* path, int& allLedPixelsNummber, int& LED_Nummber, int& allGhostPixelsNummber, int& Ghost_Nummber) {
	/*if (gIsOpen == false) {
		LOGE("\ncamera is close,GhostGlareDectect FAIL!");
		GHOST_SUCCESS = FALSE;
		return FALSE;
	}*/

	int ntype = Gettype(tImg.iBpp, tImg.iChls);

	//Դͼ
	cv::Mat image(tImg.iHei, tImg.iWid, ntype, tImg.pData);

	if (true == image.empty()) {
		GHOST_SUCCESS = FALSE;
		return FALSE;
	}
	LED_NUM_X = LedNums_X;
	LED_NUM_Y = LedNums_Y;
	Size cirSize(LedNums_X, LedNums_Y);

	Mat typeImage;
	int imgType = 0;

	if (image.type() == CV_32FC1) {
		imgType = 2;
	}
	else {
		LOGE("Not support this img format.");
		cout << "Not support this img format: " << image.type();
		GHOST_SUCCESS = FALSE;
		return FALSE;
	}

	Mat imageGray;
	if (image.channels() != 1) {
		cvtColor(image, imageGray, COLOR_BGR2GRAY);
	}

	else {
		imageGray = image.clone();
	}

	typeImage = imageGray.clone();
	if (imgType == 2) {
		normalize(imageGray, imageGray, 0, 255, NORM_MINMAX, CV_8UC1);
		LOGD("Ghost mode convert map format success.");
	}

	if (imageGray.type() != CV_8UC1) {
		imageGray.convertTo(imageGray, CV_8UC1, 1.0 / 256);
	}

	Mat varImage;
	varImage = imageGray.clone();
	int iTesh = OtsuAlgThreshold_Local(varImage);
	varImage = (varImage >= (iTesh));
	//imwrite("TIFF\\varImage.tif", varImage);
	//


	contours_first.clear();
	findContours(varImage, contours_first, RETR_CCOMP, CHAIN_APPROX_NONE, Point2f(0, 0));

	vector<vector<Point>> calContours;
	for (int i = 0; i < contours_first.size(); i++) {

		//���ǡ����ȵ�ʱ���Լ��2*��*radius
		if (contours_first[i].size() > cvRound(2 * radius) && contours_first[i].size() < cvRound(12 * radius)) {
			calContours.push_back(contours_first[i]);
		}
	}

	cout << "cal contours size: " << calContours.size();
	cout << "cirSize width: " << cirSize.width;
	cout << "cirSize height: " << cirSize.height;

	int dealWay = -99;
	if (calContours.size() >= cvRound(2 * cirSize.width * cirSize.height)) {
		//����ҵ����������ڷ���㼰���Ӱ����
		dealWay = 1;
	}
	else if (calContours.size() < cvRound(cirSize.width * cirSize.height)) {
		//����ҵ�������С�ڷ����
		dealWay = -1;
	}
	else {
		//����ҵ����������ڷ���㵫С�ڷ����+��Ӱ����
		dealWay = 0;
	}


	cout << "result dir: " << dealWay;

	//�ܵ�����������LED������
	int circleNUM = 0;

	circlePoints.clear();
	vector<vector<Point>> paintContours;

	//���ҵ�����������Բ�ε�����ʱ
	if (dealWay == 0) {
		paintContours.clear();
		Point center;
		varImage = imageGray.clone();
		for (int i = 0; i < calContours.size(); i++) {
			//���˵�̫С���������˴���ǰ��pushʱ�������˴�����ERROR
			if (calContours[i].size() > cvRound(2 * radius) && calContours[i].size() > 10) {
				Moments mom;
				mom = moments(calContours[i]);
				center.x = cvRound(mom.m10 / mom.m00);
				center.y = cvRound(mom.m01 / mom.m00);

				Rect rect(center.x - 2 * radius, center.y - 2 * radius, 4 * radius, 4 * radius);

				if (center.x - 2 * radius <= 0) {
					rect.x = 1;
				}
				if (center.y - 2 * radius <= 0) {
					rect.y = 1;
				}
				if (center.x + 2 * radius > varImage.cols - 1) {
					rect.width = (int)((varImage.cols - 2 - center.x) / 2);
				}
				if (center.y + 2 * radius > varImage.rows - 1) {
					rect.height = (int)((varImage.rows - 2 - center.y) / 2);
				}
				Mat ROI;
				ROI = varImage(rect);

				vector<Point> circlecPoints;
				if (checkRoiCircles(ROI, radius, circlecPoints)) {
					contoursCoordTrans(circlecPoints, Point(center.x - 2 * radius, center.y - 2 * radius));
					paintContours.push_back(circlecPoints);
					circleNUM++;
				}
			}
		}

		varImage.release();

		//��ʼʱΪ��ͼ
		Mat varMat(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));

		//����ϸ���������ڵ���9��
		if (circleNUM >= cirSize.width * cirSize.height) {

			//��ԭʵ������
			drawContours(varMat, paintContours, -1, Scalar(255), -1, 8, noArray(), INT_MAX, Point());

			//imwrite(".\\image_process.tif", varMat);

			std::vector<std::vector<cv::Point>> contours;
			std::vector<cv::Vec4i> heri;
			cv::findContours(varMat, contours, RETR_LIST, CHAIN_APPROX_NONE);
			for (size_t i = 0; i < contours.size(); i++) {
				double area = contourArea(contours[i]);
				//��ͬ��Ӱ�˴�������Ҫ����
				if (area > 1400.0)
				{
					std::vector<cv::Point> pointsContours = contours[i];
					int size = pointsContours.size();
					cv::Mat data_pts = cv::Mat(size, 2, CV_64FC1);
					for (int i = 0; i < size; i++) {
						data_pts.at<double>(i, 0) = pointsContours[i].x;
						data_pts.at<double>(i, 1) = pointsContours[i].y;
					}
					cv::PCA pca_analyze(data_pts, cv::Mat(), cv::PCA::DATA_AS_ROW);
					cv::Point2f center = cv::Point2f((float)pca_analyze.mean.at<double>(0, 0), (float)pca_analyze.mean.at<double>(0, 1));
					circlePoints.emplace_back(center);
				}
			}
			varMat.release();
		}
		else {
			dealWay = -1;
			// return FALSE;
		}
	}

	//��������Զ����2������

	if (dealWay == 1) {
		int m = 0;
		for (int i = 1; i <= 5; i++) {
			varImage = imageGray.clone();
			int thres = iTesh;
			thres += 10 * i;
			if (thres >= 255) {
				LOGE("Not suitable threshold.");
				// cout << "Not suitable threshold." << endl;
				GHOST_SUCCESS = FALSE;
				return FALSE;
			}

			Mat tempImage;
			tempImage = imageGray.clone();
			tempImage = (tempImage >= (thres));
			contours_second_qk.clear();
			findContours(tempImage, contours_second_qk, RETR_CCOMP, CHAIN_APPROX_NONE, Point2f(0, 0));
			int temCount = 0;

			//����ÿ��������������ɸѡ��������������������
			for (int n = 0; n < contours_second_qk.size(); n++) {
				if (contours_second_qk[n].size() > 2 * radius) {
					temCount++;
				}
			}

			if (temCount >= cirSize.width * cirSize.height && temCount < 2 * cirSize.width * cirSize.height) {
				paintContours.clear();
				Point center;
				for (int i = 0; i < contours_second_qk.size(); i++) {

					//���ĳ��������̫�٣�ֱ������
					if (contours_second_qk[i].size() < cvRound(2 * radius) || contours_second_qk[i].size() < 10) {
						continue;
					}

					Moments mom;
					mom = moments(contours_second_qk[i]);
					center.x = cvRound(mom.m10 / mom.m00);
					center.y = cvRound(mom.m01 / mom.m00);
					if ((center.x - 2 * radius <= 0) || (center.y - 2 * radius) <= 0 ||
						(center.x + 2 * radius >= imageGray.cols) ||
						(center.y + 2 * radius >= imageGray.cols - 1)) {
						continue;
					}
					Mat ROI;
					Rect rect(center.x - 2 * radius, center.y - 2 * radius, 4 * radius,
						4 * radius);
					if (center.x - 2 * radius <= 0) {
						rect.x = 1;
					}
					if (center.y - 2 * radius <= 0) {
						rect.y = 1;
					}
					if (center.x + 2 * radius > varImage.cols - 1) {
						rect.width = (int)((varImage.cols - 2 - center.x) / 2);
					}
					if (center.y + 2 * radius > varImage.rows - 1) {
						rect.height = (int)((varImage.rows - 2 - center.y) / 2);
					}
					ROI = varImage(rect).clone();
					// ROI = varImage(Rect(center.x - 2 * radius, center.y - 2 * radius,
					// 4 * radius, 4 * radius));
					vector<Point> circlecPoints;
					if (checkRoiCircles(ROI, radius, circlecPoints)) {
						contoursCoordTrans(circlecPoints, Point(center.x - 2 * radius, center.y - 2 * radius));
						paintContours.push_back(circlecPoints);
						circleNUM++;
						Mat varMat(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));
						if (circleNUM >= cirSize.width * cirSize.height) {
							for (int i = 0; i < paintContours.size(); i++) {
								drawContours(varMat, paintContours, i, Scalar(255), -1, 8, noArray(), INT_MAX, Point());
							}
							//imwrite(".\\image_process.tif", varMat);

							std::vector<std::vector<cv::Point>> contours;
							std::vector<cv::Vec4i> heri;
							cv::findContours(varMat, contours, RETR_LIST, CHAIN_APPROX_NONE);
							for (size_t i = 0; i < contours.size(); i++) {
								double area = contourArea(contours[i]);
								if (area < 2000.0) continue;

								std::vector<cv::Point> points = contours[i];
								int size = points.size();
								cv::Mat data_pts = cv::Mat(size, 2, CV_64FC1);
								for (int i = 0; i < size; i++) {
									data_pts.at<double>(i, 0) = points[i].x;
									data_pts.at<double>(i, 1) = points[i].y;
								}
								cv::PCA pca_analyze(data_pts, cv::Mat(), cv::PCA::DATA_AS_ROW);
								cv::Point2f center = cv::Point2f((float)pca_analyze.mean.at<double>(0, 0), (float)pca_analyze.mean.at<double>(0, 1));
								circlePoints.emplace_back(center);

							}
							tempImage.release();
							break;
						}
						else {
							tempImage.release();
							m++;
							continue;
						}
					}
				}
			}
			else {
				tempImage.release();
				m++;
				continue;
			}
			//}
		}
		if (m >= 5) {
			LOGE("Not find the right circles.");
			// cout << "Not find the right circles." << endl;
			GHOST_SUCCESS = FALSE;
			return FALSE;
		}
	}


	if (dealWay == -1) {

		int m = 0;
		for (int i = 1; i <= 5; i++) {
			int thres = iTesh;
			thres -= 10 * i;
			varImage = imageGray.clone();

			if (thres <= 0) {
				LOGE("Not suitable threshold.");
				cout << "Not suitable threshold.";
				GHOST_SUCCESS = FALSE;
				return FALSE;
			}

			Mat tempImage;
			tempImage = imageGray.clone();
			tempImage = (tempImage >= (thres));
			cout << "thres: " << thres;
			//cv::imwrite(".\\ghostTST.tif", tempImage);
			contours_second_qk.clear();
			findContours(tempImage, contours_second_qk, RETR_CCOMP, CHAIN_APPROX_NONE, Point2f(0, 0));
			cout << "contourrs_second_.size() = " << contours_second_qk.size();
			int temCount = 0;
			for (int n = 0; n < contours_second_qk.size(); n++) {
				if (contours_second_qk[n].size() > 2 * radius) {
					temCount++;
				}
			}

			cout << "tempCount: " << temCount;
			cout << "cirSize width: " << cirSize.width;
			cout << "cirSize height: " << cirSize.height;

			if (temCount >= cirSize.width * cirSize.height && temCount < 2 * cirSize.width * cirSize.height) {
				cout << "CCCCCC: " << contours_second_qk.size();
				paintContours.clear();
				Point center;
				cv::Mat disp(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));
				for (int i = 0; i < contours_second_qk.size(); i++) {
					if (contours_second_qk[i].size() > cvRound(2 * radius) && contours_second_qk[i].size() > 10) {
						Moments mom;
						mom = moments(contours_second_qk[i]);
						center.x = cvRound(mom.m10 / mom.m00);
						center.y = cvRound(mom.m01 / mom.m00);
						if ((center.x - 2 * radius <= 0) || (center.y - 2 * radius) <= 0 ||
							(center.x + 2 * radius >= imageGray.cols) ||
							(center.y + 2 * radius >= imageGray.cols - 1)) {
							continue;
						}
						Mat ROI;
						Rect rect(center.x - 2 * radius, center.y - 2 * radius, 4 * radius,
							4 * radius);
						if (center.x - 2 * radius <= 0) {
							rect.x = 1;
						}
						if (center.y - 2 * radius <= 0) {
							rect.y = 1;
						}
						if (center.x + 2 * radius > varImage.cols - 1) {
							rect.width = (int)((varImage.cols - 2 - center.x) / 2);
						}
						if (center.y + 2 * radius > varImage.rows - 1) {
							rect.height = (int)((varImage.rows - 2 - center.y) / 2);
						}
						ROI = varImage(rect);

						// imwrite(".\\ghost_roi_" + std::to_string(i) + ".tif", ROI);
						vector<Point> circlecPoints;
						if (checkRoiCircles(ROI, radius, circlecPoints)) {
							contoursCoordTrans(circlecPoints, Point(center.x - 2 * radius,
								center.y - 2 * radius));
							paintContours.push_back(circlecPoints);
							circleNUM++;
						}
					}
				}
				if (circleNUM >= cirSize.width * cirSize.height) {

					drawContours(disp, paintContours, -1, Scalar(255), -1, 8, noArray(), INT_MAX, Point());

					//imwrite(".\\image_process.png", disp);						
					std::vector<std::vector<cv::Point>> contours;
					std::vector<cv::Vec4i> heri;
					cv::findContours(disp, contours, RETR_LIST, CHAIN_APPROX_NONE);
					for (size_t i = 0; i < contours.size(); i++) {
						double area = contourArea(contours[i]);
						if (area > 2000.0) {
							std::vector<cv::Point> points = contours[i];
							int size = points.size();
							cv::Mat data_pts = cv::Mat(size, 2, CV_64FC1);
							for (int i = 0; i < size; i++) {
								data_pts.at<double>(i, 0) = points[i].x;
								data_pts.at<double>(i, 1) = points[i].y;
							}
							cv::PCA pca_analyze(data_pts, cv::Mat(), cv::PCA::DATA_AS_ROW);
							cv::Point2f center = cv::Point2f((float)pca_analyze.mean.at<double>(0, 0), (float)pca_analyze.mean.at<double>(0, 1));
							circlePoints.emplace_back(center);

						}
					}
					tempImage.release();
					break;
				}
				else {
					tempImage.release();
					m++;
					continue;
				}

			}
			else {
				cout << "DDDDDD";
				tempImage.release();
				m++;
				continue;
			}

		}

		if (m >= 5) {
			LOGE("Not find the right circles.");
			cout << "Not find the right circles.";
			// cout << "Not find the right circles." << endl;
			GHOST_SUCCESS = FALSE;
			return FALSE;
		}
	}

	//LOGD("Ghost mode get the demand circles.");
	cout << "Ghost mode get the demand circles.";

	cout << "Circle points count: " << circlePoints.size();

	if (!calCornersPos(circlePoints))
	{
		GHOST_SUCCESS = FALSE;
		return FALSE;
	}


	int stepWidth = abs(cvRound((circlePoints[3].x - circlePoints[4].x) - 20));
	int stepHeight = abs(cvRound((circlePoints[4].y - circlePoints[7].y) - 20));

	Mat dst(imageGray.rows, imageGray.cols, CV_8UC1, Scalar(0));

	GHOST_LUM.clear();
	LED_LUM.clear();
	LED_contours.clear();
	Ghost_contours.clear();
	for (int i = 0; i < circlePoints.size(); i++) {
		Mat temImg = imageGray.clone();
		Mat temTypeImg = typeImage.clone();
		vector<Point> dstPointsH;
		vector<vector<Point>> dstPointsL;
		float aveGray = 0;
		float baveGray = 0;
		Rect rect(cvRound(circlePoints[i].x - (stepWidth / 2)), cvRound(circlePoints[i].y - (stepHeight / 2)), stepWidth, stepHeight);
		if (circlePoints[i].x - (stepWidth / 2) <= 0) {
			rect.x = 1;
		}
		if (circlePoints[i].y - (stepHeight / 2) <= 0) {
			rect.y = 1;
		}
		if (circlePoints[i].x + stepWidth / 2 > image.cols - 1) {
			rect.width = (int)((image.cols - 2 - circlePoints[i].x) * 2);
		}
		if (circlePoints[i].y + stepHeight / 2 > image.rows - 1) {
			rect.height = (int)((image.rows - 2 - circlePoints[i].y) * 2);
		}
		// cout << "rect.x = " << rect.x << endl;
		// cout << "rect.y = " << rect.y << endl;
		// cout << "rect.width = " << rect.width << endl;
		// cout << "rect.height = " << rect.height << endl;
		Mat ROI = temImg(rect);
		Mat TypeROI = temTypeImg(rect);

		bool result = getRangeRoiPoints(ROI, TypeROI, imgType, radius, ratioH, ratioL, baveGray, aveGray, dstPointsH, dstPointsL);
		if (result) {
			LED_LUM.push_back(aveGray);
			GHOST_LUM.push_back(baveGray);
			for (int j = 0; j < dstPointsH.size(); j++) {
				dstPointsH[j].x += cvRound(circlePoints[i].x - (stepWidth / 2));
				dstPointsH[j].y += cvRound(circlePoints[i].y - (stepHeight / 2));
			}
			for (int j = 0; j < dstPointsL.size(); j++) {
				vector<Point> temPointsL;
				temPointsL = dstPointsL[j];
				for (int n = 0; n < temPointsL.size(); n++) {
					temPointsL[n].x += cvRound(circlePoints[i].x - (stepWidth / 2));
					temPointsL[n].y += cvRound(circlePoints[i].y - (stepHeight / 2));
				}
				// dstPointsL[j].x += cvRound(circlePoints[i].x - (stepWidth / 2));
				// dstPointsL[j].y += cvRound(circlePoints[i].y - (stepHeight / 2));
				Ghost_contours.push_back(temPointsL);
			}
			LED_contours.push_back(dstPointsH);
		}
		else {
			GHOST_SUCCESS = FALSE;
			return FALSE;
		}
		ROI.release();
		TypeROI.release();
		temImg.release();
		temTypeImg.release();
	}
	LOGD("Ghost mode run getRangeRoiPoints model success.");

	std::cout << "Ghost mode run getRangeRoiPoints model success.";



	Mat mixImg = Mat::zeros(imageGray.rows, imageGray.cols, CV_8UC3);
	vector<Mat> channels;
	for (int i = 0; i < 3; i++) {
		channels.push_back(imageGray);
	}
	merge(channels, mixImg);
	for (int i = 0; i < cirSize.width * cirSize.height; i++) {
		drawContours(mixImg, LED_contours, i, Scalar(50, 255, 50), 1, LINE_8, noArray(), INT_MAX, Point());
	}

	drawContours(mixImg, Ghost_contours, -1, Scalar(50, 50, 255), 1, LINE_8, noArray(), INT_MAX, Point());


	std::string outpath;
	stringstream stream;
	stream << path;
	outpath = stream.str();
	outpath += "ghost.tif";
	LOGFMTD("image input success the outpath is %s", outpath.c_str());
	//cout << "image outpath is result.tif";
	cv::imwrite(outpath, mixImg);

	int totalSUM = 0;
	LED_Nummber = LED_contours.size();
	for (int i = 0; i < LED_contours.size(); i++) {

		totalSUM += LED_contours[i].size();
	}


	allLedPixelsNummber = totalSUM;

	totalSUM = 0;
	Ghost_Nummber = Ghost_contours.size();
	for (int i = 0; i < Ghost_contours.size(); i++) {

		totalSUM += Ghost_contours[i].size();
	}


	allGhostPixelsNummber = totalSUM;
	GHOST_SUCCESS = TRUE;
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL getGhostResult(float* LedCenters_X, float* LedCenters_Y, float* LedAverageGray, float* ghostAverageGray, int* singleLedPixelNum, int* LED_pixel_X, int* LED_pixel_Y
	, int* singleGhostPixelNum, int* Ghost_pixel_X, int* Ghost_pixel_Y)
{
	if (GHOST_SUCCESS == FALSE)
	{
		return FALSE;
	}
	for (int i = 0; i < LED_NUM_X * LED_NUM_Y; i++)
	{
		LedCenters_X[i] = circlePoints[i].x;
		LedCenters_Y[i] = circlePoints[i].y;
		LedAverageGray[i] = GHOST_LUM[i];
		ghostAverageGray[i] = LED_LUM[i];
	}

	for (int i = 0; i < LED_contours.size(); i++) {
		singleLedPixelNum[i] = LED_contours[i].size();
	}

	int index = 0;
	for (int m = 0; m < LED_contours.size(); m++)
	{
		for (int n = 0; n < LED_contours[m].size(); n++) {
			LED_pixel_X[index] = LED_contours[m][n].x;
			LED_pixel_Y[index] = LED_contours[m][n].y;
			index++;
		}
	}

	for (int i = 0; i < Ghost_contours.size(); i++) {
		singleGhostPixelNum[i] = Ghost_contours[i].size();
	}

	index = 0;
	for (int m = 0; m < Ghost_contours.size(); m++)
	{
		for (int n = 0; n < Ghost_contours[m].size(); n++) {
			Ghost_pixel_X[index] = Ghost_contours[m][n].x;
			Ghost_pixel_Y[index] = Ghost_contours[m][n].y;
			index++;
		}
	}

	return TRUE;
}

Point2d cen(Mat Img)
{
	int allPointValue = 0;
	int xAllPointValue = 0;
	int yAllPointValue = 0;
	Point2d point;

	for (int i = 0; i < Img.rows; i++)
	{
		for (int j = 0; j < Img.cols; j++)
		{
			if (Img.at<uchar>(i, j) >= 2)
				allPointValue += Img.at<uchar>(i, j);
		}
	}
	for (int i = 0; i < Img.rows; i++)
	{
		for (int j = 0; j < Img.cols; j++)
		{
			if (Img.at<uchar>(i, j) >= 2)
			{
				xAllPointValue = xAllPointValue + Img.at<uchar>(i, j) * j;
				yAllPointValue = yAllPointValue + Img.at<uchar>(i, j) * i;
			}
		}
	}

	if (allPointValue > 0) {
		point.x = static_cast<double>(xAllPointValue) / allPointValue;
		point.y = static_cast<double>(yAllPointValue) / allPointValue;
	}
	else {
		point.x = 0;
		point.y = 0;
	}

	return point;
}

EXPORTC MYDLL BOOL STDCALL forPoint(uint8_t* inputim, int* xPos, int* yPos, int h, int w, int nbpp, int nChannels, int method, int& pointNumber, int pointDistance, int  startPosition, int binaryPercentage)
{
	if (nChannels != 3)
		return FALSE;

	int ntype = Gettype(nbpp, nChannels);

	cv::Mat img = cv::Mat(h, w, ntype, inputim);

	cv::Mat dst;

	dst = MatToCImage(img);							// ��������8λ�����ܶ���λ��ȥ

	vector<Point2i> result;

	vector<Mat> vchannels;
	split(dst, vchannels);

	Mat blue, green, red;
	blue = vchannels.at(0);
	green = vchannels.at(1);
	red = vchannels.at(2);

	Mat mc1, mc2, mc3, mc4, sc1, sc2, sc3, sc4;
	meanStdDev(blue, mc1, sc1);
	meanStdDev(green, mc2, sc2);
	meanStdDev(red, mc3, sc3);

	double meanc1 = mc1.at<double_t>(0, 0);
	double meanc2 = mc2.at<double_t>(0, 0);
	double meanc3 = mc3.at<double_t>(0, 0);
	double stdc1 = sc1.at<double_t>(0, 0);
	double stdc2 = sc2.at<double_t>(0, 0);
	double stdc3 = sc3.at<double_t>(0, 0);

	double bluecontrast, greencontrast, redcontrast;
	bluecontrast = stdc1 / meanc1;
	greencontrast = stdc2 / meanc2;
	redcontrast = stdc3 / meanc3;

	double thresh;
	double mm = max(max(bluecontrast, greencontrast), redcontrast);

	Mat ms;
	if (mm == bluecontrast)
	{
		ms = blue;
		thresh = meanc1 * binaryPercentage;
	}
	else if (mm == greencontrast)
	{
		ms = green;
		thresh = meanc2 * binaryPercentage;
	}
	else
	{
		ms = red;
		thresh = meanc3 * binaryPercentage;
	}

	Mat gms;
	cv::GaussianBlur(ms, gms, Size(9, 9), 2, 2);

	Mat binim;
	cv::threshold(gms, binim, thresh, 65536, THRESH_BINARY);

	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	cv::findContours(binim, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point());
	Rect rectAll = boundingRect(Mat(contours[0]));

	if (method == 0)
	{
		//�̶�����
		double tt = sqrt(rectAll.width * rectAll.width + rectAll.height * rectAll.height) - startPosition;
		int pointInterval = tt / (pointNumber - 1);
		int sx, sy, ch, cw;

		ch = rectAll.height + 20;
		cw = pointInterval + 20;
		sx = rectAll.x + cw - 10;
		sy = rectAll.y - 10;

		Rect rect(sx, sy, cw, ch);
		Mat tempImg = ms(rect);
		Point2d p = cen(tempImg);
		int px = p.x + sx;
		int py = p.y + sy;
		result.push_back(Point2i(px, py));

		binim.at<uint8_t>(result[0].y, result[0].x) = 0;

		for (int i = 1; i < pointNumber; i++)
		{
			sx = result[i - 1].x + cw / 2;
			sy = result[i - 1].y - ch / 2;

			Rect rect(sx, sy, cw, ch);
			tempImg = ms(rect);
			p = cen(tempImg);

			double dx = result[i - 1].x - p.x - sx;
			double dy = result[i - 1].y - p.y - sy;
			double d = sqrt(dx * dx + dy * dy);
			int tempx = -pointInterval / d * dx + result[i - 1].x;
			int tempy = -pointInterval / d * dy + result[i - 1].y;

			result.push_back(Point2i(tempx, tempy));

			binim.at<uint8_t>(result[i].y, result[i].x) = 0;
		}
		waitKey(0);

	}
	else
	{
		//�̶����
		int pointInterval = pointDistance;
		int sx, sy, ch, cw;

		ch = rectAll.height + 20;
		cw = pointInterval + 20;
		sx = rectAll.x + startPosition - 10;
		sy = rectAll.y - 10;

		Rect rect(sx, sy, cw, ch);
		Mat tempImg = ms(rect);
		Point2d p = cen(tempImg);
		int px = p.x + sx;
		int py = p.y + sy;
		result.push_back(Point2i(px, py));

		binim.at<uint8_t>(result[0].y, result[0].x) = 0;

		int i = 1;
		sx = result[i - 1].x + cw / 2;
		sy = result[i - 1].y - ch / 2;

		int ep = sx + cw;
		int lp = rectAll.x + rectAll.width;

		while (ep < lp)
		{
			Rect rect(sx, sy, cw, ch);
			tempImg = ms(rect);
			p = cen(tempImg);

			double dx = result[i - 1].x - p.x - sx;
			double dy = result[i - 1].y - p.y - sy;
			double d = sqrt(dx * dx + dy * dy);
			int tempx = -pointInterval / d * dx + result[i - 1].x;
			int tempy = -pointInterval / d * dy + result[i - 1].y;

			result.push_back(Point2i(tempx, tempy));

			binim.at<uint8_t>(result[i].y, result[i].x) = 0;

			sx = result[i].x + cw / 2;
			sy = result[i].y - ch / 2;

			i = i + 1;
			ep = sx + cw;
		}
		waitKey(0);
	}

	int nCount = pointNumber < result.size() ? pointNumber : result.size();

	for (int i(0); i < nCount; i++)
	{
		xPos[i] = result[i].x;
		yPos[i] = result[i].y;
	}
	pointNumber = nCount;
	return TRUE;
}

EXPORTC MYDLL BOOL STDCALL ZBDebayer(int w, int h, int bpp, int channels, uint8_t* psrcData, uint8_t* pdstData, int nMethod, int nChanneltype)
{
	bool bRet = DataAnalyzer::ZBDebayer(w, h, bpp, channels, psrcData, pdstData, nMethod, nChanneltype);

	return bRet == true ? CV_ERR_SUCCESS : CV_ERR_FAIL;
}

/**
* resolution_x ,resolution_y ,DUT ���طֱ���
* int mode ,mode=0 ��������bin��ʽ1 ��mode=1,��������bin��ʽ2
*                  ��1��bin�ļ�����ԭʼ������Ϣ��һ����0-255����ǰ��������/������� * 255���������ַ05_00_00��09_af_ff�� ��327680�� 634879
*                  ��2��bin�ļ�����ԭʼ������Ϣ��һ����0-255��(��ǰ��������-��С����)/������� * 255���������ַ05_00_00��09_af_ff��
*                                  ���ҽ� ��С����/������� * 255 ��Ϊdemura������¼ ,������ȡ���С����ѡȡ����ֵ��������
* maxlvRatio��minLvRatio ֻ����ģʽ1ʱ��Ч�� ת��bin�ļ�ʱ ���ֵ����Сֵ�������ű��� ,�ٷֱ�ֵ
* tifFilePath  tif�ļ�·��
* binFilePath  ����bin�ļ�·��
*/
EXPORTC MYDLL BOOL STDCALL generateBin(int resolution_x, int resolution_y, int mode, float maxLvRatio, float minLvRatio, const char* tifFilePath1, const char* binFilePath1) // mode =0 ,mode =1  ������ͬ�Ĵ�����ʽ
{
	std::string tifFilePath = tifFilePath1;
	std::string binFilePath = binFilePath1;
	fstream fis;
	fstream fos;
	LOGFMTD("׼����ָ��ͼƬ��%s", tifFilePath.c_str());
	fis.open(tifFilePath, ios::in | ios::binary);
	LOGD("��ͼƬ�ɹ�");
	unsigned char* result = new unsigned char[4 * 1024 * 1024]; //���bin�ļ�
	memset(result, 0xff, 4 * 1024 * 1024);
	LOGD("��ʼ��result�ڴ�ɹ�");

	char* buf = new char[resolution_x * resolution_y * 4];
	float* fbuf = new float[resolution_x * resolution_y];
	memset(buf, 0, resolution_x * resolution_y * 4);
	memset(fbuf, 0, resolution_x * resolution_y * 4);
	LOGD("��ʼ��buf�ڴ�ɹ�");

	fis.read(buf, 8);//��ȡͷ8���ֽ� tif header 
	fis.read(buf, resolution_x * resolution_y * 4);
	LOGD("��ȡ�ֽڳɹ�");
	memcpy(fbuf, buf, sizeof(float) * resolution_x * resolution_y);//binary ת��float 
	LOGD("תfloat�ɹ�");

	float max_num = *max_element(fbuf, fbuf + resolution_x * resolution_y); // ��ȡ�������ֵ
	float min_num = *min_element(fbuf, fbuf + resolution_x * resolution_y);// ��ȡ������Сֵ
	LOGD("��ȡ�������ֵ��Сֵ");
	cout << max_num << " " << min_num << endl;
	switch (mode)
	{
	case 0: // ��1��bin�ļ�����ԭʼ������Ϣ��һ����0-255����ǰ��������/������� * 255���������ַ05_00_00��09_af_ff�� ��327680�� 634879
		for (int i = 0; i < resolution_x * resolution_y; i++)
		{
			result[327680 + i] = (char)(fbuf[i] / max_num * 255);
			cout << result[327680 + i] << endl;
		}
		break;

	case 1: //��2��bin�ļ�����ԭʼ������Ϣ��һ����0-255��(��ǰ��������-��С����)/������� * 255���������ַ05_00_00��09_af_ff�����ҽ� ��С����/������� * 255 ��Ϊdemura������¼ ,������ȡ���С����ѡȡ����ֵ��������
		for (int i = 0; i < resolution_x * resolution_y; i++)
		{
			result[327680 + i] = (char)((fbuf[i] - min_num * minLvRatio) / (max_num * maxLvRatio) * 255);
			cout << (min_num * minLvRatio) / (max_num * maxLvRatio) * 255 << endl; // ��¼��log���� 
		}

		break;

	}
	LOGD("���ݴ����ɹ�");

	fos.open(binFilePath, ios::out | ios::binary);
	fos.write((char*)result, 4 * 1024 * 1024);
	LOGD("д�����ݳɹ�");
	fos.flush();
	fis.close();
	fos.close();
	delete[] result;
	delete[] buf;
	delete[] fbuf;
	return TRUE;
}

string m_getLogCurrentTime()
{

	string dateStr;
	time_t now = time(0);
	tm* gmtm = new tm();
	localtime_s(gmtm, &now);

	dateStr.append(to_string(gmtm->tm_year + 1900));
	dateStr.append("-");
	dateStr.append(((gmtm->tm_mon + 1) < 10) ? ("0" + to_string(gmtm->tm_mon + 1)) : to_string(gmtm->tm_mon + 1));
	dateStr.append("-");
	dateStr.append((gmtm->tm_mday < 10) ? ("0" + to_string(gmtm->tm_mday)) : to_string(gmtm->tm_mday));
	dateStr.append(" ");
	dateStr.append((gmtm->tm_hour < 10) ? ("0" + to_string(gmtm->tm_hour)) : to_string(gmtm->tm_hour));
	dateStr.append(":");
	dateStr.append((gmtm->tm_min < 10) ? ("0" + to_string(gmtm->tm_min)) : to_string(gmtm->tm_min));
	dateStr.append(":");
	dateStr.append((gmtm->tm_sec < 10) ? ("0" + to_string(gmtm->tm_sec)) : to_string(gmtm->tm_sec));

	return dateStr;
}

/**
* ��ԭʼ������Ϣ��һ����0-255  ������ȡ���С����,�ο������� ѡȡ����ֵ��������
* ��ԭʼ������Ϣ��һ����0-255��(��ǰ��������)/��������ȣ� * 255��,������ȡ���С����ѡȡ����ֵ�������� ,����ѡȡ�����������Ҫ�趨Ϊ255
* ���Ϊresolution_x*resolution_y ��С��bin�ļ�
* @parameter resolution_x DUT �����طֱ���
* @parameter resolution_y DUT �����طֱ���
* @parameter maxlvRatio  ���ֵ�ٷֱ� 0~1
* @parameter minLvRatio  ��Сֵ�ٷֱ� 0~1
* @parameter refLvRatio  �ο�ֵ�ٷֱ� 0~1
* @parameter tifFilePath  tif�ļ�·��
* @parameter binFilePath ����bin�ļ�·��
* @parameter maxLv       ����ֵ���趨�������ֵ
* @parameter minLv       ����ֵ���趨��С����ֵ
* @parameter refLv       ����ֵ���趨�ο�������ֵ
* @parameter refGrayLevel  ����ֵ���趨�ο���ҽ�ֵ ,��Ϊ�������ݸ���¼����
* @parameter resultsavefilepath csv �ĵ��������ļ������������ֵ����С����ֵ���ο�������ֵ���ο���ҽ�ֵ
*/
EXPORTC MYDLL int STDCALL generateDemuraBinFromTif(int resolution_x, int resolution_y, float maxLvRatio, float minLvRatio, float refLvRatio, char* tifFilePath, char* binFilePath, float* maxLv, float* minLv, float* refLv, unsigned char* refGrayLevel, char* resultsavefilepath) // mode =0 ,mode =1  ������ͬ�Ĵ�����ʽ
{
	fstream fos_resultsave;
	fstream fis;
	fstream fos;
	fis.open(tifFilePath, ios::in | ios::binary);
	if (!fis.is_open())
	{
		return -1;
	}
	struct stat buffer;
	if (stat(resultsavefilepath, &buffer) == 0) // �ж��ļ��Ƿ���� 
	{
		fos_resultsave.open(resultsavefilepath, ios::out | ios::app);
		if (!fos_resultsave.is_open())
		{
			return -2;
		}
	}
	else // �ļ�δ������������д�����ͷ�ļ� 
	{
		fos_resultsave.open(resultsavefilepath, ios::out | ios::app);
		if (!fos_resultsave.is_open())
		{
			return -2;
		}
		fos_resultsave << "Name,Time,RefLvRatio,RefLvValue,RefGrayLevel,MaxLvRatio,MaxLvValue,MinLvRatio,MinLvValue" << endl;
	}




	int outputfilesize = resolution_x * resolution_y;
	unsigned char* result = new unsigned char[outputfilesize]; //���bin�ļ�
	memset(result, 0xff, outputfilesize);

	char* buf = new char[outputfilesize * 4];
	float* fbuf = new float[outputfilesize];
	float* tempbuf = new float[outputfilesize];
	memset(buf, 0, outputfilesize * 4);
	memset(fbuf, 0, outputfilesize * 4);

	fis.read(buf, 8);//��ȡͷ8���ֽ� tif header 
	fis.read(buf, outputfilesize * 4);
	memcpy(fbuf, buf, sizeof(float) * outputfilesize);//binary ת��float 
	memcpy(tempbuf, fbuf, sizeof(float) * outputfilesize);// ��ȡ��Ҫ���������� 

	sort(tempbuf, tempbuf + outputfilesize, less<float>());// ��������

	float max_num = tempbuf[(int)(outputfilesize * maxLvRatio)];// ��ȡ�������ֵ
	float min_num = tempbuf[(int)(outputfilesize * minLvRatio)];// ��ȡ������Сֵ
	*maxLv = max_num;
	*minLv = min_num;
	*refLv = tempbuf[(int)(outputfilesize * refLvRatio)];
	*refGrayLevel = (unsigned char)((*refLv) / (max_num) * 255 + 0.5);
	cout << *maxLv << " " << *refLv << " " << (int)*refGrayLevel << " " << *minLv << endl;
	fos_resultsave << tifFilePath << ",";   // name
	fos_resultsave << m_getLogCurrentTime() << ",";  // time //m_getLogCurrentTime()
	fos_resultsave << refLvRatio << "," << *refLv << "," << (int)*refGrayLevel << ","; // refLvRatio ,refLvValue,RefGrayLevel
	fos_resultsave << maxLvRatio << "," << *maxLv << ","; // MaxLvRatio maxLvValue
	fos_resultsave << minLvRatio << "," << *minLv << endl;// minLvRatio  minLvValue
	fos_resultsave.flush();

	//bin�ļ�����ԭʼ������Ϣ��һ����0-255��(��ǰ��������)/��������ȣ� * 255��,������ȡ���С����ѡȡ����ֵ��������
	for (int i = 0; i < outputfilesize; i++)
	{
		if (fbuf[i] < 0.0)
		{
			result[i] = (unsigned char)0x00;
		}
		else if (fbuf[i] > max_num)
		{
			result[i] = (unsigned char)0xff;
		}
		else
		{
			//cout << fbuf[i] << " " << (fbuf[i]) / (max_num - min_num) * 255 << endl; // ��¼��log���� 
			result[i] = (unsigned char)((fbuf[i]) / (max_num) * 255 + 0.5);
		}

	}

	fos.open(binFilePath, ios::out | ios::binary);
	fos.write((char*)result, outputfilesize);
	fos.flush();
	fis.close();
	fos.close();
	fos_resultsave.close();
	delete[] result;
	delete[] buf;
	delete[] fbuf;
	delete[] tempbuf;
	return 1;
}


EXPORTC MYDLL BOOL STDCALL forPointEx(int w, int h, int nbpp, int nChannels, uint8_t* pData, int method, int pointDistance, int  startPosition, int binaryPercentage
	, bool bDebug, char* szSaveName, int* xPos, int* yPos, int& pointNumber, bool bInversion, int* offxl, int* offyl, int nCountLeft, int* offxr, int* offyr, int nCountRight)
{
	if (nChannels != 3)
		return FALSE;

	int ntype = Gettype(nbpp, nChannels);

	cv::Mat img = cv::Mat(h, w, ntype, pData);

	cv::Mat inputimage;

	inputimage = MatToCImage(img);							// ��������8λ�����ܶ���λ��ȥ

	if (bInversion)
	{
		cv::flip(inputimage, inputimage, 1);
	}

	vector<Mat> channels;
	split(inputimage, channels);

	Mat blue, green, red;
	blue = channels.at(0);
	green = channels.at(1);
	red = channels.at(2);

	Mat mc1, mc2, mc3, mc4, sc1, sc2, sc3, sc4;
	meanStdDev(blue, mc1, sc1);
	meanStdDev(green, mc2, sc2);
	meanStdDev(red, mc3, sc3);

	double meanc1 = mc1.at<double_t>(0, 0);
	double meanc2 = mc2.at<double_t>(0, 0);
	double meanc3 = mc3.at<double_t>(0, 0);
	double stdc1 = sc1.at<double_t>(0, 0);
	double stdc2 = sc2.at<double_t>(0, 0);
	double stdc3 = sc3.at<double_t>(0, 0);

	double bluecontrast, greencontrast, redcontrast;
	bluecontrast = stdc1 / meanc1;
	greencontrast = stdc2 / meanc2;
	redcontrast = stdc3 / meanc3;

	double thresh;
	double mm = max({ bluecontrast ,greencontrast ,redcontrast });

	Mat ms;
	if (mm == bluecontrast)
	{
		ms = blue;
		thresh = meanc1 * binaryPercentage;
	}
	else if (mm == greencontrast)
	{
		ms = green;
		thresh = meanc2 * binaryPercentage;
	}
	else
	{
		ms = red;
		thresh = meanc3 * binaryPercentage;
	}

	Mat gms;
	GaussianBlur(ms, gms, Size(9, 9), 2, 2);

	Mat binim;
	threshold(gms, binim, thresh, 255, THRESH_BINARY);

	if (bDebug)
	{
		cv::imwrite(szSaveName, binim);
	}

	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	findContours(binim, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point());

	vector<double> g_dConArea(contours.size());
	for (int i = 0; i < contours.size(); i++)
	{
		g_dConArea[i] = contourArea(contours[i]);
	}

	int max = 0;
	for (int i = 1; i < contours.size(); i++) {
		if (g_dConArea[i] > g_dConArea[max]) {
			max = i;
		}
	}


	vector<vector<Point>> maxcontours(1);
	maxcontours[0] = contours[max];

	for (int i = 0; i < contours.size(); i++)
	{
		if (i != max)
		{
			if (g_dConArea[i] > g_dConArea[max] * 0.01)
			{
				maxcontours[0].insert(maxcontours[0].end(), contours[i].begin(), contours[i].end());
			}
		}

	}

	Rect rectAll = boundingRect(Mat(maxcontours[0]));

	vector<Point2i> result;

	if (method == 0)
	{
		//�̶�����
		double tt = sqrt(rectAll.width * rectAll.width + rectAll.height * rectAll.height) - startPosition;
		int pointInterval = tt / (pointNumber - 1);
		int sx, sy, ch, cw;

		ch = rectAll.height + 20;
		cw = pointInterval + 20;
		sx = rectAll.x + cw - 10;
		sy = rectAll.y - 10;

		Rect rect(sx, sy, cw, ch);
		Mat tempImg = ms(rect);
		Point2d p = cen(tempImg);
		int px = p.x + sx;
		int py = p.y + sy;

		result.push_back(Point2i(px, py));

		binim.at<uint8_t>(result[0].y, result[0].x) = 0;

		for (int i = 1; i < pointNumber; i++)
		{
			sx = result[i - 1].x + cw / 2;
			sy = result[i - 1].y - ch / 2;

			Rect rect(sx, sy, cw, ch);
			tempImg = ms(rect);
			p = cen(tempImg);

			p = cen(tempImg);
			if (p.x == 0 && p.y == 0) {
				result.push_back(Point2i(result[i - 1].x + cw, result[i - 1].y));
			}
			else {
				double dx = result[i - 1].x - p.x - sx;
				double dy = result[i - 1].y - p.y - sy;
				double d = sqrt(dx * dx + dy * dy);
				int tempx = -pointInterval / d * dx + result[i - 1].x;
				int tempy = -pointInterval / d * dy + result[i - 1].y;

				result.push_back(Point2i(tempx, tempy));
			}
			gms.at<uint8_t>(result[i].y, result[i].x) = 0;
		}
		waitKey();

	}
	else
	{
		//�̶����
		int pointInterval = pointDistance;
		int sx, sy, ch, cw;

		ch = rectAll.height + 20;
		cw = pointInterval + 20;
		sx = rectAll.x + startPosition - 10;
		sy = rectAll.y - 10;

		Rect rect(sx, sy, cw, ch);
		Mat tempImg = ms(rect);
		Point2d p = cen(tempImg);
		int px = p.x + sx;
		int py = p.y + sy;
		result.push_back(Point2i(px, py));

		binim.at<uint8_t>(result[0].y, result[0].x) = 0;

		int i = 1;
		sx = result[i - 1].x + cw / 2;
		sy = result[i - 1].y - ch / 2;

		int ep = sx + cw;
		int lp = rectAll.x + rectAll.width;

		while (ep < lp)
		{
			Rect rect(sx, sy, cw, ch);
			tempImg = ms(rect);
			p = cen(tempImg);
			if (p.x == 0 && p.y == 0) {
				result.push_back(Point2i(result[i - 1].x + cw, result[i - 1].y));
			}
			else {
				double dx = result[i - 1].x - p.x - sx;
				double dy = result[i - 1].y - p.y - sy;
				double d = sqrt(dx * dx + dy * dy);
				int tempx = -pointInterval / d * dx + result[i - 1].x;
				int tempy = -pointInterval / d * dy + result[i - 1].y;

				result.push_back(Point2i(tempx, tempy));
			}
			//double dx = result[i - 1].x - p.x - sx;
			//double dy = result[i - 1].y - p.y - sy;
			//double d = sqrt(dx * dx + dy * dy);
			//int tempx = -pointInterval / d * dx + result[i - 1].x;
			//int tempy = -pointInterval / d * dy + result[i - 1].y;

			//if (tempx < 0 ||
			//	tempx > gms.cols ||
			//	tempy < 0 ||
			//	tempy > gms.rows)
			//{
			//	break;
			//}

			//result.push_back(Point2i(tempx, tempy));

			gms.at<uint8_t>(result[i].y, result[i].x) = 0;
			sx = result[i].x + cw / 2;
			sy = result[i].y - ch / 2;
			i = i + 1;
			ep = sx + cw;
		}
	}

	int nCount = pointNumber < result.size() ? pointNumber : result.size();

	for (int i(0); i < nCount; i++)
	{
		if (bInversion)
			xPos[i] = w - result[i].x - 1;
		else
			xPos[i] = result[i].x;

		yPos[i] = result[i].y;
	}

	pointNumber = nCount;

	if (nCountLeft + nCountRight <= nCount)
	{
		for (int i = 0; i < nCountLeft; i++)
		{
			int x = xPos[i] - offxl[i];
			int y = yPos[i] - offyl[i];

			if (x > 0 && x < w)
			{
				xPos[i] = x;
			}

			if (y > 0 && y < h)
			{
				yPos[i] = y;
			}
		}

		for (int i = 0; i < nCountRight; i++)
		{
			int x = xPos[pointNumber - 1 - i] - offxr[i];
			int y = yPos[pointNumber - 1 - i] - offyr[i];

			if (x >= 0 && x < w)
			{
				xPos[pointNumber - 1 - i] = x;
			}

			if (y >= 0 && y < h)
			{
				yPos[pointNumber - 1 - i] = y;
			}
		}
	}

	return TRUE;
};

bool calFocusIndexByEdge(const cv::Mat& src, float& focusIndex)
{
	if (src.empty())
	{
		cout << "empty error!" << endl;
		return false;
	}
	Mat gray;
	if (src.channels() == 3)
		cvtColor(src, gray, COLOR_BGR2GRAY);
	else {
		gray = src.clone();
	}

	Mat gray_32f;
	gray.convertTo(gray_32f, CV_32FC1);
	//imwrite("gray.tif", gray_32f);
	int width = src.cols;
	int height = src.rows;
	Mat mask;
	//��������ֵ
	double mean_v = cv::mean(gray_32f).val[0];
	//ȡ��������mask
	cv::threshold(gray_32f, mask, 0.7 * mean_v, 255, THRESH_BINARY);
	mask.convertTo(mask, CV_8UC1, 1);
	//�󷢹����ľ�ֵ
	double mean_w = cv::mean(gray_32f, mask).val[0];
	//cout << "mean_w: " << mean_w << endl;
	//cout << "gray32f: " << gray_32f << endl;
	float th1 = mean_w * 0.1;		//��ֵ
	float th2 = mean_w * 0.9;
	//cout << "th: " << th1 << "," << th2 << endl;
	Mat edge_v = Mat(height, 1, CV_16UC1, Scalar(0));
	Mat edge_h = Mat(1, width, CV_16UC1, Scalar(0));
	int zero_cnt = 0;
	const int zero_cnt_th = 5;// ����5���Ҳ�����Ե������Ϊ�Ǻ��
	//����
	for (int i = 0; i < height; i++)
	{
		int edge_cnt = 0;
		int change_cnt = 0;
		for (int j = 1; j < width; j++)
		{
			if (gray_32f.at<float>(i, j) > th1 && (gray_32f.at<float>(i, j) < th2))
			{
				edge_cnt++;
			}
		}
		if (edge_cnt == 0)
			zero_cnt++;
		if (zero_cnt > zero_cnt_th)
			break;
		edge_v.at<uint16_t>(i, 0) = edge_cnt;
	}
	//���
	if (zero_cnt > zero_cnt_th)
	{
		//cout << "horizontal edge !" << endl;
		LOGD("horizontal edge !");
		for (int i = 0; i < width; i++)
		{
			int edge_cnt_h = 0;
			int change_cnt = 0;
			for (int j = 1; j < height; j++)
			{
				if (gray_32f.at<float>(j, i) > th1 && (gray_32f.at<float>(j, i) < th2))
				{
					edge_cnt_h++;
				}
			}
			edge_h.at<uint16_t>(0, i) = edge_cnt_h;

		}

		float edge_pixels_sum_h = 0;
		int none_zero_cnt_h = 0;
		for (int i = 0; i < width; i++)
		{
			if (edge_h.at<uint16_t>(0, i) != 0)
			{
				edge_pixels_sum_h += edge_h.at<uint16_t>(0, i);
				none_zero_cnt_h++;
			}
		}
		if (none_zero_cnt_h != 0)
			focusIndex = edge_pixels_sum_h / none_zero_cnt_h;
		else
			focusIndex = 0;
	}
	else
	{
		/*cout << "vertical edge!" << endl;*/
		LOGD("vertical edge!");
		float edge_pixels_sum = 0;
		int none_zero_cnt = 0;
		for (int i = 0; i < edge_v.rows; i++)
		{
			if (edge_v.at<uint16_t>(i, 0) != 0)
			{
				edge_pixels_sum += edge_v.at<uint16_t>(i, 0);
				none_zero_cnt++;
			}
		}
		if (none_zero_cnt != 0)
			focusIndex = edge_pixels_sum / none_zero_cnt;
		else
			focusIndex = 0;
	}
	//cout << "focusIndex: " << focusIndex << endl;
	LOGFMTD("the focusIndex is:%f", focusIndex);
	return true;
}

BOOL CalFocusLevelByEdge(int w, int h, int bpp, int channels, const uint8_t* psrcData, const IRECT* pI, float* pResult, int length, int flag) {
	int type = Gettype(bpp, channels);
	uchar* data = (uchar*)psrcData;
	cv::Mat src(h, w, type, data);
	if (src.empty())
	{
		return FALSE;
	}

	for (int i = 0; i < length; i++)
	{
		if (pI[i].x<0 || (pI[i].cx + pI[i].x)>w || pI[i].y<0 || (pI[i].y + pI[i].cy)>h)
		{
			LOGE("CalFocusLevelByEdge rect is out of scope!");
			return FALSE;
		}
		Mat tM = src(cv::Rect(pI[i].x, pI[i].y, pI[i].cx, pI[i].cy));
		if (flag > 10)
		{
			imwrite("TIFF\\focusRect_" + to_string(i) + ".tif", tM);
		}

		bool tr = calFocusIndexByEdge(tM, pResult[i]);
		if (!tr)
		{
			return FALSE;
		}


	}
	return TRUE;
}

bool squeenPointClockwise(vector<cv::Point2f>& source, int num_x, int num_y) {
	if (source.size() != num_x * num_y)
	{
		return false;
	}


	for (int i = 1; i < source.size(); i++)
	{
		for (int j = i; j > 0; j--)
		{
			if (source[j].y < source[j - 1].y)
			{
				Point tp = source[j];
				source[j] = source[j - 1];
				source[j - 1] = tp;
			}
		}
	}

	if (source.size() == 4)
	{
		if (source[1].x < source[0].x)
		{
			Point tp = source[1];
			source[1] = source[0];
			source[0] = tp;
		}

		if (source[2].x < source[3].x)
		{
			Point tp = source[2];
			source[2] = source[3];
			source[3] = tp;
		}
		return true;
	}
	return false;
}

EXPORTC MYDLL BOOL GetRIAandPT(int w, int h, int bpp, int channels, const uint8_t* pData, int nthresh, int nTimes, int nSmooth_size, int* pX, int* pY)
{
	if (pData == nullptr)
		return FALSE;

	cv::Mat src_image;

	Mat img;
	int ntype = Gettype(bpp, channels);
	src_image = cv::Mat(h, w, ntype, (LPVOID)pData);
	if (src_image.channels() > 1)
	{
		vector<Mat> chnls;
		split(src_image, chnls);
		img = chnls[1];
	}
	else
	{
		img = src_image;
	}

	if (img.type() != CV_8U)
	{
		img.convertTo(img, CV_8U, 1.0 / 256.0);
	}

	Mat binary_image;

	threshold(img, binary_image, nthresh, 255, THRESH_BINARY);  //ͼ���ֵ��

	vector<vector<Point>> register_contours;
	vector<Vec4i> register_contours_vec4i;
	findContours(binary_image, register_contours, register_contours_vec4i, RETR_EXTERNAL, CHAIN_APPROX_NONE, Point2f(0, 0));

	//�����contour
	double max_area = 0;
	vector<Point> biggest_contour;
	for (auto i_contour = register_contours.begin(); i_contour != register_contours.end(); i_contour++)
	{
		double i_area = contourArea(*i_contour, false);
		if (i_area > max_area)
		{
			max_area = i_area;
			biggest_contour = *i_contour;
		}
	}

	//�����blob����С�ڽӾ���
	RotatedRect the_contour_rect;
	Rect rect_src = Rect(0, 0, img.cols, img.rows);
	Rect tmprect;
	Rect rect_bounding = boundingRect(biggest_contour);
	Rect bdrect;
	int edge_gap = 50;
	bdrect.x = rect_bounding.x - edge_gap;
	bdrect.y = rect_bounding.y - edge_gap;
	bdrect.width = rect_bounding.width + edge_gap * 2;
	bdrect.height = rect_bounding.height + edge_gap * 2;
	tmprect = bdrect & rect_src;
	Mat roi_srcimg;
	Mat roi_binary_image;
	Mat big_contour_image = Mat::zeros(img.rows, img.cols, binary_image.type());

	if (biggest_contour.size() > 0)
	{
		vector<vector<Point>> draw_big_contours;
		draw_big_contours.push_back(biggest_contour);
		drawContours(big_contour_image, draw_big_contours, -1, Scalar(255), -1);
	}

	if (bdrect.x < 0 || bdrect.x > src_image.cols ||
		bdrect.y < 0 || bdrect.y > src_image.rows)
		return FALSE;

	if (bdrect != tmprect)
	{
		//����������������߻�û���Թ�
		roi_binary_image = Mat::zeros(bdrect.height, bdrect.width, binary_image.type());
		roi_binary_image(Rect(edge_gap, edge_gap, rect_bounding.width, rect_bounding.height)) = big_contour_image(rect_bounding).clone();
		roi_srcimg = Mat::zeros(bdrect.height, bdrect.width, src_image.type());
		roi_srcimg(Rect(edge_gap, edge_gap, rect_bounding.width, rect_bounding.height)) = src_image(rect_bounding).clone();
	}
	else
	{
		roi_srcimg = src_image(bdrect);
		roi_binary_image = big_contour_image(bdrect);
	}

	vector<Point2f> corners_img;

	rectCornersPyrdownFaster(roi_binary_image, nTimes, nSmooth_size, corners_img);

	Rect whole_rect = Rect(0, 0, roi_binary_image.cols, roi_binary_image.rows);

	for (int i = 0; i < corners_img.size(); i++)
	{
		cout << corners_img[i] << endl;
		tmprect = Rect(round(corners_img[i].x) - 3, round(corners_img[i].y) - 3, 6, 6);
		tmprect = tmprect & whole_rect;
		rectangle(roi_binary_image, tmprect, Scalar(127), 1, 8, 0);
	}

	if (corners_img.size() < 4)
		return FALSE;

	squeenPointClockwise(corners_img, 2, 2);
	for (size_t i = 0; i < corners_img.size(); i++)
	{
		pX[i] = corners_img[i].x + bdrect.x;
		pY[i] = corners_img[i].y + bdrect.y;
	}

	return TRUE;
}

EXPORTC MYDLL BOOL GetRIAand(HImage& tsrcImg, int* pX, int* pY, uint32_t unEgde)
{
	int ntype = Gettype(tsrcImg.iBpp, tsrcImg.iChls);

	cv::Mat src_image(tsrcImg.iHei, tsrcImg.iWid, ntype, tsrcImg.pData);

	if (true == src_image.empty())
		return FALSE;

	vector<Point2f> corners_img;

	corners_img.resize(4);

	for (size_t i = 0; i < corners_img.size(); i++)
	{
		corners_img[i].x = pX[i];
		corners_img[i].y = pY[i];
	}

	std::sort(pX, pX + 4);
	std::sort(pY, pY + 4);

	int x = pX[0] - unEgde;
	int y = pY[0] - unEgde;
	if (x < 0)
		x = 0;
	if (y < 0)
		y = 0;
	int nW = pX[3] - pX[0] + unEgde * 2;
	int nH = pY[3] - pY[0] + unEgde * 2;


	Rect bdrect(x, y, nW, nH);

	for (size_t i = 0; i < corners_img.size(); i++)
	{
		corners_img[i].x -= bdrect.x;
		corners_img[i].y -= bdrect.y;
	}

	Mat roi_srcimg = src_image(bdrect);

	vector<Point2f> corners_ordered, target_corners;
	float w, h;
	getRectCornersOrdered(corners_img, corners_ordered);
	getRectWHfromProjectedCorners(corners_ordered, w, h);

	target_corners.push_back(Point2f(0, 0));
	target_corners.push_back(Point2f(w, 0));
	target_corners.push_back(Point2f(w, h));
	target_corners.push_back(Point2f(0, h));

	Mat pt_mtx = getPerspectiveTransform(corners_ordered, target_corners);

	Mat img_rst;

	warpPerspective(roi_srcimg, img_rst, pt_mtx, Size(w, h));
	tsrcImg.iWid = img_rst.cols;
	tsrcImg.iHei = img_rst.rows;
	tsrcImg.iChls = img_rst.channels();
	tsrcImg.iBpp = img_rst.elemSize1() * 8;

	memcpy(tsrcImg.pData, img_rst.data, img_rst.u->size);

	return TRUE;
}

haloCacl* pHalo = nullptr;
void CM_InitialKeyBoardSrc(int w, int h, int bpp, int channels, char* imgdata, int saveProcessData, const char* debugPath, float exp, const char* luminFile, BOOL doCali) {
	if (pHalo != nullptr)
	{
		delete pHalo;
	}
	pHalo = new haloCacl();
	return pHalo->initialSrc(w, h, bpp, channels, imgdata, saveProcessData, debugPath, exp, luminFile, doCali);
}

float CM_CalculateHalo(IRECT keyRect, int outMOVE, int threadV, int haloSize, const char* savePath, ushort* gray, uint& pixNum) {
	if (pHalo == nullptr)
	{
		return -99;
	}
	return pHalo->calculateHalo(keyRect.x, keyRect.y, keyRect.cx, keyRect.cy, outMOVE, threadV, haloSize, savePath, gray, pixNum);
}

float CM_CalculateKey(IRECT keyRect, int inMOVE, int threadV, const char* path, ushort* gray, uint& pixNum) {
	if (pHalo == nullptr)
	{
		return -99;
	}
	return pHalo->calculateKey(keyRect.x, keyRect.y, keyRect.cx, keyRect.cy, inMOVE, threadV, path, gray, pixNum);
}

int CM_GetKeyBoardResult(int& w, int& h, int& bpp, int& channels, char* pData) {
	if (pHalo == nullptr)
	{
		return 0;
	}
	return pHalo->getHaloResult(w, h, bpp, channels, pData);
}

int CM_CalcKeyBoardBySocket(int w, int h, int bpp, int channels, char* data, float* exp, const char* caliFn, const char* paramJson, float* pKeyResult, float* pHaloResult, char* drawData) {
	if (pHalo != nullptr)
	{
		delete pHalo;
	}
	pHalo = new haloCacl();
	Json::Reader r;
	Json::Value v;
	r.parse(paramJson, v);
	if (v.isNull())
	{
		LOGE("the keyBoard parameter is Not Json format!");
		return -1;
	}
	int isSaveProcess = v["saveProcessData"].asBool();
	string debugPath = v["debugPath"].asCString();

	pHalo->initialSrc(w, h, bpp, channels, data, isSaveProcess, debugPath.c_str(), exp[0], caliFn, true);
	bool doKey = v["calcKey"].asBool();
	bool doHalo = v["calcHalo"].asBool();
	int length = v["keyRect"].size();
	Json::Value v1 = v["keyRect"];
	ushort tGray = 0;
	if (doKey)
	{
		for (int i = 0; i < length; i++)
		{
			IRECT tRect;
			tRect.x = v1[i]["x"].asInt();
			tRect.y = v1[i]["y"].asInt();
			tRect.cx = v1[i]["w"].asInt();
			tRect.cy = v1[i]["h"].asInt();
			int move = v1[i]["move"].asInt();
			int thresholdV = v1[i]["thresholdV"].asInt();
			string processImage = v1[i]["processImage"].asCString();
			//string name = v1[i]["name"].asCString();
			uint pixNum = 0;
			//��ʱɾ��
			//pKeyResult[i] = pHalo->calculateKey(tRect.x, tRect.y, tRect.cx, tRect.cy, move, thresholdV, processImage.c_str(), tGray, pixNum);
		}
	}

	v1.clear();
	v1 = v["haloRect"];

	if (doHalo)
	{
		for (int i = 0; i < length; i++)
		{
			IRECT tRect;
			tRect.x = v1[i]["x"].asInt();
			tRect.y = v1[i]["y"].asInt();
			tRect.cx = v1[i]["w"].asInt();
			tRect.cy = v1[i]["h"].asInt();
			int move = v1[i]["move"].asInt();
			int thresholdV = v1[i]["thresholdV"].asInt();
			int haloSize = v1[i]["haloSize"].asInt();
			string processImage = v1[i]["processImage"].asCString();
			uint pixNum = 0;
			//pHaloResult[i] = pHalo->calculateHalo(tRect.x, tRect.y, tRect.cx, tRect.cy, move, thresholdV, haloSize, processImage.c_str(), tGray, pixNum);
		}
	}

	int sW = 0, sH = 0, sBpp = 0, sC = 0;
	pHalo->getHaloResult(sW, sH, sBpp, sC, drawData);
	return 1;
}

int CM_CalcKeyBoardBySocketGray(int w, int h, int bpp, int channels, char* data, const char* paramJson, int& resultW, int& resultH, char* pResult, uint* pPixNum, char* drawData) {

	if (pHalo != nullptr)
	{
		delete pHalo;
	}
	pHalo = new haloCacl();
	Json::Reader r;
	Json::Value v;
	r.parse(paramJson, v);
	if (v.isNull())
	{
		LOGE("the keyBoard parameter is Not Json format!");
		return -1;
	}
	Json::StreamWriterBuilder writer;
	std::string output = Json::writeString(writer, v);

	int isSaveProcess = v["saveProcessData"].asBool();
	string debugPath = v["debugPath"].asCString();
	pHalo->initialSrc(w, h, bpp, channels, data, isSaveProcess, debugPath.c_str(), 1, "null", false);

	int Number = v["keyRect"].size();

	resultW = Number;
	resultH = 2;//��һ�����ַ����ڶ����ǹ���
	int allLength = Number * resultH * channels;
	ushort* pData = new ushort[allLength];
	memset(pData, 0, allLength * sizeof(ushort));

	Json::Value v1 = v["keyRect"];
	int pixNumArr = 0;
	int elemIndex = 0;
	//int elemStep = channels;
	for (int i = 0; i < Number; i++)
	{
		Json::Value obj = v1[i];
		IRECT tRect;
		tRect.x = obj["x"].asInt();
		tRect.y = obj["y"].asInt();
		tRect.cx = obj["w"].asInt();
		tRect.cy = obj["h"].asInt();
		string name = obj["name"].asCString();
		bool doKey = obj["doKey"].asBool();
		bool doHalo = obj["doHalo"].asBool();

		if (doKey)
		{
			Json::Value jsonKey = obj["key"];
			int offsetX = jsonKey["offset_X"].asInt();
			int offsetY = jsonKey["offset_Y"].asInt();
			int move = jsonKey["move"].asInt();
			int thresholdV = jsonKey["thresholdV"].asInt();
			ushort tGray[3];
			uint pixNum = 0;
			pHalo->calculateKey(tRect.x + offsetX, tRect.y + offsetY, tRect.cx, tRect.cy, move, thresholdV, name.c_str(), tGray, pixNum);

			pData[elemIndex] = tGray[0];
			if (channels == 3)
			{
				pData[elemIndex + 1] = tGray[1];
				pData[elemIndex + 2] = tGray[2];
			}

			pPixNum[pixNumArr] = pixNum;

		}

		if (doHalo)
		{
			Json::Value jsonHalo = obj["halo"];
			int offsetX = jsonHalo["offset_X"].asInt();
			int offsetY = jsonHalo["offset_Y"].asInt();

			int move = jsonHalo["move"].asInt();
			int thresholdV = jsonHalo["thresholdV"].asInt();
			int haloSize = jsonHalo["haloSize"].asInt();
			ushort tGray[3];
			uint pixNum = 0;
			pHalo->calculateHalo(tRect.x + offsetX, tRect.y + offsetY, tRect.cx, tRect.cy, move, thresholdV, haloSize, name.c_str(), tGray, pixNum);
			pData[elemIndex + Number * channels] = tGray[0];
			if (channels == 3)
			{
				pData[elemIndex + Number * channels + 1] = tGray[1];
				pData[elemIndex + Number * channels + 2] = tGray[2];
			}
			pPixNum[pixNumArr + Number] = pixNum;
			//elemIndex += channels;
		}
		elemIndex += channels;
		pixNumArr++;
	}

	memcpy(pResult, pData, bpp / 8 * allLength);
	delete[]pData;
	int sW = 0, sH = 0, sBpp = 0, sC = 0;
	pHalo->getHaloResult(sW, sH, sBpp, sC, drawData);
	return 1;
}

ledCheck_qk* pLedCheck_qk = nullptr;

int CM_FindLedPosition(int w, int h, int bpp, int channels, uchar* data, int ledNum_x, int ledNum_y, int threadV, PointInt* corner) {
	if (pLedCheck_qk == nullptr)
	{
		pLedCheck_qk = new ledCheck_qk();
	}
	int cornerX[4] = { corner[0].x, corner[1].x,  corner[2].x,  corner[3].x };
	int cornerY[4] = { corner[0].y, corner[1].y,  corner[2].y,  corner[3].y };
	return pLedCheck_qk->findLedPosition(w, h, bpp, channels, data, ledNum_x, ledNum_y, threadV, cornerX, cornerY);
}

int CM_GetLedCenterNum() {
	if (pLedCheck_qk == nullptr)
	{
		LOGE("never invoke CM_FindLedPosition before");
		return -1;
	}
	return pLedCheck_qk->getLedCenterNum();
}

int CM_GetBadLedNum() {
	if (pLedCheck_qk == nullptr)
	{
		LOGE("never invoke CM_FindLedPosition before");
		return -1;
	}
	return pLedCheck_qk->getBadPointNum();
}

int CM_GetLedCenterPositions(PointInt* pArr, int& referenceRadius) {
	if (pLedCheck_qk == nullptr)
	{
		LOGE("never invoke CM_FindLedPosition before");
		return FALSE;
	}
	return pLedCheck_qk->getLedCenterPositions(pArr, referenceRadius);
}

int CM_GetBadLedPositions(PointInt* pArr) {
	if (pLedCheck_qk == nullptr)
	{
		LOGE("never invoke CM_FindLedPosition before");
		return FALSE;
	}
	return pLedCheck_qk->getBadPositions(pArr);
}

int CM_GetLedDrawImg(int& w, int& h, int& bpp, int& channels, uchar* data) {
	if (pLedCheck_qk == nullptr)
	{
		LOGE("never invoke CM_FindLedPosition before");
		return FALSE;
	}
	return pLedCheck_qk->getDrawImg(w, h, bpp, channels, data);
}

int CM_FindHighIndensityLed(int w, int h, int bpp, int channels, char* imgdata, CVLED_COLOR color, const char* cfg_json, const char* positionFn, int& col, int& row, float& x_interval, float& y_interval, float& angle, double* pX, double* pY) {
	LOGI("invoke CM_FindHighIndensityLed");
	int res = ledCheck_qk::findHighIndensityLed(w, h, bpp, channels, imgdata, color, cfg_json, positionFn, col, row, x_interval, y_interval, angle, pX, pY);
	LOGFMTI("CM_FindHighIndensityLed return is:%d", res);
	return res;
}

int CM_FindLedPositionBySocket(int w, int h, int bpp, int channels, uchar* data, const char* paramJson, PointInt* pArr, int& pLength, int& referenceRadius) {
	if (pLedCheck_qk == nullptr)
	{
		pLedCheck_qk = new ledCheck_qk();
	}
	Json::Reader r;
	Json::Value v;
	r.parse(paramJson, v);
	if (v.isNull())
	{
		LOGE("the parameter is Not Json format!");
		return -1;
	}
	int ledNum_x = v["ledNum_x"].asInt();
	int ledNum_y = v["ledNum_y"].asInt();
	int threadV = v["thresholdValue"].asInt();

	int cornerX[4];
	int cornerY[4];
	for (int i = 0; i < 4; i++)
	{
		cornerX[i] = v["cornerPoints"][i]["x"].asInt();
		cornerY[i] = v["cornerPoints"][i]["y"].asInt();
	}

	BOOL res = pLedCheck_qk->findLedPosition(w, h, bpp, channels, data, ledNum_x, ledNum_y, threadV, cornerX, cornerY);
	if (res < 0)
	{
		return res;
	}

	int pLedNum = pLedCheck_qk->getLedCenterNum();
	int badNum = pLedCheck_qk->getBadPointNum();
	if (pLength < pLedNum + badNum)
	{
		pLength = pLedNum + badNum;
		LOGFMTE("the point arrry length is%d,not enough", pLedNum + badNum);
		return -2;
	}

	pLedCheck_qk->getLedCenterPositions(pArr, referenceRadius);

	pLedCheck_qk->getBadPositions(pArr + pLedNum);
	pLength = pLedNum + badNum;
	return res;
}

Ghost* pGhost = nullptr;

int CM_CalcGhostSocket(int w, int h, int bpp, int channels, uchar* data, uchar* pXYZ, int xyzIndex, const char* paramJson, char* result, int& showBpp, int& showChannel, uchar* showData) {
	if (pGhost == nullptr)
	{
		pGhost = new Ghost();
	}
	Json::Reader r;
	Json::Value v;
	r.parse(paramJson, v);
	if (v.isNull())
	{
		LOGE("the  parameter is Not Json format!");
		return -1;
	}
	Json::Value vOther = v["vOther"];
	bool isDebug = vOther["Debug"].asBool();
	string debugPath = vOther["debugPath"].asCString();

	pGhost->enableDebug(isDebug, debugPath.c_str());

	pGhost->initialMat(w, h, bpp, channels, data);
	pGhost->loadXyz(pXYZ, xyzIndex);

	Json::Value vBright = v["Bright"];
	int thresholdMin = vBright["thresholdMin"].asInt();
	int thresholdMax = vBright["thresholdMax"].asInt();
	int thresholdStep = vBright["thresholdStep"].asInt();
	int brightNumX = vBright["brightNumX"].asInt();
	int brightNumY = vBright["brightNumY"].asInt();
	Pattern patternType = (Pattern)vBright["brightNumY"].asInt();
	int outRectSizeMin = vBright["outRectSizeMin"].asInt();
	float outRectSizeRate = vBright["outRectSizeRate"].asFloat();
	int erodeKernel = vBright["erodeKernel"].asInt();

	int res = pGhost->findBright(thresholdMin, thresholdMax, thresholdStep, brightNumX, brightNumY, patternType, outRectSizeMin, outRectSizeRate, erodeKernel);
	if (res != 1)
	{
		LOGE("Failed to findBright");
		return 0;
	}



	Json::Value vGhost = v["Ghost"];
	int length = vGhost["ingoreCheckMixBright"].size();
	bool* ingoreCheckMixBright = new bool[length];
	for (int i = 0;i < length;i++)
	{
		ingoreCheckMixBright[i] = vGhost["ingoreCheckMixBright"][i].asBool();
	}
	pGhost->enableCheckCloseBright(ingoreCheckMixBright, length);
	delete[]ingoreCheckMixBright;

	thresholdMin = vGhost["thresholdMin"].asInt();
	thresholdMax = vGhost["thresholdMax"].asInt();
	thresholdStep = vGhost["thresholdStep"].asInt();
	outRectSizeMin = vGhost["outRectSizeMin"].asInt();
	outRectSizeRate = vGhost["outRectSizeRate"].asFloat();
	int minGary = vGhost["minGary"].asInt();
	float garyRate = vGhost["garyRate"].asFloat();
	erodeKernel = vGhost["erodeKernel"].asInt();
	int erodeTime = vGhost["erodeTime"].asInt();
	int distanceToBright = vGhost["distanceToBright"].asInt();
	res = pGhost->findGhost(thresholdMin, thresholdMax, thresholdStep, outRectSizeMin, outRectSizeRate, minGary, garyRate, erodeKernel, erodeTime, distanceToBright);
	if (res != 1)
	{
		LOGE("Failed to findBright");
		/*return 0;*/
	}

	float showMinGain = vOther["showMinGain"].asFloat();
	float showMaxGain = vOther["showMaxGain"].asFloat();
	if (showMaxGain > 1) {
		showMaxGain = 0.9;
	}

	pGhost->setDrawMatGain(showMinGain, showMaxGain);

	Json::Value vResult;
	Json::Value vPart;

	length = brightNumX * brightNumY;
	float* Y = new float[length];
	res = pGhost->getBrightAverageY(Y, length);
	if (res == 1)
	{
		for (int i = 0; i < length; i++)
		{
			vPart["Y_Lum"].append(Y[i]);
		}
	}


	PointInt* po = new PointInt[length];
	res = pGhost->getBrightPointsCenter(po, length);
	Json::Value item;

	if (res == 1)
	{
		for (int i = 0; i < length; i++)
		{
			item["x"] = po[i].x;
			item["y"] = po[i].y;
			vPart["center"].append(item);
		}
	}


	vResult["Bright"] = vPart;

	vPart.clear();

	//��Ӱ���

	pGhost->getGhostAverageY(Y, length);
	if (res == 1)
	{
		for (int i = 0; i < length; i++)
		{
			vPart["Y_Lum"].append(Y[i]);
		}
	}

	res = pGhost->getBrightPointsCenter(po, length);

	if (res == 1)
	{
		for (int i = 0; i < length; i++)
		{
			item["x"] = po[i].x;
			item["y"] = po[i].y;
			vPart["center"].append(item);
		}
	}
	delete[]po;
	delete[]Y;

	vResult["Ghost"] = vPart;

	Json::StreamWriterBuilder writer;
	std::string output = Json::writeString(writer, vResult);
	memcpy(result, output.c_str(), output.length() + 1);

	int sW = w, sH = h;
	pGhost->getDrawMat(sW, sH, showBpp, showChannel, showData);

	return 1;
}

EXPORTC MYDLL HANDLE STDCALL CM_MatchTemplate(int w, int h, int bpp, int channels, BYTE* pData)
{
	CMMatch* pMatch = new CMMatch();

	pMatch->LoadTemplate(w, h, bpp, channels, pData);

	return pMatch;
}

EXPORTC MYDLL BOOL STDCALL CM_MatchParameter(HANDLE handle, int nMaxCount, double dScore, double dMaxOverlap, double dToleranceAngle, int m_iMinReduceArea)
{
	CMMatch* pMatch = (CMMatch*)handle;

	return pMatch->SetParameter(nMaxCount, dScore, dMaxOverlap, dToleranceAngle, m_iMinReduceArea);
}

EXPORTC MYDLL int STDCALL CM_MatchExecute(HANDLE handle, int w, int h, int bpp, int channels, BYTE* pData)
{
	CMMatch* pMatch = (CMMatch*)handle;

	return pMatch->Execute(w, h, bpp, channels, pData);
}

EXPORTC MYDLL int STDCALL CM_MatchResult(HANDLE handle, TargetMatchPoint* ptTMPoints)
{
	CMMatch* pMatch = (CMMatch*)handle;

	return pMatch->GetResult(ptTMPoints);
}

EXPORTC MYDLL BOOL STDCALL CM_MatchCloseHandle(HANDLE handle)
{
	CMMatch* pMatch = (CMMatch*)handle;
	delete pMatch;
	pMatch = nullptr;
	return true;
}
////////////////////////////////////BF˫Ŀ�ں�/////////////////////////////////////
EXPORTC MYDLL int STDCALL CM_AVR_GetCrossMarksForBinocularFusion(const char* imgFile, const char* jsonCfg, BFResultData& resultData, const char* resultFile)
{
	return getCrossMarksForBinocularFusion(imgFile, jsonCfg, resultData, resultFile);
}

EXPORTC MYDLL int STDCALL CM_AVR_GetCrossMarksForBinocularFusionFromMem(HImage& tImg, const char* jsonCfg, BFResultData& resultData, const char* resultFile)
{
	return getCrossMarksForBinocularFusion(tImg, jsonCfg, resultData, resultFile);
}