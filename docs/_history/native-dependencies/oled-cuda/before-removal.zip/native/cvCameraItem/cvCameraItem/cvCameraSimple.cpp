#include "stdafx.h"
#include <map>
#include "log4z.h"
#include "colorVisionSimple.h"
#include "CameraManager.h"
#include "cvCamera.h"
#include "opencv2/opencv.hpp"

std::map<HANDLE, colorVisionSimple*>map_Handle;

colorVisionSimple* findHandle(HANDLE handle) {
	std::map<HANDLE, colorVisionSimple*>::iterator it = map_Handle.begin();

	while (it != map_Handle.end())
	{
		if (it->first == handle) {
			return it->second;
		}
		it++;
	}
	return nullptr;
}

bool isSimpleHandle(HANDLE handle) {
	std::map<HANDLE, colorVisionSimple*>::iterator it = map_Handle.begin();

	while (it != map_Handle.end())
	{
		if (it->first == handle) {
			return true;
		}
		it++;
	}
	return false;
}

bool accessToReadRelayCfg(HANDLE handle) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return false;
	}
	return pSimple->accessToReadRelayCfg();
}

HANDLE STDCALL CM_CreatCameraManagerSimple(const char* cameraCfgFile) {
	LOGI("invoke CM_CreatCameraManagerSimple");
	colorVisionSimple* pSimple = new colorVisionSimple(cameraCfgFile);

	if (!pSimple->getReadSuccess())
	{
		delete pSimple;
		return nullptr;
	}

	HANDLE camHandle = CM_CreatCameraManager(pSimple->getCameraType(), pSimple->getCameraId().c_str(), "");

	pSimple->setCameraHandle(camHandle);

	map_Handle.insert(std::pair<HANDLE, colorVisionSimple*>(camHandle, pSimple));

	return camHandle;

}

BOOL STDCALL CM_OpenSimple(HANDLE handle) {
	LOGI("invoke CM_OpenSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->openCamera(pSimple->getTakeImageMode());
}

BOOL STDCALL CM_OpenLiveSimple(HANDLE handle) {
	LOGI("invoke CM_OpenLiveSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->openCamera(TakeImageMode::Live);
}

BOOL  CM_SetExpTimeSimple(HANDLE handle, float exp1, float exp2, float exp3) {
	LOGI("invoke CM_SetExpTimeSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->setExp(exp1, exp2, exp3);
}

BOOL  CM_SetPortComSimple(HANDLE handle, const char* portCom) {
	LOGI("invoke CM_SetPortComSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->setCfwCom(portCom);
}

BOOL  CM_SetFocusComSimple(HANDLE handle, const char* focusCom) {
	LOGI("invoke CM_SetFocusComSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->setFocusCom(focusCom);
}

int CM_GetSpecialTasks(HANDLE handle, char* pTasks) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return 0;
	}
	return pSimple->getSpecialTasks(pTasks);
}

int CM_GetDcfParameters(HANDLE handle, char* pParameter) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return 0;
	}
	return pSimple->getParameters(pParameter);
}

int CalFocusLevelByEdgeSimple(HANDLE handle, const IRECT* pI, float* pResult, int length, int flag) {
	LOGFMTI("invoke CalFocusLevelByEdgeSimple,the flag is:%d .", flag);
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return 0;
	}
	int res = pSimple->calFoucusLevel(pI, pResult, length, 11);
	LOGFMTI("CalFocusLevelByEdgeSimple return is:%d .", res);
	return res;
}

int CM_CreatChildHandle(HANDLE handle, HANDLE& childHandle, UCHAR ucMachineNO, int handleType) {
	LOGFMTI("invoke CM_CreatChildHandle,the handleType is:%d .", handleType);
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return 0;
	}
	if (handleType == 0)
	{
		int res = pSimple->creatMotorHandle(childHandle, ucMachineNO);
		LOGFMTI("CM_CreatChildHandle return is:%d .", res);
		return res;
	}
	return 0;
}

BOOL CM_SetComSimple(HANDLE handle, int comType, const char* ComNummber, int flag) {
	LOGFMTI("invoke CM_SetComSimple,the COM type is:%d .", comType);
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	BOOL res = FALSE;
	switch (comType)
	{
	case 0:
		res = pSimple->setCfwCom(ComNummber);
		break;
	case 1:
		res = pSimple->setFocusCom(ComNummber);
		break;
	case 2:
		res = pSimple->setRelayCom(ComNummber);
		break;
	default:
		break;
	}
	LOGFMTI("CM_SetComSimple return is:%d .", res);
	return res;
}



BOOL  CM_GetAutoExpTimeSimple(HANDLE handle, float& exp1, float& exp2, float& exp3, float* saturation) {
	LOGI("invoke CM_GetAutoExpTimeSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->getAutoExp(exp1, exp2, exp3, saturation);
}

BOOL  CM_GetFrameSimple(HANDLE handle, uint& w, uint& h, uint& srcbpp, uint& bpp, uint& channels, BYTE* srcimgdata, BYTE* imgdata) {
	LOGI("invoke CM_GetFrameSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->getFrame(w, h, srcbpp, bpp, channels, srcimgdata, imgdata);
}

int  CM_GetCalibrationGroupNum(HANDLE handle) {
	LOGI("invoke CM_GetCalibrationGroupNum");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return -1;
	}
	return pSimple->getCaliGroupNum();
}

BOOL  CM_GetAllCalibrationGroupTitles(HANDLE handle, char* caliTitles[]) {
	LOGI("invoke CM_GetAllCalibrationGroupTitles");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->getAllCaliTitle(caliTitles);
}

BOOL  CM_ChooseCalibrationTitle(HANDLE handle, const char* title) {
	LOGI("invoke CM_ChooseCalibrationTitle");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->chooseCaliGroup(title);
}

BOOL  CM_GetCaliGropupItems(HANDLE handle, const char* title, char* groupItemsJson) {
	LOGI("invoke CM_GetCaliGropupItems");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->getGroupItems(title, groupItemsJson);
}

BOOL  CM_EnableCali(HANDLE handle, int caliType, BOOL enable) {
	LOGI("invoke CM_EnableCali");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	bool tEanble = false;
	if (enable == TRUE)
	{
		tEanble = true;
	}
	pSimple->enableCali(caliType, tEanble);
	return TRUE;
}

BOOL CM_LedPickFiltrate(HANDLE handle, int channelType, int aligrithFlag, int saveLedPic, int useFixRadius, int fixRadius, int contoursSquare, /*int LEDnum,*/ double acceptanceFactor, int bynaryDiffVaule,
	OPTIC_DATA* ledData, int LedNumX, int LedNumY, double* suposeLedAreaSize, double* suposeLedAreaSizeOffset, double* actualLedAreaSize/*,int useLocalLedCoordidate,*/
	, const char* aligrithCfg/*,int* pointScope, int binaryCorret, int boundry*/) {

	LOGI("invoke CM_GetCaliGropupItems");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->ledPickFiltrate(channelType, aligrithFlag, saveLedPic, useFixRadius, fixRadius, contoursSquare, acceptanceFactor, bynaryDiffVaule,
		ledData, LedNumX, LedNumY, suposeLedAreaSize, suposeLedAreaSizeOffset, actualLedAreaSize, aligrithCfg);
}

BOOL CM_GetOpticsData(HANDLE handle, OPTIC_DATA* pOD, int pointNummber) {
	//LOGI("invoke CM_GetOpticsData");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->getOpticsData(pOD, pointNummber);
}

BOOL  CM_SetCaliFilePath(HANDLE handle, const char* path) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->setCaliFilePath(path);
}

int CM_InitialGenerateCali(HANDLE handle, CalibrationType ct, int number, int type) {
	LOGI("invoke CM_InitialGenerateCali");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->initialGenerateCali(ct, number, type);
	LOGFMTI("CM_InitialGenerateCali return is:%d", res);
	return res;
}

int CM_SetColorCaliData(HANDLE handle, CalibrationType ct, IRECT ir, int part, float cie_x, float cie_y, float luminace) {
	LOGI("invoke CM_SetColorCaliData");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->setCaliData(ct, ir, part, cie_x, cie_y, luminace);
	LOGFMTI("CM_SetColorCaliData return is:%d", res);
	return res;
}

int CM_SaveCaliFile(HANDLE handle, CalibrationType ct, const char* fileName) {
	LOGI("invoke CM_SaveCaliFile");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->saveCaliFile(ct, fileName);
	LOGFMTI("CM_SaveCaliFile return is:%d", res);
	return res;
}

int CM_LedCalInit(HANDLE handle, const char* fileName) {
	LOGFMTI("invoke CM_LedCalInit");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	pSimple->findLedInitial_s(fileName);
	return TRUE;
}

int CM_LedCalFind(HANDLE handle, int index) {
	LOGFMTI("invoke CM_LedCalFind.index:%d", index);
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->findDotsArray_s(index);
	LOGFMTI("CM_LedCalFind return is:%d", res);
	return res;
}

int CM_LedCalComBine(HANDLE handle, int n_pic, int& w_comb, int& h_comb, BYTE* rst) {
	LOGFMTI("invoke CM_LedCalComBine.n_pic:%d", n_pic);
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	uint32_t tw = 0;
	uint32_t th = 0;
	int res = pSimple->combinespadingData_s(n_pic, &tw, &th, rst);
	w_comb = tw;
	h_comb = th;
	LOGFMTI("CM_LedCalComBine return is:%d", res);
	return res;
}

int CM_LedCalFindHighDensity(HANDLE handle, int& number_x, int& number_y, float& interval_x, float& interval_y, float& angle, OPTIC_DATA* pOD) {
	LOGFMTI("invoke CM_LedCalFindHighDensity");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	if (number_x * number_y <= 0)
	{
		return FALSE;
	}
	double* px = new double[number_x * number_y];
	double* py = new double[number_x * number_y];
	int res = pSimple->findLedHighDensity(number_x, number_y, interval_x, interval_y, angle, px, py);

	for (int i = 0; i < number_x * number_y; i++)
	{
		pOD[i].px = int(px[i]);
		pOD[i].py = int(py[i]);
		pOD[i].shape = 0;
		pOD[i].w_radius = 0;
	}
	delete[]px;
	delete[]py;
	LOGFMTI("CM_LedCalFindHighDensity return is:%d", res);
	return res;
}

int CM_DebugImage(HANDLE handle, const char* fn, int imgType) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->debugImage(fn, imgType);
}

int CM_InsertCaliGroup(HANDLE handle, const char* caliTitle, float gain, int ct, int channelType, const char* caliFile, BOOL newGroup) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->insertCaliGroup(caliTitle, gain, (CalibrationType)ct, channelType, caliFile, newGroup);
}

int CM_ReSaveDcf(HANDLE handle, const char* fn) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->reSaveDcf(fn);
}

int CM_ZipFromDcf(HANDLE handle, const char* dcfName, const char* zipFn) {
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	return pSimple->zipFromDcf(dcfName, zipFn);
}

BOOL  CM_ReleaseCameraManagerSimple(HANDLE handle) {
	LOGI("invoke CM_ReleaseCameraManagerSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	delete pSimple;
	map_Handle.erase(handle);

	return CM_ReleaseCameraManager(handle);
}

void CM_GetWhiteBalance(int w, int h, int bpp, const char* srcBgr, float* exp, float* balanceParameters, char* dstBgrData) {

	LOGI("do white balance");
	int type = CV_16UC3;
	if (bpp == 8)
	{
		type = CV_8UC3;
	}

	const cv::Mat src(h, w, type, (uchar*)srcBgr);


	cv::Mat arr[3];
	cv::split(src, arr);

	uchar* grayR = arr[2].data;
	uchar* grayG = arr[1].data;
	uchar* grayB = arr[0].data;

	float tR = exp[1] / exp[0];
	float tB = exp[1] / exp[2];
	if (bpp == 16)
	{
		//���������ֱ�������ͨ����KeyValueKeyValue KeyValue KeyValueKeyValue
		float parameterR = tR * balanceParameters[0] / 256;
		float parameterG = balanceParameters[1] / 256;
		float parameterB = tB * balanceParameters[2] / 256;
		int bppLength = 65536;
		uchar* lut = (uchar*)malloc(bppLength);
		for (int i = 0; i < bppLength; i++)
		{
			int value = i * parameterR;
			//lut[i] = i * parameterR;
			if (value > 255)
			{
				lut[i] = 255;
			}
			else
			{
				lut[i] = value;
			}
		}
		ushort* turnData = (ushort*)grayR;
		int index = 2;
		for (int i = 0; i < w * h; i++) {
			dstBgrData[index] = lut[turnData[i]];
			index += 3;
		}
		for (int i = 0; i < bppLength; i++)
		{
			//lut[i] = i * parameterG;
			int value = i * parameterG;
			if (value > 255)
			{
				lut[i] = 255;
			}
			else
			{
				lut[i] = value;
			}
		}
		turnData = (ushort*)grayG;
		index = 1;
		for (int i = 0; i < w * h; i++) {
			dstBgrData[index] = lut[turnData[i]];
			index += 3;
		}
		for (int i = 0; i < bppLength; i++)
		{
			//lut[i] = i * parameterB;
			int value = i * parameterB;
			if (value > 255)
			{
				lut[i] = 255;
			}
			else
			{
				lut[i] = value;
			}
		}
		turnData = (ushort*)grayB;
		index = 0;
		for (int i = 0; i < w * h; i++) {
			dstBgrData[index] = lut[turnData[i]];
			index += 3;
		}
		free(lut);

		return;
	}
	else
	{
		float parameterR = tR * balanceParameters[0];
		float parameterG = balanceParameters[1];
		float parameterB = tB * balanceParameters[2];
		int bppLength = 256;
		uchar* lut = (uchar*)malloc(bppLength);
		for (int i = 0; i < bppLength; i++)
		{
			//lut[i] = i * parameterR;
			int value = i * parameterR;
			if (value > 255)
			{
				lut[i] = 255;
			}
			else
			{
				lut[i] = value;
			}
		}
		int index = 2;
		for (int i = 0; i < w * h; i++) {
			dstBgrData[index] = lut[grayR[i]];
			index += 3;
		}
		for (int i = 0; i < bppLength; i++)
		{
			//lut[i] = i * parameterG;
			int value = i * parameterG;
			if (value > 255)
			{
				lut[i] = 255;
			}
			else
			{
				lut[i] = value;
			}
		}
		index = 1;
		for (int i = 0; i < w * h; i++) {
			dstBgrData[index] = lut[grayG[i]];
			index += 3;
		}
		for (int i = 0; i < bppLength; i++)
		{
			//lut[i] = i * parameterB;
			int value = i * parameterB;
			if (value > 255)
			{
				lut[i] = 255;
			}
			else
			{
				lut[i] = value;
			}
		}
		index = 0;
		for (int i = 0; i < w * h; i++) {
			dstBgrData[index] = lut[grayB[i]];
			index += 3;
		}
		free(lut);
	}

}

#pragma region �����ǲ���

BOOL  CM_GetSpNamesSimple(HANDLE handle, char* SpectrometerName) {
	Json::Value v;
	v["name"].append("default");

	Json::StreamWriterBuilder writer;
	std::string output = Json::writeString(writer, v);
	memcpy(SpectrometerName, output.c_str(), output.length() + 1);
	return TRUE;
}

BOOL  CM_OpenSpectrometerSimple(HANDLE handle, const char* SpectrometerName) {

	LOGI("invoke CM_OpenSpectrometerSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->openSpectrometer();
	LOGFMTI("CM_OpenSpectrometerSimple return is:%d", res);
	return res;
}

BOOL  CM_CloseSpectrometerSimple(HANDLE handle, const char* SpectrometerName) {

	LOGI("invoke CM_CloseSpectrometerSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->closeSpectrometer();
	LOGFMTI("CM_CloseSpectrometerSimple return is:%d", res);
	return res;
}

BOOL  CM_LoadFileSimple(HANDLE handle, const char* SpectrometerName, int type, const char* fn) {

	LOGI("invoke CM_LoadFileSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = FALSE;
	//[0,9]��������
	if (type >= 0 && type < 10)
	{
		res = pSimple->loadSpectrometerCfgFile(type, fn);
		LOGFMTI("CM_LoadFileSimple return is:%d", res);

	}
	return res;
}

BOOL  CM_GenerateSpDarkDataSimple(HANDLE handle, const char* SpectrometerName, int type, float fTimeStart, int iAveNum, int nStepTime, int nStepCount) {

	LOGI("invoke CM_GenerateSpDarkDataSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->spectrometerDarkCali(type, fTimeStart, nStepTime, nStepCount, iAveNum);

	LOGFMTI("CM_GenerateSpDarkDataSimple return is:%d", res);
	return res;
}

BOOL  CM_DoSpMeasureSimple(HANDLE handle, const char* SpectrometerName, /*TRIGGER_MODE TriggerMode,*/ int darkMode, float fIntTime, int iAveNum, COLOR_PARA& dPara) {

	LOGI("invoke CM_DoSpMeasureSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->doSpectrometerMeasure(/*TriggerMode, */darkMode, fIntTime, iAveNum, dPara);

	LOGFMTI("CM_DoSpMeasureSimple return is:%d", res);
	return res;
}

BOOL CM_DoSpMeasureSimpleJson(HANDLE handle, const char* SpectrometerName, const char* paramJson, char* resultBuff, int& resLen) {

	LOGI("invoke CM_DoSpMeasureSimpleJson");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->doSpectrometerMeasure(paramJson, resultBuff, resLen);

	LOGFMTI("CM_DoSpMeasureSimpleJson return is:%d", res);
	return res;
}

BOOL  CM_GetSpAutoTime(HANDLE handle, const char* SpectrometerName, float& fIntTime, int iLimitTime, float fTimeB, int useSaturation, int nSaturation) {

	LOGI("invoke CM_GetSpAutoTime");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->getSpectrometerAutoTime(fIntTime, iLimitTime, fTimeB, useSaturation, nSaturation);

	LOGFMTI("CM_GetSpAutoTime return is:%d", res);
	return res;
}

BOOL  CM_EnableRealTimeCaliBySpect(HANDLE handle, const char* SpectrometerName, int enable, float MeasureTime, int iAveNum, PointInt center, int radius_w, int darkMode, int h) {
	LOGI("invoke CM_EnableRealTimeCaliBySpect");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->enableRealTimeCaliBySpect(enable, darkMode, MeasureTime, iAveNum, center, radius_w, h);

	LOGFMTI("CM_EnableRealTimeCaliBySpect return is:%d", res);
	return res;
}

#pragma endregion


int CM_CalcFovSimple(HANDLE handle, ChannelTypeSimple chooseChannels, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, float* coordinates, FovPattern pattern, FovType type) {
	LOGI("invoke CM_CalcFovSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->caclFov(chooseChannels, Radio, cameraDegrees, fovDegrees, thresholdValue, dFovDist, coordinates, pattern, type);
	LOGFMTI("CM_CalcFovSimple return is:%d", res);
	return res;
}

int CM_CalcSfrSimple(HANDLE handle, ChannelTypeSimple chooseChannels, IRECT rtROI, double gamma, float* pdfrequency, float* pdomainSamplingData, int nLen) {
	LOGI("invoke CM_CalcSfrSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->caclSFR(chooseChannels, rtROI, gamma, pdfrequency, pdomainSamplingData, nLen);
	LOGFMTI("CM_CalcSfrSimple return is:%d", res);
	return res;
}

double CM_CalcMtfSimple(HANDLE handle, ChannelTypeSimple chooseChannels, EvaFunc type, int dx, int dy, int ksize, double dRatio) {
	LOGI("invoke CM_CalcMtfSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	double res = pSimple->caclMTF(chooseChannels, type, dx, dy, ksize, dRatio);

	LOGFMTI("CM_CalcMtfSimple return is:%f", res);
	return res;
}

int CM_CalcGhostSimple(HANDLE handle, ChannelTypeSimple chooseChannels, const int radius, int LedNums_X, int LedNums_Y, float ratioH, float ratioL, char* path, int& allLedPixelsNummber, int& LED_Nummber, int& allGhostPixelsNummber, int& Ghost_Nummber) {
	LOGI("invoke CM_CalcGhostSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->caclGhost(chooseChannels, radius, LedNums_X, LedNums_Y, ratioH, ratioL, path, allLedPixelsNummber, LED_Nummber, allGhostPixelsNummber, Ghost_Nummber);
	LOGFMTI("CM_CalcGhostSimple return is:%d", res);
	return res;
}

int CM_GetGhostResultSimple(HANDLE handle, float* LedCenters_X, float* LedCenters_Y, float* LedAverageGray, float* ghostAverageGray, int* singleLedPixelNum, int* LED_pixel_X, int* LED_pixel_Y, int* singleGhostPixelNum, int* Ghost_pixel_X, int* Ghost_pixel_Y) {
	LOGI("invoke CM_GetGhostResultSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->_getGhostResult(LedCenters_X, LedCenters_Y, LedAverageGray, ghostAverageGray, singleLedPixelNum, LED_pixel_X, LED_pixel_Y, singleGhostPixelNum, Ghost_pixel_X, Ghost_pixel_Y);
	LOGFMTI("CM_GetGhostResultSimple return is:%d", res);
	return res;
}

int CM_CalcDistortionSimple(HANDLE handle, ChannelTypeSimple chooseChannels, ISIZE iSize, BlobThreParams tBlobThreParams, float* finalPointsX, float* finalPointsY, double& pointx, double& pointy, double& maxErrorRatio, double& t, CornerType type, SlopeType sType, LayoutType lType, DistortionType dType, int timeoutNumLimit) {
	LOGI("invoke CM_CalcDistortionSimple");
	colorVisionSimple* pSimple = findHandle(handle);
	if (pSimple == nullptr) {
		return FALSE;
	}
	int res = pSimple->caclDistortion(chooseChannels, iSize, tBlobThreParams, finalPointsX, finalPointsY, pointx, pointy, maxErrorRatio, t, type, sType, lType, dType, timeoutNumLimit);
	LOGFMTI("CM_CalcDistortionSimple return is:%d", res);
	return res;
}