#include "stdafx.h"
#include <iostream>
#include "colorVisionSimple.h"
#include "cvConvertXYZ.h"
#include<fstream>
#include "log4z.h"
#include"json\json.h"
#include "CameraManager.h"
#include "cvCamera.h"
#include "cvAutoFocus.h"
#include "cvCalibration.h"
#include <io.h>
#include "cvErrorDefine.h"
#include "cvOpencvHandle.h"
#include"cvSensorComm.h"
#include "LedCheck.h"
#include "cvOled.h"
//#include "CvOledInterface.h"
#include "zip.h"
#include "ZipHelper.h"
#include "cvSpectrometer.h"
#include "cvCommonCalc.h"
#include "OpencvManager.h"
#include "SdkSpecialCfg.h"

using namespace std;
#define _DEBUG_IMAGE 1


colorVisionSimple::colorVisionSimple(const char* cameraCfgFile)
	: version(0), partNumber(3),
	port(nullptr)
	, channelTye(nullptr)
	, cfgStream(nullptr), caliFilePath("cfg//")
	, color_lum(CalibrationType::Empty_Num)
	, expRGB(new float[3] { 10, 10, 10 })
	, readFileSuccess(false)
	, useComCfw(FALSE)
	, useRelay(FALSE)
	, useFocusCom(FALSE)
	, calibrationWay(0)
	, chooseIndex(-1)
	, cameraBkId("")
	, tSrcData(nullptr)
	, tXyzData(nullptr)
	, m_handleMotorBase(nullptr)
	, m_handleMotorChild(nullptr)
	, caliImageArr(nullptr)
	, caliDataInputArr(nullptr)
	, spectHandle(nullptr)
	, spectIsOpen(false)
	, spectRealCaliIsActive(false)
	, relaySetByManual(false)

{
	std::ifstream fs(cameraCfgFile, std::ios::binary | std::ios::ate);
	if (!fs.is_open()) {
		LOGE("����dcf" + string(cameraCfgFile) + "ʧ�ܣ�");
		//cout << "fail to read dcf:" << cameraCfgFile << endl;

	}
	else
	{
		readFileSuccess = true;
		LOGI("����dcf :" + string(cameraCfgFile) + "�ɹ���");
		std::streamsize size = fs.tellg();
		cfgStreamLength = size;
		fs.seekg(0, std::ios::beg);

		cfgStream = new char[size];

		if (fs.read(cfgStream, size))
		{
			readFileSuccess = true;
		}
		else
		{
			cout << "fail to read dcfData";
			readFileSuccess = false;
		}
	}


	fs.close();

	formatCameraCfg();

	//��dcf���б�ѡIDʱ�������������
	if (cameraBkId != "")
	{
		LOGI("��ѡID in the DCF: " + cameraBkId);
		char idJson[512];
		int res = CM_GetCameraID(this->camType, idJson, 512);
		if (res != 1)
		{
			LOGE("no camera IS connected!!\n");
			readFileSuccess = false;
		}
		Json::Value v;
		Json::Reader r;
		r.parse(idJson, v);
		int camNum = v["number"].asInt();
		for (int i = 0; i < camNum; i++)
		{
			std::string tId = v["ID"][i].asCString();
			if (tId == cameraBkId)
			{
				cameraId = cameraBkId;
				LOGI("�����˱�ѡID: " + cameraBkId);

			}
		}
	}


}

colorVisionSimple::~colorVisionSimple() {
	CM_UnInitXYZ(this->cameraHandle);
	if (useComCfw == TRUE)
	{
		BOOL re = CM_SetPortComParam(cameraHandle, FALSE, this->cfwCom.c_str(), this->cfwBoud);
	}
	if (useFocusCom == TRUE)
	{
		CM_ShutDown(m_handleMotorBase);
	}

	if (useRelay) {
		CM_SetRelayComParam(cameraHandle, FALSE, relayCom.c_str(), relayBaudRate, 0);
	}

	if (port != nullptr)
	{
		delete[]port;
		port = nullptr;
	}
	if (channelTye != nullptr)
	{
		delete[]channelTye;
		channelTye = nullptr;
	}
	if (cfgStream != nullptr)
	{
		delete[]cfgStream;
		cfgStream = nullptr;
	}
	delete[]expRGB;
	if (tSrcData != nullptr)
	{
		delete[]tSrcData;
	}
	if (tXyzData != nullptr)
	{
		delete[]tXyzData;
	}

	if (caliImageArr != nullptr)
	{
		for (int i = 0; i < caliImageArrNum; i++)
		{
			if (caliImageArr[i].pData != nullptr)
			{
				delete[]caliImageArr[i].pData;
			}

		}
		delete[]caliDataInputArr;
		delete[]caliImageArr;
	}
	/*std::map<int, rebuiltData*>::iterator it = map_ledData_Y.begin();

	while (it != map_ledData_Y.end())
	{

		delete[] it->second->m_data;
		map_ledData_Y.erase(it);

		it++;
	}
	map_ledData_Y.clear();*/
	CvOledRealse();
	LOGI("~colorVisionSimple\n");
}

bool colorVisionSimple::getReadSuccess() {
	return this->readFileSuccess;
}

void colorVisionSimple::setCameraHandle(HANDLE handle) {
	this->cameraHandle = handle;
	initialCamera();

}

void colorVisionSimple::formatCameraCfg() {

	if (!readFileSuccess)
	{
		return;
	}
	char head[8] = { '\0' };
	memcpy(head, cfgStream + 1, 7);
	string strHead = string(head);
	if (strHead != "version")
	{
		LOGE("IS NOT the DCF supplied by ColorVision!");
		readFileSuccess = false;
		return;
	}
	char* pMoudle = getModulePoint(VERSION);
	pMoudle += 9;
	int* p = (int*)(pMoudle);
	this->version = *p;
	pMoudle += 4;

	this->maxValue = (uchar)*pMoudle;
	pMoudle++;
	this->minValue = (uchar)*pMoudle;
	pMoudle++;
	this->turnValue = (uchar)*pMoudle;
	unEncryptionByte(cfgStream + 64, cfgStreamLength - 64);

	pMoudle = getModulePoint(PART_LENGTH);
	p = (int*)(pMoudle);
	this->partNumber = *p;



	pMoudle = getModulePoint(CAMERA_HARD_WARA);

	p = (int*)pMoudle;
	//����Ӳ������
	this->camType = (CameraType)(*p);
	p++;
	this->takePicMode = (TakeImageMode)(*p);
	p++;
	this->srcBpp = *p;
	p++;
	useComCfw = *p;
	p++;
	cfwBoud = *p;
	p++;
	this->useFocusCom = *p;
	p++;
	this->focusType = (FOCUS_COMMUN)(*p);
	p++;
	this->focusBoud = *p;
	p++;

	if (port == nullptr)
	{
		port = new int[3];
	}

	memcpy(port, p, 12);

	p += 3;
	if (channelTye == nullptr)
	{
		channelTye = new ChannelType[3];
	}

	memcpy(channelTye, p, 12);

	//�趨id
	pMoudle = getModulePoint(ID);
	//char c = pMoudle[0];
	p = (int*)pMoudle;
	//int idLen = *p;
	p++;
	char* pId = (char*)p;
	//memcpy(pId, p, idLen);
	this->cameraId = string(pId);
	LOGI("cameraID in DCF:" + cameraId);

	//��������
	pMoudle = getModulePoint(CALIBRATION_FILE);

	Json::Reader rJson;
	Json::Value root;

	rJson.parse(pMoudle, root);
	int caliGroupNum = root["caliGroupNum"].asInt();

	this->vector_caliGroups.clear();
	for (int i = 0; i < caliGroupNum; i++)
	{
		caliGroup singleCaliGroup;
		singleCaliGroup.caliFileNum = root["list_caliGroup"][i]["list_cali"].size();
		singleCaliGroup.groupTitle = root["list_caliGroup"][i]["groupTitle"].asCString();
		singleCaliGroup.gain = root["list_caliGroup"][i]["gain"].asFloat();
		for (int j = 0; j < singleCaliGroup.caliFileNum; j++)
		{
			caliCell caliCellOne;
			caliCellOne.caliType = (CalibrationType)root["list_caliGroup"][i]["list_cali"][j]["caliType"].asInt();
			caliCellOne.echannelType = (ChannelType)root["list_caliGroup"][i]["list_cali"][j]["channelType"].asInt();
			caliCellOne.caliFile = root["list_caliGroup"][i]["list_cali"][j]["caliFile"].asCString();
			singleCaliGroup.list_cali.push_back(caliCellOne);
		}
		vector_caliGroups.push_back(singleCaliGroup);
	}




	//���Ӳ������json
	pMoudle = getModulePoint(CAMERA_CFG);

	rJson.parse(pMoudle, root);

	Json::StreamWriterBuilder writerBuilder;
	unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
	ostringstream ss;
	json_write->write(root, &ss);
	this->cameraCfgStr = ss.str();
	ss.str("");
	ss.clear();

	//�Զ��ع�json
	pMoudle = getModulePoint(AUTO_EXP);
	rJson.parse(pMoudle, root);
	json_write->write(root, &ss);
	this->autoExposureCfg = ss.str();
	ss.str("");
	ss.clear();

	//���鲿������
	pMoudle = getModulePoint(OTHER_CFG);
	if (pMoudle != nullptr) {
		rJson.parse(pMoudle, root);
		this->motorScopeMin = root["motorScopeMin"].asInt();
		this->motorScopeMax = root["motorScopeMax"].asInt();

		if (!root["calibrationWay"].isNull())
		{
			this->calibrationWay = root["calibrationWay"].asInt();
		}
		if (!root["cameraBkId"].isNull())
		{
			this->cameraBkId = root["cameraBkId"].asCString();
		}

		if (!root["relay"].isNull())
		{
			this->useRelay = root["relay"]["use"].asInt();

			this->relayBaudRate = root["relay"]["baudRate"].asInt();
		}
		/*HANDLE spectHandle;
	 bool spectExsit;
	 int spectType;
	 string spectId;
	 int blindType;
	 int blindPort;
	 int blindBaud;*/

		if (!root["spectrometer"][0].isNull())
		{
			Json::Value t = root["spectrometer"][0];

			spectExsit = t["isExsit"].asBool();
			spectType = t["type"].asInt();
			spectId = t["id"].asCString();
			blindType = t["blindType"].asInt();
			if (spectType == 1)
			{
				spectBoud = 9600;
			}
			blindPort = t["blindPort"].asInt();
			spMeasurePort = t["measurePort"].asInt();
			blindBaud = t["blindBaud"].asInt();
		}

	}

}

char* colorVisionSimple::getModulePoint(cfgModule m) {

	if (m >= partNumber) {
		return nullptr;
	}
	//������������
	char* p_moudle = cfgStream + 64;
	if (m == PART_LENGTH) {
		return p_moudle;
	}

	//���������鳤��ͷָ��
	int* index = (int*)(p_moudle + 4);

	p_moudle = cfgStream;

	for (int i = 0; i < m; i++)
	{

		p_moudle += index[i];
	}
	return p_moudle;
}

void colorVisionSimple::addPartLength(cfgModule m, int length) {
	if (m >= partNumber) {
		return;
	}
	//������������
	char* pPartArr = cfgStream + 64 + 4;
	int* p = (int*)pPartArr;
	p[m] += length;

}

BOOL colorVisionSimple::openCamera(TakeImageMode tMode) {

	BOOL result = FALSE;

	if (tMode == TakeImageMode::Live)
	{
		result = CM_SetTakeImageMode(cameraHandle, TakeImageMode::Live);
		if (result != TRUE) {
			return result;
		}

		result = CM_SetImageBpp(cameraHandle, 8);
		if (result != TRUE) {
			return result;
		}


	}
	else
	{

		result = CM_SetTakeImageMode(cameraHandle, this->takePicMode);
		if (result != TRUE) {
			LOGFMTI("CM_OpenSimple return:%d", result);
			return result;
		}
		result = CM_SetImageBpp(cameraHandle, this->srcBpp);
		if (result != TRUE) {
			LOGFMTI("CM_OpenSimple return:%d", result);
			return result;
		}

	}
	result = CM_Open(this->cameraHandle);

	if (result != TRUE) {
		LOGFMTI("CM_OpenSimple return:%d", result);
		return result;
	}

	CM_InitXYZ(this->cameraHandle);


	result = CM_SetGain(cameraHandle, this->gain);
	if (result != TRUE) {
		LOGFMTI("CM_OpenSimple return:%d", result);
		return result;
	}
	LOGFMTI("CM_OpenSimple return:%d", result);
	return TRUE;
}

TakeImageMode colorVisionSimple::getTakeImageMode() {
	return this->takePicMode;
}

CameraType  colorVisionSimple::getCameraType() {
	return this->camType;
}

std::string colorVisionSimple::getCameraId() {
	return cameraId;
}

BOOL colorVisionSimple::setExp(float exp1, float exp2, float exp3) {
	int tempPort[3];

	ChannelType tempType[3];
	sequencePortChannelType(tempPort, tempType);

	CameraMode m = CameraMode::LV_MODE;

	CM_GetMode(cameraHandle, m);

	if (m == CameraMode::BV_MODE || m == CameraMode::LV_MODE)
	{
		this->expRGB[0] = exp1;
		this->expRGB[1] = exp1;
		this->expRGB[2] = exp1;
	}

	else
	{
		float expTemp[3];
		for (int i = 0; i < 3; i++)
		{
			switch (tempType[i])
			{
			case CHANNEL_R:
				expTemp[i] = exp1;
				break;
			case CHANNEL_G:
				expTemp[i] = exp2;
				break;
			case CHANNEL_B:
				expTemp[i] = exp3;
				break;
			default:
				break;
			}
		}
		this->expRGB[0] = expTemp[0];
		this->expRGB[1] = expTemp[1];
		this->expRGB[2] = expTemp[2];

	}


	BOOL Re = FALSE;
	Re = CM_SetExpTime(cameraHandle, exp1);

	if (Re != TRUE)
	{
		LOGFMTI("CM_SetExpTimeSimple return is:%d", Re);
		return Re;
	}
	LOGFMTI("CM_SetExpTimeSimple return is:%d", TRUE);
	return TRUE;
}

BOOL colorVisionSimple::getAutoExp(float& exp1, float& exp2, float& exp3, float* saturtion) {
	float tempExp[3];
	float tempSaturation[3];
	BOOL result = CM_GetAutoExpTime(cameraHandle, tempExp, tempSaturation);

	int tempPort[3];
	ChannelType tempType[3];
	sequencePortChannelType(tempPort, tempType);

	for (int i = 0; i < 3; i++)
	{
		switch (tempType[i])
		{
		case CHANNEL_R:
			exp1 = tempExp[0];
			saturtion[0] = tempSaturation[0];
			break;
		case CHANNEL_G:
			exp2 = tempExp[1];
			saturtion[1] = tempSaturation[1];
			break;
		case CHANNEL_B:
			exp3 = tempExp[2];
			saturtion[2] = tempSaturation[2];
			break;
		default:
			break;
		}
	}
	LOGFMTI("CM_GetAutoExpTimeSimple return is:%d", result);
	return result;
}

BOOL colorVisionSimple::initialCamera() {
	Json::Value root;
	Json::Value arr;
	arr["title"] = Json::Value("Red");
	arr["cfwport"] = Json::Value(port[0]);
	arr["chtype"] = Json::Value(channelTye[0]);
	root["channelCfg"].append(arr);

	arr["title"] = Json::Value("Green");
	arr["cfwport"] = Json::Value(port[1]);
	arr["chtype"] = Json::Value(channelTye[1]);
	root["channelCfg"].append(arr);

	arr["title"] = Json::Value("Blue");
	arr["cfwport"] = Json::Value(port[2]);
	arr["chtype"] = Json::Value(channelTye[2]);
	root["channelCfg"].append(arr);

	//ת��string
	Json::StreamWriterBuilder writerBuilder;
	unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
	ostringstream ss;
	json_write->write(root, &ss);
	string strContent = ss.str();

	BOOL Re = CM_UpdateCfgJson(cameraHandle, ConfigType::Cfg_Channels, strContent.c_str());
	if (Re == TRUE)
	{
		LOGI("����ͨ����\n" + strContent + "\n");
	}

	Re = CM_UpdateCfgJson(cameraHandle, ConfigType::Cfg_Camera, cameraCfgStr.c_str());
	if (Re == TRUE)
	{
		LOGI("����������ã��ɹ�\n");
	}

	Re = CM_UpdateCfgJson(cameraHandle, ConfigType::Cfg_ExpTime, autoExposureCfg.c_str());

	return TRUE;
}

BOOL colorVisionSimple::getFrame(uint& w, uint& h, uint& srcbpp, uint& bpp, uint& channels, BYTE* srcimgdata, BYTE* imgdata) {

	int result = FALSE;
	int tryCount = 0;
	while (true) {
		result = CM_GetFrame(cameraHandle, combineParameter_Json(expRGB).c_str(), w, h, srcbpp, bpp, channels, srcimgdata, imgdata);

		if (result == CV_ERR_SUCCESS)
		{
			LOGFMTI("CM_GetFrameSimple return is:%d �� ����%d�γɹ�", result, tryCount + 1);
			m_w = w;
			m_h = h;
			m_channels = channels;
			/*OPTIC_DATA op[1];
			op[0].shape = 0;
			op[0].px = 1000;
			op[0].py = 1000;
			op[0].w_radius = 100;

			CM_GetOpticsData(cameraHandle, op, 1);
			LOGFMTI("x:%f,y:%f,Lum:%f", op[0].cie_x, op[0].cie_y, op[0].Y);*/
			//������ʵʱ���ݽ���
			realTimeCaliBySpect(imgdata);
			/*CM_GetOpticsData(cameraHandle, op, 1);
			LOGFMTI("realTimeCali-x:%f,y:%f,Lum:%f", op[0].cie_x, op[0].cie_y, op[0].Y);*/
			if (tSrcData == nullptr) {
				tSrcData = new BYTE[srcbpp / 8 * m_w * m_h * m_channels];
			}
			memcpy(tSrcData, srcimgdata, srcbpp / 8 * m_w * m_h * m_channels);

			if (tXyzData == nullptr) {
				tXyzData = new BYTE[4 * m_w * m_h * m_channels];
			}
			memcpy(tXyzData, imgdata, 4 * m_w * m_h * m_channels);
			return result;
		}

		if (result == CV_ERR_CAM_ONLINE)
		{
			LOGI(" \nCamera OFFLINE ,Sleep 10seconds to wait\n");
			Sleep(10000);
		}


		LOGI(" before CM_Reset");
		/*if (useRelay == 1)
		{

			if (accessToReadRelayCfg() && readRelayCfg(relayCom)) {
				/ *û���ֶ�����relay��COM�����Զ�ȡ�ļ�������* /
				CM_SetComSimple(cameraHandle, 2, relayCom.c_str());
			}
			CM_DoRelay(cameraHandle);
			//CM_OpenSimple(cameraHandle);
		}*/
		/*else
		{*/
		CM_ResetEx(cameraHandle, 3000);
		Sleep(5000);

		if (useRelay == 1 && this->useComCfw == TRUE)
		{
			BOOL re = CM_SetPortComParam(cameraHandle, TRUE, this->cfwCom.c_str(), this->cfwBoud);

			if (re != 1) {
				LOGFMTD("Fialed connect port after reset - time: % d", tryCount);
			}
		}
		//}
		int res = CM_OpenSimple(cameraHandle);

		if (res != 1) {
			LOGFMTD("open camera Fialed after reset-time:%d", tryCount);
			tryCount++;
			continue;
		}
		LOGI(" AFTER CM_Reset");
		CM_SetGain(cameraHandle, this->gain);

		if (useRelay) {

			int ndPort = -1;
			int spMessurePort = -1;
			if (readSimpleMemory(ndPort, spMessurePort)) {
				if (ndPort > -1)
				{
					CM_SetPort(cameraHandle, ndPort);
				}
				if (_currentSpPort > -1)
				{
					CM_SetPort(cameraHandle, _currentSpPort);
				}
			}
		}

		if (tryCount == 3)
		{
			LOGFMTI("CM_GetFrameSimple return is:%d �� ����%d��ʧ��", result, tryCount);
			return result;

		}

		tryCount++;
	}

}

int colorVisionSimple::getCaliGroupNum() {
	return this->vector_caliGroups.size();
}

BOOL colorVisionSimple::getAllCaliTitle(char* caliTitles[]) {
	string title = "";
	for (int i = 0; i < vector_caliGroups.size(); i++)
	{
		title = vector_caliGroups[i].groupTitle;
		memcpy(caliTitles[i], title.c_str(), title.size() + 1);
	}
	return TRUE;
}

BOOL colorVisionSimple::chooseCaliGroup(string caliGroupTitle) {
	bool findOut = false;

	for (int i = 0; i < vector_caliGroups.size(); i++)
	{
		if (vector_caliGroups[i].groupTitle == caliGroupTitle)
		{
			chooseIndex = i;
			findOut = true;
			break;
		}
	}
	if (!findOut)
	{
		chooseIndex = -1;
		LOGFMTI("fail to update title:%s", caliGroupTitle.c_str());
		LOGFMTI("CM_ChooseCalibrationTitle FAIL- return is :%d!", FALSE);
		return FALSE;
	}
	this->gain = vector_caliGroups[chooseIndex].gain;

	CM_SetGain(cameraHandle, this->gain);

	LOGI("��������Ϊ��\nTitle-> " + caliGroupTitle + this->makeCFG_calibration(vector_caliGroups[chooseIndex]));

	BOOL re = CM_UpdateCfgJson(cameraHandle, ConfigType::Cfg_Calibration, this->makeCFG_calibration(vector_caliGroups[chooseIndex]).c_str());
	LOGFMTI("CM_ChooseCalibrationTitle return is :%d!", re);
	return TRUE;

}

BOOL colorVisionSimple::getGroupItems(std::string caliGroupTitle, char* groupItemsJson) {
	bool findOut = false;
	int chooseIndex = 0;
	for (int i = 0; i < vector_caliGroups.size(); i++)
	{
		if (vector_caliGroups[i].groupTitle == caliGroupTitle)
		{
			chooseIndex = i;
			findOut = true;
			break;
		}
	}
	if (!findOut)
	{
		return FALSE;
	}

	string caliItemJson = this->makeCFG_calibration(vector_caliGroups[chooseIndex]);
	memcpy(groupItemsJson, caliItemJson.c_str(), caliItemJson.length() + 1);
	return TRUE;
}


BOOL colorVisionSimple::getParameters(char* pParameter) {
	Json::Value v;
	v["cameraId"] = cameraId;
	v["cameraType"] = (int)camType;
	v["takeMode"] = (int)takePicMode;
	v["srcBpp"] = srcBpp;
	v["currentGain"] = gain;

	//ת��string
	Json::StreamWriterBuilder writerBuilder;
	unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
	ostringstream ss;
	json_write->write(v, &ss);
	string strContent = ss.str();

	memcpy(pParameter, strContent.c_str(), strContent.length() + 1);
	return TRUE;

}

void colorVisionSimple::enableCali(int caliType, bool enable) {

	if (caliType == -1)
	{
		//������-1ʱ���������н����ļ���״̬
		for (int i = 0; i < int(CalibrationType::Empty_Num); i++)
		{
			m_caliTitleEnble.allCaliTitles[i].enable = enable;
		}
		return;
	}

	if (caliType == 6)
	{
		//������ɫ�Ƚ����Ƿ񼤻�
		m_caliTitleEnble.allCaliTitles[6].enable = enable;
		m_caliTitleEnble.allCaliTitles[8].enable = enable;
		m_caliTitleEnble.allCaliTitles[9].enable = enable;
		return;
	}
	else
	{
		m_caliTitleEnble.allCaliTitles[caliType].enable = enable;
	}
}

BOOL colorVisionSimple::setCaliFilePath(std::string path) {
	if (_access(path.c_str(), 0) == -1) {
		LOGE("���ý����ļ��洢·��ʧ�ܣ�" + path + "-�ļ�·��������");
		return FALSE;
	}
	this->caliFilePath = path;
	LOGI("���ý����ļ�·��Ϊ��" + path);
	return TRUE;
}

BOOL colorVisionSimple::setCfwCom(const char* ComNum) {
	this->cfwCom = string(ComNum);
	if (this->useComCfw == TRUE)
	{
		BOOL re = CM_SetPortComParam(cameraHandle, TRUE, ComNum, this->cfwBoud);
		LOGFMTI("CM_SetPortComSimple return is:%d", re);
		return re;
	}
	LOGFMTI("CM_SetPortComSimple return is:%d", TRUE);
	return TRUE;
}

BOOL colorVisionSimple::setFocusCom(const char* ComNum) {
	BOOL result = FALSE;
	if (this->useFocusCom == TRUE)
	{
		//LOGFMTI("focusType:%d,COMNum:%s focusBoud:%d", focusBoud);
		result = CM_InitComEx(m_handleMotorBase, this->focusType, ComNum, focusBoud);
		if (result != TRUE)
		{
			return result;
		}

	}
	return TRUE;
}

BOOL colorVisionSimple::setSpectrometerCom(const char* ComNum) {

	//��������Ӳ����Ҫ����COMʱ
	if (this->spectType == 1)
	{
		spectCom = string(ComNum);
		return TRUE;
	}
	LOGI("the spectrometer is no need to set COM for this type!");
	return FALSE;
}

BOOL colorVisionSimple::setRelayCom(const char* ComNum, int sleepTime) {
	this->relayCom = string(ComNum);
	CM_SetRelayComParam(cameraHandle, TRUE, relayCom.c_str(), relayBaudRate, sleepTime);
	relaySetByManual = true;
	return TRUE;
}

bool colorVisionSimple::accessToReadRelayCfg() {
	LOGFMTI("useRelay:%d,relaySetByManual:%d", useRelay, relaySetByManual);
	if (useRelay == 1 && !relaySetByManual) {
		/*
				dcf�������˼̵���������û���ֶ����ü̵���COM
		*/

		return true;
	}
	LOGI("have no access to relaySetByManual");
	return false;
}

ImageChannelType colorVisionSimple::channelTypeToSdk(ChannelType c) {
	ImageChannelType imgType;
	switch (c) {
	case CHANNEL_R:
		imgType = ImageChannelType::Gray_X;
		break;
	case CHANNEL_G:
		imgType = ImageChannelType::Gray_Y;
		break;
	case CHANNEL_B:
		imgType = ImageChannelType::Gray_Z;
		break;
	default:
		imgType = ImageChannelType::Gray_X;
		break;
	}
	return imgType;
}

void colorVisionSimple::EncryptionByte(char* cArr, int length) {
	for (int i = 0; i < length; i++)
	{
		cArr[i] += turnValue;
	}
}

void colorVisionSimple::unEncryptionByte(char* cArr, int length) {

	for (int i = 0; i < length; i++)
	{
		cArr[i] -= turnValue;
	}
}

bool colorVisionSimple::isUseCaliType(vector<caliCell>& vc, int caliT) {

	CalibrationType ct = CalibrationType(caliT);
	for (int i = 0; i < vc.size(); i++)
	{
		if (vc[i].caliType == ct)
		{
			return true;
		}
	}
	return false;
}

std::string colorVisionSimple::combineParameter_Json(float* exp) {

	int* tempPort = new int[3];

	ChannelType* tempChannelType = new ChannelType[3];
	for (int i = 0; i < 3; i++)
	{

		tempPort[i] = port[i];
		tempChannelType[i] = channelTye[i];
	}

	//ͨ����
	int channelsNum = 3;
	CM_GetChannels(cameraHandle, channelsNum);
	CameraMode m = CameraMode::LV_MODE;
	CM_GetMode(cameraHandle, m);

	if (m == CameraMode::CV_MODE)
	{
		sequencePortChannelType(tempPort, tempChannelType);
	}


	Json::Value root, lumChromaCheck, lum, channels, channels1, channels2, checkItem;

	root["channelCount"] = channelsNum;
	root["measureCount"] = 1;

	root["title"] = "ceshi001";
	root["autoExpFlag"] = false;

	//��ɫ�Ƚ�������
	int caliType = 99;
	bool enableCali = false;
	string caliTitle = "";

	switch (color_lum)
	{

	case CalibrationType::Luminance:
		caliType = 6;
		enableCali = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Luminance)].enable;
		caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Luminance)].title[1];
		break;
	case CalibrationType::LumOneColor:
		break;
	case CalibrationType::LumFourColor:
		caliType = 8;
		enableCali = m_caliTitleEnble.allCaliTitles[int(CalibrationType::LumFourColor)].enable;
		caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::LumFourColor)].title[1];
		break;
	case CalibrationType::LumMultiColor:
		caliType = 9;
		enableCali = m_caliTitleEnble.allCaliTitles[int(CalibrationType::LumMultiColor)].enable;
		caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::LumMultiColor)].title[1];
		break;

	default:
		break;
	}



	//��ɫ�Ƚ���ѡ��
	lumChromaCheck["type"] = caliType;
	lumChromaCheck["enable"] = enableCali;
	lumChromaCheck["title"] = caliTitle;
	root["lumChromaCheck"] = Json::Value(lumChromaCheck);

	std::vector<caliCell>tCaliList;

	if (chooseIndex > -1)
	{
		tCaliList = vector_caliGroups[chooseIndex].list_cali;
		if (calibrationWay == 1)
		{
			Json::Value caliItem;

			for (int i = 0; i < tCaliList.size(); i++)
			{
				int caliTypeInt = (int)tCaliList[i].caliType;
				if (caliTypeInt == 6 || caliTypeInt == 8 || caliTypeInt == 9)
				{
					continue;
				}
				caliItem["type"] = caliTypeInt;
				caliItem["enable"] = m_caliTitleEnble.allCaliTitles[caliTypeInt].enable;
				caliItem["title"] = m_caliTitleEnble.allCaliTitles[caliTypeInt].title[1];
				root["calibrationlist"].append(caliItem);
			}
		}
	}




	//��һͨ��
	channels["exp"] = expRGB[0];
	channels["cfwport"] = tempPort[0];
	channels["channelType"] = tempChannelType[0];
	channels["fileName"] = " ";

	if (calibrationWay == 0)
	{
		int caliT = int(CalibrationType::DSNU);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 4;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[0])];
			if (channelsNum == 1)
			{
				caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[1];
			}
			checkItem["title"] = caliTitle;
			channels["check"]["dsnuCheck"] = Json::Value(checkItem);
		}


		//��һͨ�����ȳ���ʶ���������ṩ��Ϊ׼
		caliT = int(CalibrationType::Uniformity);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 5;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[0])];
			if (channelsNum == 1)
			{
				caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[1];
			}
			checkItem["title"] = caliTitle;
			channels["check"]["uniformityCheck"] = Json::Value(checkItem);
		}

		caliT = int(CalibrationType::DefectPoint);
		if (isUseCaliType(tCaliList, caliT))
		{
			checkItem["type"] = 3;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[0])];
			if (channelsNum == 1)
			{
				caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[1];
			}
			checkItem["title"] = caliTitle;
			channels["check"]["defectCheck"] = Json::Value(checkItem);
		}

		caliT = int(CalibrationType::Distortion);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 11;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[0])];
			if (channelsNum == 1)
			{
				caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[1];
			}
			checkItem["title"] = caliTitle;
			channels["check"]["distortionCheck"] = Json::Value(checkItem);
		}


	}
	root["channels"].append(channels);

	if (channelsNum == 1) {
		//ת��string
		Json::StreamWriterBuilder writerBuilder;
		unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
		ostringstream ss;
		json_write->write(root, &ss);
		string strContent = ss.str();
		delete[]tempPort;
		delete[]tempChannelType;
		return strContent;
	}

	//�ڶ�ͨ��

	channels1["exp"] = expRGB[1];
	channels1["cfwport"] = tempPort[1];
	channels1["channelType"] = tempChannelType[1];
	channels1["fileName"] = "er.tif";

	int caliT = int(CalibrationType::DSNU);
	if (calibrationWay == 0) {
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 4;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			checkItem["title"] = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[1])];
			channels1["check"]["dsnuCheck"] = Json::Value(checkItem);
		}


		//�ڶ�ͨ�����ȳ���ʶ���������ṩ��Ϊ׼
		caliT = int(CalibrationType::Uniformity);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 5;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			checkItem["title"] = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[1])];
			channels1["check"]["uniformityCheck"] = Json::Value(checkItem);
		}

		caliT = int(CalibrationType::DefectPoint);
		if (isUseCaliType(tCaliList, caliT))
		{
			checkItem["type"] = 3;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[1])];
			checkItem["title"] = caliTitle;
			channels["check"]["defectCheck"] = Json::Value(checkItem);
		}

		caliT = int(CalibrationType::Distortion);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 11;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			checkItem["title"] = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[1])];
			channels1["check"]["distortionCheck"] = Json::Value(checkItem);
		}
	}
	root["channels"].append(channels1);

	//����ͨ��

	channels2["exp"] = expRGB[2];
	channels2["cfwport"] = tempPort[2];
	channels2["channelType"] = tempChannelType[2];
	channels2["fileName"] = "lan.tif";

	caliT = int(CalibrationType::DSNU);
	if (calibrationWay == 0) {
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 4;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			checkItem["title"] = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[2])];
			channels2["check"]["dsnuCheck"] = Json::Value(checkItem);
		}


		//����ͨ�����ȳ���ʶ���������ṩ��Ϊ׼
		caliT = int(CalibrationType::Uniformity);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 5;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			checkItem["title"] = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[2])];
			channels2["check"]["uniformityCheck"] = Json::Value(checkItem);
		}

		caliT = int(CalibrationType::DefectPoint);
		if (isUseCaliType(tCaliList, caliT))
		{
			checkItem["type"] = 3;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			caliTitle = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[2])];
			checkItem["title"] = caliTitle;
			channels["check"]["defectCheck"] = Json::Value(checkItem);
		}

		caliT = int(CalibrationType::Distortion);
		if (isUseCaliType(tCaliList, caliT)) {
			checkItem["type"] = 11;
			checkItem["enable"] = m_caliTitleEnble.allCaliTitles[caliT].enable;
			checkItem["title"] = m_caliTitleEnble.allCaliTitles[caliT].title[int(tempChannelType[2])];
			channels2["check"]["distortionCheck"] = Json::Value(checkItem);
		}

	}
	root["channels"].append(channels2);

	//ת��string
	Json::StreamWriterBuilder writerBuilder;
	unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
	ostringstream ss;
	json_write->write(root, &ss);
	string strContent = ss.str();
	delete[]tempPort;
	delete[]tempChannelType;
	LOGI("simple JSon:\n" + strContent);
	return strContent;

}

string colorVisionSimple::makeCFG_calibration(const caliGroup& cg) {
	Json::Value v;
	Json::Value item;

	string caliTitle = "";

	for (int i = 0; i < cg.list_cali.size(); i++)
	{

		//ͨ������R��G��B
		ChannelType cType = cg.list_cali[i].echannelType;

		CalibrationType caliType = cg.list_cali[i].caliType;

		switch (caliType)
		{
		case CalibrationType::DarkNoise:
			break;
		case CalibrationType::DefectWPoint:
			break;
		case CalibrationType::DefectBPoint:
			break;
		case CalibrationType::DefectPoint:
			switch (cType)
			{
			case CHANNEL_R:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DefectPoint)].title[0];
				break;
			case CHANNEL_G:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DefectPoint)].title[1];
				break;
			case CHANNEL_B:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DefectPoint)].title[2];
				break;
			default:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DefectPoint)].title[1];
				break;
			}
			break;
		case CalibrationType::DSNU:
			switch (cType)
			{
			case CHANNEL_R:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DSNU)].title[0];
				break;
			case CHANNEL_G:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DSNU)].title[1];
				break;
			case CHANNEL_B:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DSNU)].title[2];
				break;
			default:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::DSNU)].title[1];
				break;
			}
			break;

		case CalibrationType::Uniformity:
			switch (cType)
			{
			case CHANNEL_R:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Uniformity)].title[0];
				break;
			case CHANNEL_G:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Uniformity)].title[1];
				break;
			case CHANNEL_B:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Uniformity)].title[2];
				break;
			default:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Uniformity)].title[1];
				break;
			}
			break;
		case CalibrationType::Luminance:
			caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Luminance)].title[1];
			color_lum = caliType;
			break;
		case CalibrationType::LumOneColor:
			break;
		case CalibrationType::LumFourColor:
			caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::LumFourColor)].title[1];
			color_lum = caliType;
			break;
		case CalibrationType::LumMultiColor:
			caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::LumMultiColor)].title[1];
			color_lum = caliType;
			break;
		case CalibrationType::LumColor:
			break;
		case CalibrationType::Distortion:
			switch (cType)
			{
			case CHANNEL_R:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Distortion)].title[0];
				break;
			case CHANNEL_G:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Distortion)].title[1];
				break;
			case CHANNEL_B:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Distortion)].title[2];
				break;
			default:
				caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::Distortion)].title[1];
				break;
			}
			break;
		case CalibrationType::ColorShift:
			break;
		case CalibrationType::ColorDiff:
			caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::ColorDiff)].title[1];
			break;
		case CalibrationType::AngleShift:
			caliTitle = m_caliTitleEnble.allCaliTitles[int(CalibrationType::AngleShift)].title[1];
			break;
		case CalibrationType::Empty_Num:
			break;
		default:
			break;
		}

		item["type"] = int(caliType);
		item["title"] = caliTitle;

		item["doc"] = caliFilePath + cg.list_cali[i].caliFile;
		v["calibrationLibCfg"].append(item);

	}

	//ת��string
	Json::StreamWriterBuilder writerBuilder;
	unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
	ostringstream ss;
	json_write->write(v, &ss);
	string strContent = ss.str();
	return strContent;
}


void colorVisionSimple::sequencePortChannelType(int* tempPort, ChannelType* tempType) {


	for (int i = 0; i < 3; i++)
	{

		tempPort[i] = port[i];
		tempType[i] = channelTye[i];
	}

	for (int i = 0; i < 3; i++)
	{
		for (int j = i; j > 0; j--)
		{
			if (tempPort[j] < tempPort[j - 1])
			{
				int p = tempPort[j];
				tempPort[j] = tempPort[j - 1];
				tempPort[j - 1] = p;
				ChannelType t = tempType[j];
				tempType[j] = tempType[j - 1];
				tempType[j - 1] = t;
			}
		}
	}
}

int colorVisionSimple::initialRelayer(int sleepTime) {

	HANDLE comH = CM_InitSensorComm(Communicate_Type::Communicate_Serial);

	int res = CM_InitSerialSensor(comH, relayCom.c_str(), relayBaudRate);

	if (res != 1) {
		CM_UnInitSensorComm(comH);
		return 0;
	}
	byte reChar[256] = { 0xA0, 0x01 ,0x01, 0xA2 };
	char bF[256];

	CM_SendCmdToSensorEx4(comH, reChar, 4);
	Sleep(sleepTime);
	reChar[0] = 0xA0;
	reChar[1] = 0x01;
	reChar[2] = 0x00;
	reChar[3] = 0xA1;
	CM_SendCmdToSensorEx4(comH, reChar, 4);
	Sleep(1000);
	CM_DestroySensor(comH);
	CM_UnInitSensorComm(comH);

	return 1;
}

int colorVisionSimple::getSpecialTasks(char* pTasks) {
	int taskNum = useComCfw + useFocusCom + useRelay;

	if (taskNum == 0)
	{
		string ts = "You don't need to invoke any Function special!just invoke the general Functions.\n";
		memcpy(pTasks, ts.c_str(), ts.length() + 1);
		return taskNum;
	}

	string information = "before open the camera,You must do the things list next...\n\n";

	if (useComCfw == 1)
	{
		information += "You need to invoke the Function:{CM_SetComSimple},the comType is 0,and check the COM  by Device manager yourself!\n\n";
	}

	if (useFocusCom == 1)
	{
		information += "You need to invoke the Function:{CM_SetComSimple},the comType is 1,and check the COM  by Device manager yourself!\n\n";
	}

	if (useRelay == 1)
	{
		information += "You need to invoke the Function:{CM_SetComSimple},the comType is 2,and check the COM  by Device manager yourself!\n\n";
	}
	memcpy(pTasks, information.c_str(), information.length() + 1);
	return taskNum;
}

void colorVisionSimple::findLedInitial_s(const char* cfgFn) {
	ledParameters = string(cfgFn);
	CvOledInit();
	/*std::ifstream fs(cfgFn, std::ios::binary | std::ios::ate);
	if (!fs.is_open()) {

		return;
	}
	else
	{

		std::streamsize size = fs.tellg();

		fs.seekg(0, std::ios::beg);

		char *jsonCfg = new char[size];

		if (fs.read(jsonCfg, size))
		{
			CvLoadParam(jsonCfg);
		}
		delete[]jsonCfg;

	}*/

}

int colorVisionSimple::findDotsArray_s(/*int w, int h, BYTE* imgdata,  CVLED_COLOR color,*/ int index) {
	int type = CV_MAKE_TYPE(CV_16U, m_channels);
	/*cv::Mat src(m_h, m_w, type, tSrcData);
	m_w = src.cols;
	m_h = src.rows;*/


	/*cv::Mat mArr[3];
	cv::split(src, mArr);*/
	string postion = "ledPartPosition.dat";

	int res = findDotsArrayMemImp(m_w, m_h, tSrcData, type, (CVLED_COLOR)1, ledParameters.c_str(), postion.c_str());
	if (res != 0)
	{
		return -99;
	}
	uint32_t w_rebuilt = 0;
	uint32_t h_rebuilt = 0;
	BYTE* reData = new BYTE[m_h * m_w];
	BYTE* tempXYZ = nullptr;
	if (m_channels == 1)
	{
		tempXYZ = tXyzData;
	}
	else {
		tempXYZ = tXyzData + m_w * m_h * 4;
	}


	res = rebuildPixelsMemImp(m_w, m_h, tempXYZ, CV_32FC1, (CVLED_COLOR)1, ledParameters.c_str(), postion.c_str(), &w_rebuilt, &h_rebuilt, reData);
	if (res != 0)
	{
		LOGE("rebuildPixelsMemImp channel Y FAIL!");
		return -99;
	}
	std::map<int, rebuiltData*>::iterator it = map_ledData_Y.begin();

	while (it != map_ledData_Y.end())
	{
		if (it->first == index) {
			delete[] it->second->m_data;
			map_ledData_Y.erase(it);
			break;
		}
		it++;
	}
	BYTE* dstRebuiltData = new BYTE[w_rebuilt * h_rebuilt * 4];
	memcpy(dstRebuiltData, reData, w_rebuilt * h_rebuilt * 4);

	rebuiltData* pr = new rebuiltData(w_rebuilt, h_rebuilt, dstRebuiltData);
	map_ledData_Y.insert(std::pair<int, rebuiltData*>(index, pr));

	if (m_channels == 3)
	{
		res = rebuildPixelsMemImp(m_w, m_h, tXyzData, CV_32FC1, (CVLED_COLOR)1, ledParameters.c_str(), postion.c_str(), &w_rebuilt, &h_rebuilt, reData);
		if (res != 0)
		{
			LOGE("rebuildPixelsMemImp channel X FAIL!");
			return -99;
		}
		it = map_ledData_X.begin();

		while (it != map_ledData_X.end())
		{
			if (it->first == index) {
				delete[] it->second->m_data;
				map_ledData_X.erase(it);
				break;
			}
			it++;
		}
		dstRebuiltData = new BYTE[w_rebuilt * h_rebuilt * 4];
		memcpy(dstRebuiltData, reData, w_rebuilt * h_rebuilt * 4);

		rebuiltData* pr = new rebuiltData(w_rebuilt, h_rebuilt, dstRebuiltData);
		map_ledData_X.insert(std::pair<int, rebuiltData*>(index, pr));

		//Z
		res = rebuildPixelsMemImp(m_w, m_h, tXyzData + m_w * m_h * 8, CV_32FC1, (CVLED_COLOR)1, ledParameters.c_str(), postion.c_str(), &w_rebuilt, &h_rebuilt, reData);
		if (res != 0)
		{
			LOGE("rebuildPixelsMemImp channel Z FAIL!");
			return -99;
		}
		it = map_ledData_Z.begin();

		while (it != map_ledData_Z.end())
		{
			if (it->first == index) {
				delete[] it->second->m_data;
				map_ledData_Z.erase(it);
				break;
			}
			it++;
		}
		dstRebuiltData = new BYTE[w_rebuilt * h_rebuilt * 4];
		memcpy(dstRebuiltData, reData, w_rebuilt * h_rebuilt * 4);

		pr = new rebuiltData(w_rebuilt, h_rebuilt, dstRebuiltData);
		map_ledData_Z.insert(std::pair<int, rebuiltData*>(index, pr));
	}
	delete[]reData;
	return TRUE;
}



int colorVisionSimple::combinespadingData_s(/*int w, int h, BYTE* imadata, int type, */ int n_pic, uint32_t* w_comb, uint32_t* h_comb, BYTE* rst) {

	int dataLength = 0;
	std::map<int, rebuiltData*>::iterator it = map_ledData_Y.begin();
	dataLength = (it->second->m_w * it->second->m_h * 4);
	*w_comb = it->second->m_w;
	*h_comb = it->second->m_h;
	//���ֻ��һ��ͼ
	if (n_pic == 1)
	{
		if (m_channels == 1)
		{
			memcpy(rst, it->second->m_data, dataLength);
			delete[]it->second->m_data;
		}
		else
		{
			memcpy(rst, map_ledData_X[0]->m_data, dataLength);
			delete[] map_ledData_X[0]->m_data;

			memcpy(rst + dataLength, map_ledData_Y[0]->m_data, dataLength);
			delete[] map_ledData_Y[0]->m_data;

			memcpy(rst + dataLength * 2, map_ledData_Z[0]->m_data, dataLength);
			delete[] map_ledData_Z[0]->m_data;
		}
		CM_SetBufferXYZ(cameraHandle, it->second->m_w, it->second->m_h, 32, m_channels, rst);
		return TRUE;
	}

	int tempPicNum = 0;
	while (it != map_ledData_Y.end())
	{
		//
		tempPicNum++;
		it++;
	}

	if (tempPicNum != n_pic)
	{
		LOGFMTI("the LED image num��%d is wrong!", tempPicNum);
		return FALSE;
	}

	BYTE* dstData = new BYTE[dataLength * n_pic];

	int dataIndex = 0;
	for (int i = 0; i < n_pic; i++)
	{
		//int tLength = map_ledData_Y[i]->m_w * map_ledData_Y[i]->m_h * 4 ;
		memcpy(dstData + dataIndex, map_ledData_Y[i]->m_data, dataLength);
		delete[]map_ledData_Y[i]->m_data;
		/*cv::Mat t(map_ledData[i]->m_h, map_ledData[i]->m_w, )
		cv::imwrite("pic\\map_"+to_string(i)+".tif",)*/
		dataIndex += dataLength;
	}
	BYTE* pCutXyz = new BYTE[dataLength * n_pic];
	int ledSpace = sqrt(n_pic);
	int res = combineSpacingDataMemImp(map_ledData_Y[0]->m_w, map_ledData_Y[0]->m_h, dstData, CV_32FC1, dataLength, n_pic, ledSpace, ledSpace, w_comb, h_comb, pCutXyz);
	if (res != 0)
	{
		LOGE("combineSpacingDataMemImp channel Y FAIL!");
		return -99;
	}
	if (m_channels == 1)
	{
		memcpy(rst, pCutXyz, dataLength * n_pic);
	}
	else
	{
		memcpy(rst + dataLength * n_pic, pCutXyz, dataLength * n_pic);
	}
	delete[]pCutXyz;
	if (m_channels == 3)
	{
		dataIndex = 0;
		for (int i = 0; i < n_pic; i++)
		{
			memcpy(dstData + dataIndex, map_ledData_X[i]->m_data, dataLength);
			delete[]map_ledData_X[i]->m_data;
			/*cv::Mat t(map_ledData[i]->m_h, map_ledData[i]->m_w, )
			cv::imwrite("pic\\map_"+to_string(i)+".tif",)*/
			dataIndex += dataLength;
		}
		res = combineSpacingDataMemImp(map_ledData_X[0]->m_w, map_ledData_X[0]->m_h, dstData, CV_32FC1, dataLength, n_pic, ledSpace, ledSpace, w_comb, h_comb, rst);
		if (res != 0)
		{
			LOGE("combineSpacingDataMemImp channel X FAIL!");
			return -99;
		}
		//Z

		dataIndex = 0;
		for (int i = 0; i < n_pic; i++)
		{
			memcpy(dstData + dataIndex, map_ledData_Z[i]->m_data, dataLength);
			delete[]map_ledData_Z[i]->m_data;
			/*cv::Mat t(map_ledData[i]->m_h, map_ledData[i]->m_w, )
			cv::imwrite("pic\\map_"+to_string(i)+".tif",)*/
			dataIndex += dataLength;
		}
		res = combineSpacingDataMemImp(map_ledData_Z[0]->m_w, map_ledData_Z[0]->m_h, dstData, CV_32FC1, dataLength, n_pic, ledSpace, ledSpace, w_comb, h_comb, rst + dataLength * 2 * n_pic);
		if (res != 0)
		{
			LOGE("combineSpacingDataMemImp channel Z FAIL!");
			return -99;
		}
	}

	CM_SetBufferXYZ(cameraHandle, *w_comb, *h_comb, 32, m_channels, rst);
	delete[]dstData;
	map_ledData_X.clear();
	map_ledData_Y.clear();
	map_ledData_Z.clear();
	return TRUE;
}


int colorVisionSimple::findLedHighDensity(int& col, int& row, float& x_interval, float& y_interval, float& angle, double* pX, double* pY) {
	int type = CV_MAKE_TYPE(CV_16U, m_channels);

	int res = findDotsArrayLowPitchMemPtsMemReturnMemImp(m_w, m_h, tSrcData, type, (CVLED_COLOR)1, ledParameters.c_str(), col, row, x_interval, y_interval, angle, pX, pY);
	if (res != 0) {
		return FALSE;
	}
	return TRUE;
}

int colorVisionSimple::ledPickFiltrate(int channelType, int aligrithFlag, int saveLedPic, int useFixRadius, int fixRadius, int contoursSquare, /*int LEDnum,*/ double acceptanceFactor, int bynaryDiffVaule,
	OPTIC_DATA* ledData, int LedNumX, int LedNumY, double* suposeLedAreaSize, double* suposeLedAreaSizeOffset, double* actualLedAreaSize/*,int useLocalLedCoordidate,*/
	, const char* aligrithCfg/*,int* pointScope, int binaryCorret, int boundry*/) {
	int* tLedX = new int[LedNumX * LedNumY];
	int* tLedY = new int[LedNumX * LedNumY];
	double* tLedRadus = new double[LedNumX * LedNumY];

	//���ò���
	int* pointScope = nullptr;
	int binaryCorret = 0;
	int boundry = 0;
	bool useLocalCoordate = false;
	float* localMark = nullptr;
	double* localX = nullptr;
	double* localY = nullptr;
	/*~~~~~~~~~~~~~~~~*/

	//TEST
	/*cv::Mat test =cv:: imread("tiff\\ledcheck.tif",cv:: IMREAD_UNCHANGED);
	m_w = test.cols;
	m_h = test.rows;
	m_channels = test.channels();
	tSrcData = test.data;*/
	/*~~~~~~~~~~~~~~~~*/

	int res = LedCheckYaQi(saveLedPic, channelType, m_w, m_h, srcBpp, m_channels, tSrcData, useFixRadius, fixRadius
		, contoursSquare, LedNumX * LedNumY, acceptanceFactor, bynaryDiffVaule, tLedRadus, tLedX, tLedY, LedNumX, LedNumY, pointScope
		, binaryCorret, boundry, suposeLedAreaSize, suposeLedAreaSizeOffset, actualLedAreaSize, useLocalCoordate, localMark, localX, localY);

	if (res == 1)
	{
		for (int i = 0; i < LedNumX * LedNumY; i++)
		{
			ledData[i].px = tLedX[i];
			ledData[i].py = tLedY[i];
			ledData[i].w_radius = (int)tLedRadus[i];

		}
	}
	LOGFMTI("ledPickFiltrate return is:%d", res);
	delete[]tLedX;
	delete[]tLedY;
	delete[]tLedRadus;
	return res;
}


int colorVisionSimple::getOpticsData(OPTIC_DATA* pOD, int pointNummber) {
	if (m_channels == 3)
	{
		for (int i = 0; i < pointNummber; i++)
		{
			//����ע��ΪԲʱ
			if (pOD[i].shape == 0)
			{
				CM_GetXYZCircle(cameraHandle, pOD[i].px, pOD[i].py, pOD[i].X, pOD[i].Y, pOD[i].Z, pOD[i].w_radius);
				CM_GetxyuvCCTWaveCircle(cameraHandle, pOD[i].px, pOD[i].py, pOD[i].cie_x, pOD[i].cie_y, pOD[i].cie_u, pOD[i].cie_v, pOD[i].CCT, pOD[i].dominantWave, pOD[i].w_radius);
			}

			//����ע��Ϊ����ʱ
			if (pOD[i].shape == 1)
			{
				CM_GetXYZRect(cameraHandle, pOD[i].px, pOD[i].py, pOD[i].X, pOD[i].Y, pOD[i].Z, pOD[i].w_radius, pOD[i].h);
				CM_GetxyuvCCTWaveRect(cameraHandle, pOD[i].px, pOD[i].py, pOD[i].cie_x, pOD[i].cie_y, pOD[i].cie_u, pOD[i].cie_v, pOD[i].CCT, pOD[i].dominantWave, pOD[i].w_radius, pOD[i].h);
			}
		}
	}

	//�������ȼ�ʱ
	else
	{
		for (int i = 0; i < pointNummber; i++)
		{
			//����ע��ΪԲʱ
			if (pOD[i].shape == 0)
			{
				CM_GetYCircle(cameraHandle, pOD[i].px, pOD[i].py, pOD[i].Y, pOD[i].w_radius);

			}

			//����ע��Ϊ����ʱ
			if (pOD[i].shape == 1)
			{
				CM_GetYRect(cameraHandle, pOD[i].px, pOD[i].py, pOD[i].Y, pOD[i].w_radius, pOD[i].h);

			}
			pOD[i].X = -99;
			pOD[i].Z = -99;
			pOD[i].cie_x = -99;
			pOD[i].cie_y = -99;
			pOD[i].cie_u = -99;
			pOD[i].cie_v = -99;
			pOD[i].CCT = -99;
			pOD[i].dominantWave = -99;
		}
	}
	Json::Value v;
	Json::Value item;
	for (int i = 0; i < pointNummber; i++)
	{
		item["number"] = i;
		string shape = "Circle";
		if (pOD[i].shape == 1)
		{
			shape = "Rect";
		}

		item["shape"] = shape;

		item["center"] = "(" + to_string(pOD[i].px) + "," + to_string(pOD[i].py) + ")";

		item["size"] = "(" + to_string(pOD[i].w_radius) + "," + to_string(pOD[i].h) + ")";

		item["Cie"] = "(" + to_string(pOD[i].cie_x) + "," + to_string(pOD[i].cie_y) + ")";

		item["Luminance"] = to_string(pOD[i].Y);

		v["opticsData"].append(item);
	}
	Json::StreamWriterBuilder writer;
	std::string output = Json::writeString(writer, v);
	output = "\n\n" + output + "\n\n";
	LOGI(output.c_str());
	return CV_ERR_SUCCESS;
}

BOOL  colorVisionSimple::creatMotorHandle(HANDLE& handle, UCHAR ucMachineNO) {
	if (useFocusCom == 0)
	{
		LOGE("the device has no motor!");
		return CV_ERR_MOTOR_NO;
	}
	if (m_handleMotorBase == nullptr)
	{
		LOGE("please set the motor COM first");
		return FALSE;
	}
	int result = CM_InitMachine(m_handleMotorBase, handle, ucMachineNO);
	result = CM_ClearAlarm(handle);
	if (result != TRUE)
	{
		LOGE("Fail to CM_ClearAlarm");
		CM_ShutDown(handle);
		handle = nullptr;
		return result;
	}
	m_handleMotorChild = handle;
	setMotorScope(m_handleMotorChild, motorScopeMin, motorScopeMax);
	GoHome(m_handleMotorChild);
	return result;

}

int colorVisionSimple::calFoucusLevel(const IRECT* pI, float* pResult, int length, int flag) {
	return CalFocusLevelByEdge(m_w, m_h, srcBpp, m_channels, tSrcData, pI, pResult, length, flag);
}

int colorVisionSimple::initialGenerateCali(CalibrationType ct, int number, int type) {
	switch (ct)
	{
	case CalibrationType::DarkNoise:
		break;
	case CalibrationType::DefectWPoint:
		break;
	case CalibrationType::DefectBPoint:
		break;
	case CalibrationType::DefectPoint:
		break;
	case CalibrationType::DSNU:
		break;
	case CalibrationType::Uniformity:
		break;
	case CalibrationType::Luminance:
		break;
	case CalibrationType::LumOneColor:
		break;
	case CalibrationType::LumFourColor:
		if (caliImageArr != nullptr)
		{
			delete[]caliImageArr;
			delete[]caliDataInputArr;
		}
		caliImageArr = new HImage[4];
		caliDataInputArr = new IIntputData[4];
		for (int i = 0; i < 4; i++)
		{
			caliImageArr[i].iChls = -99;
			caliImageArr[i].pData = nullptr;
		}
		caliImageArrNum = 4;
		break;
	case CalibrationType::LumMultiColor:
		break;
	case CalibrationType::LumColor:
		break;
	case CalibrationType::Distortion:
		break;
	case CalibrationType::ColorShift:
		break;
	case CalibrationType::LineArity:
		break;
	case CalibrationType::ColorDiff:
		break;
	case CalibrationType::AngleShift:
		break;
	case CalibrationType::Empty_Num:
		break;
	default:
		return 0;
	}
	return 1;
}

int colorVisionSimple::setCaliData(CalibrationType ct, IRECT ir, int part, float cie_x, float cie_y, float luminace) {
	if (tSrcData == nullptr)
	{
		LOGE("please take a image first");
		return FALSE;
	}

	if (caliImageArr == nullptr)
	{

		LOGE("You need to invoke initialGenenrateCaliFile first!");
		return FALSE;
	}

	if (ir.x<0 || (ir.cx + ir.x)>m_w || ir.y<0 || (ir.y + ir.cy)>m_h)
	{
		caliImageArr[part].iHei = -99;
		LOGE("the rect is out of scope!");
		return FALSE;
	}
	BYTE* pHdata = new BYTE[srcBpp / 8 * ir.cx * ir.cy * m_channels];
	BYTE* pTempData = pHdata;
	int length = srcBpp / 8 * ir.cx * m_channels;
	for (int i = ir.y; i < ir.y + ir.cy; i++)
	{

		memcpy(pTempData, tSrcData + srcBpp / 8 * m_channels * (i * m_w + ir.x), length);
		pTempData += length;

	}
	//����ȡͼ���ָ�븳ֵ�������Ӧ��
	caliImageArr[part].iBpp = srcBpp;
	caliImageArr[part].iChls = m_channels;
	caliImageArr[part].iWid = ir.cx;
	caliImageArr[part].iHei = ir.cy;
	if (caliImageArr[part].pData != nullptr)
	{
		delete[]caliImageArr[part].pData;
	}
	caliImageArr[part].pData = pHdata;

	//��ɫ��������ȡ����ɫ������
	caliDataInputArr[part].iCx = cie_x;
	caliDataInputArr[part].iCy = cie_y;
	caliDataInputArr[part].iLv = luminace;
	caliDataInputArr[part].iexp_x = expRGB[0];
	caliDataInputArr[part].iexp_y = expRGB[1];
	caliDataInputArr[part].iexp_z = expRGB[2];
	return TRUE;
}

int colorVisionSimple::saveCaliFile(CalibrationType ct, const char* fileName) {
	IRECT tRect[4];
	switch (ct)
	{
	case CalibrationType::DarkNoise:
		break;
	case CalibrationType::DefectWPoint:
		break;
	case CalibrationType::DefectBPoint:
		break;
	case CalibrationType::DefectPoint:
		break;
	case CalibrationType::DSNU:
		break;
	case CalibrationType::Uniformity:
		break;
	case CalibrationType::Luminance:
		break;
	case CalibrationType::LumOneColor:
		break;
	case CalibrationType::LumFourColor:
		if (caliImageArr == nullptr)
		{
			LOGE("at least invoke CM_InitialGenerateCali once!");
			return FALSE;
		}
		for (int i = 0; i < 4; i++)
		{
			if (caliImageArr[i].iChls == -99)
			{
				LOGFMTI("rect index:%d is empty,please set first!", i);
				return FALSE;
			}
			tRect[i].x = 0;
			tRect[i].y = 0;
			tRect[i].cx = caliImageArr[i].iWid;
			tRect[i].cy = caliImageArr[i].iHei;
		}
		return CM_SaveColorFour(caliImageArr, tRect, caliDataInputArr, fileName);
		break;
	case CalibrationType::LumMultiColor:
		break;
	case CalibrationType::LumColor:
		break;
	case CalibrationType::Distortion:
		break;
	case CalibrationType::ColorShift:
		break;
	case CalibrationType::LineArity:
		break;
	case CalibrationType::ColorDiff:
		break;
	case CalibrationType::AngleShift:
		break;
	case CalibrationType::Empty_Num:
		return FALSE;
	default:
		return FALSE;
	}
	return TRUE;
}

int colorVisionSimple::getLedPosition(OPTIC_DATA* pOD, int& pointNummber) {
	cv::Mat src(m_h, m_w, CV_16UC3, tSrcData);

	return 1;

}

int colorVisionSimple::debugImage(const char* fn, int imgType) {
#if _DEBUG_IMAGE 1
	cv::Mat src = cv::imread(fn, cv::IMREAD_UNCHANGED);
	if (src.empty())
	{
		return -1;
	}
	m_w = src.cols;
	m_h = src.rows;

	if (src.depth() == CV_16U)
	{
		srcBpp = 16;
		m_channels = src.channels();
	}
	if (src.depth() == CV_8U)
	{
		srcBpp = 8;
		m_channels = src.channels();
	}


	switch (imgType)
	{
	case 0:

		delete[]tSrcData;
		tSrcData = new BYTE[srcBpp / 8 * m_w * m_h * m_channels];
		memcpy(tSrcData, src.data, srcBpp / 8 * m_w * m_h * m_channels);
		break;
	case 1:
		//m_channels = 1;
		delete[]tXyzData;
		tXyzData = new BYTE[4 * m_w * m_h * m_channels];
		memcpy(tXyzData, src.data, 4 * m_w * m_h);
		break;
	case 2:
		m_channels = 3;
		memcpy(tXyzData + 4 * m_w * m_h, src.data, 4 * m_w * m_h);
		break;
	case 3:
		m_channels = 3;
		memcpy(tXyzData + 8 * m_w * m_h, src.data, 4 * m_w * m_h);
		break;
	default:
		break;

	}

	return TRUE;
#else
	return FALSE;
#endif

}

bool colorVisionSimple::mergeMat(map<int, rebuiltData*>& pM, int num, BYTE* pData) {
	return true;
	/*int length = 0;
	int w = pM[0]->m_w;
	int h = pM[0]->m_h;
	for (int i = 0; i < num; i++)
	{
		length += pM[i]->m_h * pM[i]->m_w * 4;
	}
	BYTE* pT = new BYTE[length];
	float* pFt = (float*)pT;
	int dd = sqrt(num);
	for (int picN = 0; picN < num; picN++)
	{
		for (int i = 0; i < h; i += 4)
		{
			for (int j = 0; j < w; j += 4) {
				pFt[i * w + j] = pM[picN]->m_data[]
			}
		}
	}
	*/
}

int colorVisionSimple::insertCaliGroup(const char* caliTitle, float gain, CalibrationType ct, int channelType, const char* caliFile, BOOL newGroup) {
	string title(caliTitle);
	string fn(caliFile);

	for (int i = 0; i < vector_caliGroups.size(); i++)
	{
		for (int j = 0; j < vector_caliGroups[i].list_cali.size(); j++)
		{
			if (fn == vector_caliGroups[i].list_cali[j].caliFile && title != vector_caliGroups[i].groupTitle)
			{
				LOGE("the cali file name is exsit!");
				return FALSE;
			}
		}
	}

	//������һ���µĽ�����ʱ
	if (newGroup == 1)
	{
		for (int i = 0; i < vector_caliGroups.size(); i++)
		{
			if (title == vector_caliGroups[i].groupTitle)
			{
				LOGE("the new caliTile is exist!");
				return FALSE;
			}
		}
		caliGroup cg;
		cg.gain = gain;
		cg.groupTitle = title;

		//���������ڵ�ǰ�����ϵĽ���

		if (chooseIndex > -1) {
			vector<caliCell>::iterator it = vector_caliGroups[chooseIndex].list_cali.begin();
			LOGFMTI("vector_caliGroups[chooseIndex].list_cali size:%d", vector_caliGroups[chooseIndex].list_cali.size());

			while (it != vector_caliGroups[chooseIndex].list_cali.end())
			{
				caliCell cc = *it;
				if (cc.caliType != CalibrationType::Luminance && cc.caliType != CalibrationType::LumFourColor && cc.caliType != CalibrationType::LumMultiColor)
				{
					if (cc.caliType != ct || cc.echannelType != channelType)
					{
						cg.list_cali.push_back(cc);

						LOGI("add cali file exist" + it->caliFile);
					}
				}
				it++;
			}

		}
		caliCell ccF;
		ccF.caliFile = caliFile;
		ccF.caliType = ct;
		ccF.echannelType = (ChannelType)channelType;
		cg.list_cali.push_back(ccF);
		cg.caliFileNum = cg.list_cali.size();

		vector_caliGroups.push_back(cg);

		return TRUE;

	}

	else
	{

		for (int i = 0; i < vector_caliGroups.size(); i++)
		{
			if (vector_caliGroups[i].groupTitle == title)
			{
				vector_caliGroups[i].gain = gain;
				for (int j = 0; j < vector_caliGroups[i].list_cali.size(); j++)
				{
					if (vector_caliGroups[i].list_cali[j].caliType == ct && vector_caliGroups[i].list_cali[j].echannelType == channelType)
					{
						vector_caliGroups[i].list_cali[j].caliFile = caliFile;
						return TRUE;
					}
				}

				caliCell cc;
				cc.caliFile = caliFile;
				cc.caliType = ct;
				cc.echannelType = (ChannelType)channelType;
				vector_caliGroups[i].caliFileNum = vector_caliGroups[i].list_cali.size();
				vector_caliGroups[i].list_cali.push_back(cc);
				return TRUE;
			}
		}
	}
	return FALSE;
}

int colorVisionSimple::reSaveDcf(const char* fn) {
	ofstream fs(fn, ios::binary | ios::trunc);

	int partLength[] = { /*�汾*/64, /*��ģ����ռ�ֽ���*/128,/*Ӳ��*/64,/*id*/1024,/*�����ļ�����*/64,/*cameracf*/512,/*�Զ��ع�*/512,/*��������*/10000 };
	string headTitle = "bversion:";
	fs.write(headTitle.c_str(), headTitle.size());

	// д��汾
	fs.write(reinterpret_cast<const char*>(&version), sizeof(version));

	// д��汾���֣��ֽ����飩
	unsigned char versionPart[] = { maxValue, minValue, turnValue };
	fs.write(reinterpret_cast<const char*>(versionPart), sizeof(versionPart));
	char* buffer = new char[partLength[0] - 16];
	memset(buffer, '\0', partLength[0] - 16);
	fs.write(buffer, partLength[0] - 16);	//ͷ�������64�ֽ�
	delete[]buffer;

	Json::Value v;
	Json::Value v1;
	Json::Value v2;
	v["caliGroupNum"] = vector_caliGroups.size();
	for (int i = 0; i < vector_caliGroups.size(); i++)
	{
		v1.clear();
		v1["groupTitle"] = vector_caliGroups[i].groupTitle;
		v1["gain"] = vector_caliGroups[i].gain;

		for (int j = 0; j < vector_caliGroups[i].list_cali.size(); j++)
		{
			v2["caliType"] = (int)vector_caliGroups[i].list_cali[j].caliType;
			v2["channelType"] = (int)vector_caliGroups[i].list_cali[j].echannelType;
			v2["caliFile"] = vector_caliGroups[i].list_cali[j].caliFile;
			v1["list_cali"].append(v2);
		}
		v["list_caliGroup"].append(v1);
	}

	Json::StreamWriterBuilder writer;
	std::string strCaliPart = Json::writeString(writer, v);	//��������string
	partLength[4] = strCaliPart.length() + 64;


	buffer = new char[partLength[1]];
	memset(buffer, '\0', partLength[1]);
	int* pInt = (int*)buffer;
	*pInt = 8;//ģ������
	memcpy(buffer + 4, partLength, 32);
	EncryptionByte(buffer, partLength[1]);
	fs.write(buffer, partLength[1]);;
	delete[]buffer;

	//Ӳ�����֣�������͡�ģʽ��ͨ�����á����ڵ�
	buffer = new char[partLength[2]];
	memset(buffer, '\0', partLength[2]);
	pInt = (int*)buffer;
	pInt[0] = (int)camType;
	pInt[1] = (int)takePicMode;
	pInt[2] = srcBpp;
	pInt[3] = useComCfw;
	pInt[4] = cfwBoud;
	pInt[5] = useFocusCom;
	pInt[6] = (int)focusType;
	pInt[7] = focusBoud;
	memcpy(buffer + 32, port, 12);		//ת�ֿ�
	memcpy(buffer + 44, channelTye, 12);	//��ɫƬ����
	EncryptionByte(buffer, partLength[2]);
	fs.write(buffer, partLength[2]);
	delete[]buffer;

	//id���֣�Ŀǰֻ�����ID
	buffer = new char[partLength[3]];
	memset(buffer, '\0', partLength[3]);
	pInt = (int*)buffer;
	*pInt = cameraId.length();
	memcpy(buffer + 4, cameraId.c_str(), cameraId.length() + 1);
	EncryptionByte(buffer, partLength[3]);
	fs.write(buffer, partLength[3]);
	delete[]buffer;

	//д����ģ���json  
	buffer = new char[partLength[4]];
	memset(buffer, '\0', partLength[4]);
	memcpy(buffer, strCaliPart.c_str(), strCaliPart.length() + 1);
	EncryptionByte(buffer, partLength[4]);
	fs.write(buffer, partLength[4]);
	delete[]buffer;

	//д���Ӳ������
	buffer = new char[partLength[5]];
	memset(buffer, '\0', partLength[5]);
	memcpy(buffer, cameraCfgStr.c_str(), cameraCfgStr.length() + 1);

	EncryptionByte(buffer, partLength[5]);
	fs.write(buffer, partLength[5]);
	delete[]buffer;

	//д�Զ��ع�����
	buffer = new char[partLength[6]];
	memset(buffer, '\0', partLength[6]);
	memcpy(buffer, autoExposureCfg.c_str(), autoExposureCfg.length() + 1);
	EncryptionByte(buffer, partLength[6]);
	fs.write(buffer, partLength[6]);
	delete[]buffer;

	//д��������
	buffer = new char[partLength[7]];
	memset(buffer, '\0', partLength[7]);
	v.clear();


	v["relay"]["use"] = useRelay;
	v["relay"]["baudRate"] = relayBaudRate;


	v["motorScopeMin"] = motorScopeMin;
	v["motorScopeMax"] = motorScopeMax;
	v["calibrationWay"] = calibrationWay;
	v["cameraBkId"] = cameraBkId;


	//����������list

	Json::Value json_spectrometer;
	json_spectrometer["isExsit"] = spectExsit;
	json_spectrometer["type"] = spectType;
	json_spectrometer["id"] = spectId;
	json_spectrometer["blindType"] = blindType;
	json_spectrometer["blindPort"] = blindPort;
	json_spectrometer["measurePort"] = spMeasurePort;//
	json_spectrometer["blindBaud"] = blindBaud;

	v["spectrometer"].append(json_spectrometer);

	string other = Json::writeString(writer, v);
	memcpy(buffer, other.c_str(), other.length() + 1);
	EncryptionByte(buffer, partLength[7]);
	fs.write(buffer, partLength[7]);
	delete[]buffer;


	//��β��ȫ�ļ���100KB
	int currentDataLength = 0;
	for (int i = 0; i < 8; i++)
	{
		currentDataLength += partLength[i];
	}
	const int fileBytes = 1024 * 100;     //���ɸ��ģ������汾dcf��Сͳһ����
	buffer = new char[fileBytes - currentDataLength];
	memcpy(buffer, cfgStream + currentDataLength, fileBytes - currentDataLength);
	fs.write(buffer, fileBytes - currentDataLength);
	delete[]buffer;

	fs.close();
	return TRUE;
}

int colorVisionSimple::zipFromDcf(const char* dcfName, const char* zipFn) {
	zipFile zf = zipOpen(zipFn, 0);
	if (zf == nullptr) {
		std::cerr << "Failed to open zip file." << std::endl;
		return -1;
	}

	// ������Ҫѹ�����ļ���
	string fileNameInZip = "Camera.cfg";
	zip_fileinfo zi;
	memset(&zi, 0, sizeof(zip_fileinfo));

	// ���ļ����ӵ� zip ����
	if (zipOpenNewFileInZip(zf, fileNameInZip.c_str(), &zi, nullptr, 0, nullptr, 0, nullptr, Z_DEFLATED, Z_DEFAULT_COMPRESSION) != ZIP_OK) {
		LOGFMTE("Failed to add file to zip:%s", fileNameInZip.c_str());
		zipClose(zf, nullptr);
		return -1;
	}

	// �����ļ�����
	Json::Value v;
	Json::Value arr;
	bool isTrue = true;
	if (srcBpp == 8)
	{
		isTrue = false;
	}
	v["Bit"] = isTrue;
	v["CameraID"] = cameraId;
	v["CameraType"] = (int)camType;
	v["TakeImageMode"] = (int)takePicMode;
	string SN = string(dcfName);
	v["CameraSN"] = SN;
	isTrue = false;
	if (useComCfw == 1)
	{
		isTrue = true;
	}
	v["CWFPort"]["COM"] = isTrue;
	v["CWFPort"]["Enabled"] = isTrue;

	arr["title"] = Json::Value("Red");
	arr["cfwport"] = Json::Value(port[0]);
	arr["chtype"] = Json::Value(channelTye[0]);
	v["CWFPort"]["channel"].append(arr);

	arr["title"] = Json::Value("Green");
	arr["cfwport"] = Json::Value(port[1]);
	arr["chtype"] = Json::Value(channelTye[1]);
	v["CWFPort"]["channel"].append(arr);

	arr["title"] = Json::Value("Blue");
	arr["cfwport"] = Json::Value(port[2]);
	arr["chtype"] = Json::Value(channelTye[2]);
	v["CWFPort"]["channel"].append(arr);

	Json::StreamWriterBuilder writer;
	std::string output = Json::writeString(writer, v);
	zipWriteInFileInZip(zf, output.c_str(), output.length());
	arr.clear();
	v.clear();

	// �رյ�ǰ�ļ�
	zipCloseFileInZip(zf);


	map<string, caliZipItem>map_caliItem;
	for (int i = 0; i < vector_caliGroups.size(); i++)
	{
		fileNameInZip = "Calibration\\" + vector_caliGroups[i].groupTitle + ".cfg";
		memset(&zi, 0, sizeof(zip_fileinfo));
		if (zipOpenNewFileInZip(zf, fileNameInZip.c_str(), &zi, nullptr, 0, nullptr, 0, nullptr, Z_DEFLATED, Z_DEFAULT_COMPRESSION) != ZIP_OK) {
			LOGFMTE("Failed to add file to zip:%s", fileNameInZip.c_str());
			zipClose(zf, nullptr);
			return -1;
		}
		Json::Value jsonArray(Json::arrayValue);
		for (int j = 0; j < vector_caliGroups[i].list_cali.size(); j++)
		{
			int type = (int)vector_caliGroups[i].list_cali[j].caliType;
			string fn = vector_caliGroups[i].list_cali[j].caliFile;
			string tFn = fn;
			string title = tFn.erase(fn.length() - 4, 4);

			caliZipItem item;
			item.caliType = type;
			item.caliFn = fn;
			item.title = title;
			map_caliItem.insert(pair<string, caliZipItem>(title, item));

			arr["CalibrationType"] = type;
			arr["FileName"] = fn;
			arr["Title"] = title;
			jsonArray.append(arr);

		}
		output = Json::writeString(writer, jsonArray);
		zipWriteInFileInZip(zf, output.c_str(), output.length());
		// �رյ�ǰ�ļ�
		zipCloseFileInZip(zf);
		arr.clear();
		jsonArray.clear();
	}

	map<string, caliZipItem>::iterator it = map_caliItem.begin();
	while (it != map_caliItem.end())
	{
		arr["CalibrationType"] = it->second.caliType;

		arr["FileName"] = it->second.caliFn;
		arr["Title"] = it->second.title;
		v["Calibration"].append(arr);
		arr.clear();
		std::ifstream fs("cfg\\" + it->second.caliFn, std::ios::binary | std::ios::ate);
		if (!fs.is_open())
		{
			LOGFMTE("Failed to add file to zip:%s", it->second.caliFn.c_str());
			//zipCloseFileInZip(zf);
			zipClose(zf, nullptr);
			remove(zipFn);

			return FALSE;
		}

		std::streamsize size = fs.tellg();

		fs.seekg(0, std::ios::beg);

		char* buffer = new char[size];
		fs.read(buffer, size);
		CalibrationType ct = CalibrationType(it->second.caliType);
		switch (ct)
		{
		case CalibrationType::Uniformity:
			fileNameInZip = "Calibration\\Uniformity\\" + it->second.caliFn;
			break;
		case CalibrationType::Distortion:
			fileNameInZip = "Calibration\\Distortion\\" + it->second.caliFn;
			break;
		case CalibrationType::Luminance:
			fileNameInZip = "Calibration\\Luminance\\" + it->second.caliFn;
			break;
		case CalibrationType::DefectPoint:
			fileNameInZip = "Calibration\\DefectPoint\\" + it->second.caliFn;
			break;
		case CalibrationType::DSNU:
			fileNameInZip = "Calibration\\DSNU\\" + it->second.caliFn;
			break;
		case CalibrationType::LumFourColor:
			fileNameInZip = "Calibration\\LumFourColor\\" + it->second.caliFn;
			break;
		case CalibrationType::LumMultiColor:
			fileNameInZip = "Calibration\\LumMultiColor\\" + it->second.caliFn;
			break;
		case CalibrationType::ColorDiff:
			fileNameInZip = "Calibration\\ColorDiff\\" + it->second.caliFn;
			break;
		case CalibrationType::AngleShift:
			fileNameInZip = "Calibration\\AngleShift\\" + it->second.caliFn;
			break;
		default:
			break;
		}
		memset(&zi, 0, sizeof(zip_fileinfo));
		if (zipOpenNewFileInZip(zf, fileNameInZip.c_str(), &zi, nullptr, 0, nullptr, 0, nullptr, Z_DEFLATED, Z_DEFAULT_COMPRESSION) != ZIP_OK) {
			LOGFMTE("Failed to add file to zip:%s", fileNameInZip.c_str());
			zipClose(zf, nullptr);
			delete[]buffer;
			return -1;
		}
		zipWriteInFileInZip(zf, buffer, size);
		fs.close();
		// �رյ�ǰ�ļ�
		zipCloseFileInZip(zf);
		delete[]buffer;
		it++;
	}

	output = Json::writeString(writer, v);
	fileNameInZip = "Calibration.cfg";
	memset(&zi, 0, sizeof(zip_fileinfo));
	if (zipOpenNewFileInZip(zf, fileNameInZip.c_str(), &zi, nullptr, 0, nullptr, 0, nullptr, Z_DEFLATED, Z_DEFAULT_COMPRESSION) != ZIP_OK) {
		LOGFMTE("Failed to add file to zip:%s", fileNameInZip.c_str());
		zipClose(zf, nullptr);
		return -1;
	}
	zipWriteInFileInZip(zf, output.c_str(), output.length());
	arr.clear();
	v.clear();
	// �رյ�ǰ�ļ�
	zipCloseFileInZip(zf);

	// �ر� zip �ļ�
	zipClose(zf, nullptr);
	LOGFMTI("Zip file created successfully.");
	return TRUE;
}

void colorVisionSimple::writeSimpleMemory(int type, int dst) {
	/*������ʹ��Ƶ������������� ��Ҫ�����ID���а�*/
	const string cvSimpleMemory = "cvSimpleMemory.txt";
	Json::Value root;

	// 1. ��ȡ������
	{
		ifstream in(cvSimpleMemory, ios::binary);
		if (in.is_open()) {
			Json::CharReaderBuilder reader;
			string errs;
			// ʹ�ý��µ� parse API��Json::Reader ���𽥱����ã�
			if (!Json::parseFromStream(reader, in, &root, &errs)) {
				// �������ʧ�ܣ����ļ��𻵣���root �ᱣ�ֿգ��·����Զ������½ṹ
				// Ҳ���Ը�����Ҫ�����ﱨ������ errs
			}
			in.close();
		}
	}

	// 2. �޸��߼�
	// ȷ�� root �����Ǹ����󣬷�ֹԭ�ļ��Ƿ����ݵ��±���
	if (!root.isObject()) {
		root = Json::objectValue;
	}

	if (type == 0) {
		root["ndPort"] = dst;
	}

	if (type == 1) {
		/*root["spMesurePort"] = dst;��ʱ����ʵ��
		LOGD("spMesurePort");*/
	}

	// 3. д���ļ�
	Json::StreamWriterBuilder writer;


	ofstream outFile(cvSimpleMemory, ios::out | ios::trunc);
	if (outFile.is_open()) {
		// ֱ��д������Ч�ʸ���
		unique_ptr<Json::StreamWriter> sw(writer.newStreamWriter());
		sw->write(root, &outFile);
		outFile.close();
	}
	/*LOGD("writeSimpleMemory");*/
}

bool colorVisionSimple::readSimpleMemory(int& ndPort, int& spMesurePort) {
	const string cvSimpleMemory = "cvSimpleMemory.txt";
	Json::Value root;

	// 1. ��ȡ������

	ifstream in(cvSimpleMemory, ios::binary);
	if (in.is_open()) {
		Json::CharReaderBuilder reader;
		string errs;
		// ʹ�ý��µ� parse API��Json::Reader ���𽥱����ã�
		if (!Json::parseFromStream(reader, in, &root, &errs)) {
			// �������ʧ�ܣ����ļ��𻵣���root �ᱣ�ֿգ��·����Զ������½ṹ
			// Ҳ���Ը�����Ҫ�����ﱨ������ errs

			in.close();
			return false;
		}
		if (root.isMember("ndPort")) {
			ndPort = root["ndPort"].asInt();
		}//

		if (root.isMember("spMesurePort")) {
			spMesurePort = root["spMesurePort"].asInt();
		}
		in.close();
		return true;
	}
	return false;

}

int colorVisionSimple::openSpectrometer() {
	if (spectHandle == nullptr)
	{
		spectHandle = CM_CreateEmission(spectType);
	}

	if (spectHandle == nullptr)
	{
		return FALSE;
	}
	int COM = 3;
	string comInt = spectCom;
	if (!comInt.empty())
	{
		comInt.erase(0, 3);
		try {
			COM = std::stoi(comInt); // ����ת��

		}
		catch (const std::invalid_argument& e) {
			//std::cerr << "ת��ʧ��: ��Ч�����ָ�ʽ -> " << e.what() << std::endl;

		}
		catch (const std::out_of_range& e) {
			//std::cerr << "ת��ʧ��: ���ֳ�����Χ -> " << e.what() << std::endl;			
		}
	}
	if (spectType == 0) {
		COM = 0;
		spectBoud = 0;
	}

	int res = CM_Emission_Init(spectHandle, COM, spectBoud);

	if (res != TRUE)
	{
		LOGE("initial spectrometer FAIL!");
		return FALSE;
	}

	char pC[256] = { '0' };

	res = CM_Emission_GetSerialNumber(spectHandle, pC);

	if (res != TRUE)
	{
		LOGE("get spectrometer ID FAIL!");
		CM_Emission_Close(spectHandle);
		return FALSE;
	}

	if (spectId != string(pC))
	{
		LOGFMTI("the spectrometer id in DCF is:%s,it doesn't match the id searched :%s.", spectId.c_str(), pC);
		CM_Emission_Close(spectHandle);
		return FALSE;
	}

	spectIsOpen = true;

	LOGI("open the spectrometer Success!");
	return TRUE;
}

int colorVisionSimple::loadSpectrometerCfgFile(int type, const char* Fn) {
	int res = FALSE;
	string pf = caliFilePath + string(Fn);
	if (type == 0)
	{
		LOGFMTI("load the spectrometer wave file: %s", pf.c_str());
		//��������
		res = CM_Emission_LoadWavaLengthFile(spectHandle, pf.c_str());
	}

	if (type == 1)
	{
		LOGFMTI("load the spectrometer amplitude file: %s", pf.c_str());
		//���Է�ֵ����
		res = CM_Emission_LoadMagiudeFile(spectHandle, pf.c_str());
	}
	LOGFMTI("load %s -return is%d ", pf.c_str(), res);
	return res;
}

int colorVisionSimple::spectrometerDarkCali(int type, float fTimeStart, int nStepTime, int nStepCount, int iAveNum) {
	bool isOk = checkSpectrometerStatus();
	if (!isOk)
	{
		return FALSE;
	}
	int res = FALSE;

	int currentPort = 0;
	if (!setSpPort(false)) {
		return CV_ERR_CAM_SET_CFWPORT;
	}
	/*

		Sleep(2000);*/

	if (blindType == 2)
	{
		//��ͨ����բ��У�㣬��

	}

	if (type == 0)
	{
		//����У��
		res = CM_Emission_DarkStorage(spectHandle, fTimeStart, iAveNum, -1, darkCaliData);
	}
	else
	{
		//��������У��
		res = CM_Emission_Init_Auto_Dark(spectHandle, fTimeStart, nStepTime, nStepCount, iAveNum);
	}


	resetSpPortAfterDarkCali();

	return res;
}

int colorVisionSimple::doSpectrometerMeasure(/*TRIGGER_MODE TriggerMode,*/ int darkMode, float fIntTime, int iAveNum, COLOR_PARA& dPara) {
	bool isOk = checkSpectrometerStatus();
	if (!isOk)
	{
		return FALSE;
	}
	int res = FALSE;

	int currentPort = 0;

	/*if (!setSpPort(currentPort)) {
		return CV_ERR_CAM_SET_CFWPORT;
	}
	Sleep(2000);*/
	if (darkMode == 0)
	{
		res = CM_Emission_GetData(spectHandle, TRIGGER_MODE::EXINT_FALLING_EDGE/*TriggerMode*/, fIntTime, iAveNum, -1, darkCaliData, -1.0, -1.0, -1.0, -1.0, dPara);
	}
	else
	{
		float autoDarkData[2048];
		res = CM_Emission_AutoDarkStorage(spectHandle, fIntTime, -1, -1, autoDarkData);
		if (res != TRUE)
		{
			LOGE("get the Spetrometer Auto dark data Fail!");
			return res;
		}
		res = CM_Emission_GetData(spectHandle, TRIGGER_MODE::EXINT_FALLING_EDGE /*TriggerMode*/, fIntTime, iAveNum, -1, autoDarkData, -1.0, -1.0, -1.0, -1.0, dPara);

	}

	/*resetSpPort(currentPort);*/
	return res;
}

int colorVisionSimple::doSpectrometerMeasure(const char* paramJson, char* resultBuff, int& resLen) {
	bool isOk = checkSpectrometerStatus();
	if (!isOk)
	{
		return FALSE;
	}
	Json::Reader r;
	Json::Value v;

	Json::Value vChild;

	r.parse(paramJson, v);
	if (v.isNull())
	{
		LOGE("the  parameter is Not Json format!");
		return FALSE;
	}

	LOGFMTI("SpectrometerMeasure parameter :%s", paramJson);

	int darkMode = v["darkMode"].asInt();
	float fIntTime = v["integrationTime"].asFloat();
	int iAveNum = v["messureNum"].asInt();
	int res = FALSE;

	/*int currentPort = 0;*/

	if (!setSpPort(true)) {//ȷ���������ڼ��λ
		return CV_ERR_CAM_SET_CFWPORT;
	}

	COLOR_PARA dPara;
	if (darkMode == 0)
	{
		res = CM_Emission_GetData(spectHandle, TRIGGER_MODE::EXINT_FALLING_EDGE/*TriggerMode*/, fIntTime, iAveNum, -1, darkCaliData, -1.0, -1.0, -1.0, -1.0, dPara);
	}
	else
	{
		float autoDarkData[2048];
		res = CM_Emission_AutoDarkStorage(spectHandle, fIntTime, -1, -1, autoDarkData);
		if (res != TRUE)
		{
			LOGE("get the Spetrometer Auto dark data Fail!");
			return res;
		}
		res = CM_Emission_GetData(spectHandle, TRIGGER_MODE::EXINT_FALLING_EDGE /*TriggerMode*/, fIntTime, iAveNum, -1, autoDarkData, -1.0, -1.0, -1.0, -1.0, dPara);

	}

	//resetSpPort(/*currentPort*/);//�ָ�������ת��������λ
	Json::Value vResult;
	//Json::Value vPart;
	Json::Value item;
	if (res == 1) {
		vResult["cie_x"] = dPara.fx;
		vResult["cie_y"] = dPara.fy;
		vResult["cie_u"] = dPara.fu;
		vResult["cie_v"] = dPara.fv;
		vResult["Y_Lumnance"] = dPara.fPh;
		vResult["dominantWave"] = dPara.fLd;
		vResult["peakWavelength"] = dPara.fLp;
		vResult["CCT"] = dPara.fCCT;
		vResult["Saturation"] = dPara.fIp / 65535;//Spectral data array

		for (int i = 0; i < 4001; i++)
		{
			vResult["SpectralDataArray"].append(dPara.fPL[i]);
		}
	}
	else
	{
		vResult["message"] = "Failed to messure";
	}
	Json::StreamWriterBuilder writer;
	string	result = Json::writeString(writer, vResult);
	if (resLen < result.length() + 1)
	{
		resLen = result.length() + 1024;//���һЩ
		LOGE("buffer is not enough");
		return -3;
	}
	resLen = result.length() + 1;
	memcpy(resultBuff, result.c_str(), resLen);
	return res;
}

int colorVisionSimple::getSpectrometerAutoTime(float& fIntTime, int iLimitTime, float fTimeB, int useSaturation, int nSaturation) {
	bool isOk = checkSpectrometerStatus();
	if (!isOk)
	{
		return FALSE;
	}

	int currentPort = -1;

	if (!setSpPort(true)) {
		return CV_ERR_CAM_SET_CFWPORT;
	}


	int res = FALSE;
	if (useSaturation == 0)
	{
		res = CM_Emission_GetAutoTime(spectHandle, fIntTime, iLimitTime, fTimeB, nSaturation);
	}
	else
	{
		res = CM_Emission_GetAutoTimeEx(spectHandle, fIntTime, iLimitTime, fTimeB, nSaturation);
	}

	return res;
}


int colorVisionSimple::enableRealTimeCaliBySpect(int enable, int darkMode, float MeasureTime, int iAveNum, PointInt center, int radius_w, int h) {
	if (enable == 0)
	{
		spectRealCaliIsActive = false;
	}

	else
	{
		spectRealCaliIsActive = true;
	}

	spectRealCaliDarkMode = darkMode;
	spectRealCaliTime = MeasureTime;
	spectRealCaliMeasureNum = iAveNum;
	spectRealCaliCenter = center;
	spectRealCaliRadius_w = radius_w;
	spectRealCaliH = h;
	//LOGFMTI("set Param spectRealCaliDarkMode:%d,spectRealCaliTime:%f,spectRealCaliMeasureNum:%d", spectRealCaliDarkMode, spectRealCaliTime, spectRealCaliMeasureNum);

	return TRUE;
}

int colorVisionSimple::closeSpectrometer() {
	bool isOk = checkSpectrometerStatus();
	if (!isOk)
	{
		return FALSE;
	}
	int res = FALSE;

	res = CM_Emission_Close(spectHandle);

	//res = CM_ReleaseEmission(spectHandle);

	return res;
}

bool colorVisionSimple::checkSpectrometerStatus() {
	if (spectHandle == nullptr)
	{
		LOGE(" the Spetrometer Handle is Empty!");
		return false;
	}
	if (!spectIsOpen)
	{
		LOGE(" the Spetrometer  is closed!");
		return false;
	}

	int res = FALSE;

	char pC[256] = { '0' };

	res = CM_Emission_GetSerialNumber(spectHandle, pC);

	if (res != TRUE)
	{
		LOGE("get spectrometer ID FAIL!");
		return false;
	}

	if (spectId != string(pC))
	{
		LOGFMTI("the spectrometer id in DCF is:%s,it doesn't match the id searched :%s.", spectId.c_str(), pC);
		return false;
	}
	return true;
}


bool colorVisionSimple::getAverageXyz(BYTE* pXyz, OPTIC_DATA& op) {
	if (op.shape == 0) {
		if (op.px - op.w_radius<0 || op.px + op.w_radius>m_w || op.py - op.w_radius<0 || op.py + op.w_radius>m_h) {
			return false;
		}
		Mat mask(2 * op.w_radius, 2 * op.w_radius, CV_8UC1, Scalar(0, 0, 0));

		for (int i = 0; i < 2 * op.w_radius; i++) {
			for (int j = 0; j < 2 * op.w_radius; j++)
			{
				if (pow((i - op.w_radius), 2) + pow((j - op.w_radius), 2) <= pow(op.w_radius, 2)) {
					mask.at<uchar>(j, i) = 255;
				}
			}
		}
		//imwrite("mask.tif", mask);

		if (m_channels == 3) {
			Mat XYZ(m_h, m_w, CV_32FC1, pXyz);
			Mat rectX = Mat(XYZ, Rect(op.px - op.w_radius, op.py - op.w_radius, op.w_radius * 2, op.w_radius * 2)).clone();

			XYZ = Mat(m_h, m_w, CV_32FC1, pXyz + m_w * m_h * 4);
			Mat rectY = Mat(XYZ, Rect(op.px - op.w_radius, op.py - op.w_radius, op.w_radius * 2, op.w_radius * 2)).clone();

			XYZ = Mat(m_h, m_w, CV_32FC1, pXyz + m_w * m_h * 8);
			Mat rectZ = Mat(XYZ, Rect(op.px - op.w_radius, op.py - op.w_radius, op.w_radius * 2, op.w_radius * 2)).clone();

			op.X = mean(rectX, mask)[0];
			op.Y = mean(rectY, mask)[0];
			op.Z = mean(rectZ, mask)[0];
			LOGFMTI("real cali get X:%f,Y:%f,Z:%f", op.X, op.Y, op.Z);
			return true;
		}

	}

	else
	{
		if (op.px - op.w_radius<0 || op.px + op.w_radius>m_w || op.py - op.h<0 || op.py + op.h>m_h) {
			return false;
		}

		if (m_channels == 3) {
			Mat XYZ(m_h, m_w, CV_32FC1, pXyz);
			Mat rectX = Mat(XYZ, Rect(op.px - op.w_radius * 0.5, op.py - op.h * 0.5, op.w_radius, op.h)).clone();

			XYZ = Mat(m_h, m_w, CV_32FC1, pXyz + m_w * m_h * 4);
			Mat rectY = Mat(XYZ, Rect(op.px - op.w_radius * 0.5, op.py - op.h * 0.5, op.w_radius, op.h)).clone();

			XYZ = Mat(m_h, m_w, CV_32FC1, pXyz + m_w * m_h * 8);
			Mat rectZ = Mat(XYZ, Rect(op.px - op.w_radius * 0.5, op.py - op.h * 0.5, op.w_radius, op.h)).clone();

			op.X = mean(rectX)[0];
			op.Y = mean(rectY)[0];
			op.Z = mean(rectZ)[0];
			LOGFMTI("real cali get X:%f,Y:%f,Z:%f", op.X, op.Y, op.Z);
			return true;
		}

	}
	return false;
}

bool colorVisionSimple::realTimeCaliBySpect(BYTE* pXyz) {
	if (spectRealCaliIsActive)
	{
		if (!spectIsOpen)
		{
			LOGE("the spectrometer must be opened if you Use the real time cali!");
			return false;
		}
		COLOR_PARA tOp;
		LOGFMTI("spectRealCaliDarkMode:%d,spectRealCaliTime:%f,spectRealCaliMeasureNum:%d", spectRealCaliDarkMode, spectRealCaliTime, spectRealCaliMeasureNum);
		int res = doSpectrometerMeasure(spectRealCaliDarkMode, spectRealCaliTime, spectRealCaliMeasureNum, tOp);

		if (res != TRUE)
		{
			LOGE("the spectrometer get real time data Fail!");
			return false;
		}
		OPTIC_DATA cameraOp[1];
		cameraOp->w_radius = spectRealCaliRadius_w;
		cameraOp->h = spectRealCaliH;
		if (spectRealCaliH == 0)
		{
			cameraOp->shape = 0;
		}
		else
		{
			cameraOp->shape = 1;
		}
		cameraOp->px = spectRealCaliCenter.x;
		cameraOp->py = spectRealCaliCenter.y;

		if (cameraOp->px< cameraOp->w_radius || cameraOp->px + cameraOp->w_radius>m_w
			|| cameraOp->py < cameraOp->w_radius || cameraOp->py + cameraOp->w_radius>m_w)
		{
			LOGE("the terminal point for camera is out of range");
			return false;
		}
		if (!getAverageXyz(pXyz, cameraOp[0])) {
			return false;
		}
		//CM_GetOpticsData(cameraHandle, cameraOp, 1);
		float m = 1, n = 1, p = 1;
		GetmnpByXYZxyLv(cameraOp->X, cameraOp->Y, cameraOp->Z, tOp.fx, tOp.fy, tOp.fPh, m, n, p);
		CM_SetBymnp(cameraHandle, TRUE, m, n, p);

		LOGI("do the real Time cali by spectromerter SuccessFully");
		return true;
	}

	else
	{
		float m = 1, n = 1, p = 1;

		CM_SetBymnp(cameraHandle, FALSE, m, n, p);
	}
	return false;
}

bool colorVisionSimple::getHImage(HImage& hi, int type) {
	hi.pData = nullptr;
	if (tSrcData == nullptr)
	{
		LOGE("image ptr is null,please take image first");
		return false;
	}
	hi.iWid = m_w;
	hi.iHei = m_h;
	hi.iBpp = srcBpp;
	if (type < 1 || m_channels == 1) {
		hi.iChls = m_channels;
		hi.pData = tSrcData;
		return true;
	}

	hi.iChls = 1;
	cv::Mat src(m_h, m_w, OpencvManager::Gettype(srcBpp, m_channels), tSrcData);
	cv::Mat arr[3];

	if (type > 0 && type < 4)
	{
		//ѡ��RGB�κ�һ��ͨ��ʱ
		cv::split(src, arr);
	}
	if (type > 3) {
		hi.iBpp = 32;
		hi.iChls = 1;
	}
	switch (type)
	{
	case 1:
		hi.pData = new BYTE[srcBpp / 2 * m_w * m_h];
		memcpy(hi.pData, arr[2].data, srcBpp / 2 * m_w * m_h);
		break;
	case 2:
		hi.pData = new BYTE[srcBpp / 2 * m_w * m_h];
		memcpy(hi.pData, arr[1].data, srcBpp / 2 * m_w * m_h);
		break;
	case 3:
		hi.pData = new BYTE[srcBpp / 2 * m_w * m_h];
		memcpy(hi.pData, arr[0].data, srcBpp / 2 * m_w * m_h);
		break;
	case 4:
		hi.pData = tXyzData;
		//memcpy(hi.pData, tXyzData, 4 * m_w * m_h);
		break;
	case 5:
		if (m_channels == 3)
		{
			hi.pData = tXyzData + 4 * m_w * m_h;
		}
		else
		{
			hi.pData = tXyzData;
		}
		//memcpy(hi.pData, tXyzData + 4 * m_w * m_h, 4 * m_w * m_h);
		break;
	case 6:
		hi.pData = tXyzData + 8 * m_w * m_h;
		//memcpy(hi.pData, tXyzData + 8 * m_w * m_h, 4 * m_w * m_h);
		break;
	default:
		break;
	}


	return true;
}

void colorVisionSimple::releaseHImage(HImage& hi) {
	if (hi.pData == nullptr || hi.pData == tSrcData || hi.pData == tXyzData
		|| hi.pData == tXyzData + 4 * m_w * m_h || hi.pData == tXyzData + 8 * m_w * m_h)

	{
		return;
	}
	else
	{
		delete[]hi.pData;
		hi.pData = nullptr;
	}
}

bool colorVisionSimple::setSpPort(bool enableMessure) {
	if (blindType == 1 && spMeasurePort > -1)
	{
		if (enableMessure)
		{
			/*writeSimpleMemory(1, _currentSpPort);*/
			if (_currentSpPort == spMeasurePort) {
				return true;
			}


			int success = CM_SetPort(cameraHandle, spMeasurePort);

			if (success != TRUE)
			{
				LOGE("Fail to control the Port!");
				return  false;
			}
			_currentSpPort = spMeasurePort;

			//Sleep(4000);
			LOGFMTD("set port :%d,in spMeasurePort", spMeasurePort);
		}
		else
		{
			if (_currentSpPort == blindPort) {
				return true;
			}

			int success = CM_SetPort(cameraHandle, blindPort);

			if (success != TRUE)
			{
				LOGE("Fail to control the Port!");
				return  false;
			}
			_currentSpPort = blindPort;
		}
	}
	return true;
}

bool colorVisionSimple::resetSpPortAfterDarkCali(/*int& currentPort*/) {
	if (/*currentPort > -1*/blindType == 1 /*&& blindPort > -1*/)
	{
		if (_currentSpPort == spMeasurePort) {
			return true;
		}
		int res = CM_SetPort(cameraHandle, spMeasurePort);
		if (res != 1)
		{
			LOGE("Failed to reset spPort to messure");
			return false;
		}
		_currentSpPort = spMeasurePort;
		/*writeSimpleMemory(1, _currentSpPort);*/
	}

	return true;
}

int colorVisionSimple::caclFov(ChannelTypeSimple chooseChannel, double Radio, double cameraDegrees, double& fovDegrees, int thresholdValue, double dFovDist, float* coordinates, FovPattern pattern, FovType type) {
	HImage hi;
	if (!getHImage(hi, 0))
	{
		return 0;
	}
	int res = FovCalculation(hi, Radio, cameraDegrees, fovDegrees, thresholdValue, dFovDist, coordinates, pattern, type);
	releaseHImage(hi);
	return res;
}

int colorVisionSimple::caclSFR(ChannelTypeSimple chooseChannel, IRECT rtROI, double gamma, float* pdfrequency, float* pdomainSamplingData, int nLen) {
	HImage hi;
	if (!getHImage(hi, 0))
	{
		return 0;
	}
	int res = SFRCalculation(hi, rtROI, gamma, pdfrequency, pdomainSamplingData, nLen);
	releaseHImage(hi);
	return res;
}

double colorVisionSimple::caclMTF(ChannelTypeSimple chooseChannel, EvaFunc type, int dx, int dy, int ksize, double dRatio) {
	HImage hi;
	if (!getHImage(hi, 0))
	{
		return 0;
	}
	double res = cvCalArticulation(type, hi, dx, dy, ksize, dRatio);
	releaseHImage(hi);
	return res;
}

int colorVisionSimple::caclGhost(ChannelTypeSimple chooseChannel, const int radius, int LedNums_X, int LedNums_Y, float ratioH, float ratioL, char* path, int& allLedPixelsNummber, int& LED_Nummber, int& allGhostPixelsNummber, int& Ghost_Nummber) {
	HImage hi;
	if (!getHImage(hi, 5))
	{
		return 0;
	}
	int res = GhostGlareDectect(hi, radius, LedNums_X, LedNums_Y, ratioH, ratioL, path, allLedPixelsNummber, LED_Nummber, allGhostPixelsNummber, Ghost_Nummber);
	releaseHImage(hi);
	return res;
}

int colorVisionSimple::_getGhostResult(float* LedCenters_X, float* LedCenters_Y, float* LedAverageGray, float* ghostAverageGray, int* singleLedPixelNum, int* LED_pixel_X, int* LED_pixel_Y, int* singleGhostPixelNum, int* Ghost_pixel_X, int* Ghost_pixel_Y) {

	return getGhostResult(LedCenters_X, LedCenters_Y, LedAverageGray, ghostAverageGray, singleLedPixelNum, LED_pixel_X, LED_pixel_Y, singleGhostPixelNum, Ghost_pixel_X, Ghost_pixel_Y);
}

int colorVisionSimple::caclDistortion(ChannelTypeSimple chooseChannel, ISIZE iSize, BlobThreParams tBlobThreParams, float* finalPointsX, float* finalPointsY, double& pointx, double& pointy, double& maxErrorRatio, double& t, CornerType type, SlopeType sType, LayoutType lType, DistortionType dType, int timeoutNumLimit) {
	HImage hi;
	if (!getHImage(hi, 0))
	{
		return 0;
	}
	int res = DistortionCalculation(hi, iSize, tBlobThreParams, finalPointsX, finalPointsY, pointx, pointy, maxErrorRatio, t, type, sType, lType, dType, timeoutNumLimit);
	releaseHImage(hi);
	return res;
}

