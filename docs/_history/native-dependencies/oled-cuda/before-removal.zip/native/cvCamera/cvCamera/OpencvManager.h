#pragma once
#include <opencv2/opencv.hpp>
#include <vector>
#include "log4z.h"
#include <Eigen/Dense>
#include <Eigen/Core>
#include "CMStruct.h"
#include "StreamingImageAverage.h"

using namespace std;
using namespace cv;
using namespace zsummer::log4z;

#define DECLSPEC_IMPORT __declspec(dllimport)

namespace OpencvManager
{
	/*****************************************************
brief: ����λ�ǵ�
Returns:
Parameter:
		srcImage��input, Դͼ��
		cornerPoint�� input&output,�ֶ�λ�Ľǵ㣻
		qualityLevel��input, ���Ȳ�����0.04��
		cutWidth��input,���еĳ���
		edge��input, ����ͼ������

******************************************************/
	BOOL WINAPI findExactCornerPoint(Mat& srcImage, Point2f* cornerPoint, double qualityLevel, const int cutWidth, const int edge);

	int WINAPI findExactCornerPoint(Mat& srcImage, vector<Point2f>& cornerPoint, double qualityLevel, const int cutWidth, const int edge);

	/*****************************************************
brief: ���ĸ��ǵ����������������Ͻ�Ϊ��㣬˳ʱ��
Returns:
Parameter:

		cornerPoints�� input&output,�ֶ�λ�Ľǵ㣻

******************************************************/
	BOOL WINAPI sortCornerPoints(vector< cv::Point2f>& cornerPoints);

	BOOL WINAPI pickHighSaturationImage(Mat* imgArr, Mat& dst, int imageNummber);

	float WINAPI caclSaturation(Mat& images);

	BOOL WINAPI OtsuAlgThresholdTEST(const Mat& image, int& otsu);

	double WINAPI binarize(const Mat& inputImage, Mat& outputImage, const double thresh);

	double WINAPI binarize(Mat inputImage, double thresh);

	void WINAPI Dilate(const Mat& src, Mat& dst, int size);

	void WINAPI Dilate(Mat& src, int size);

	void WINAPI Erode(const Mat& src, Mat& dst, int size);

	void WINAPI Erode(Mat& src, int size);

	BOOL WINAPI findBrightCornerPoint(Mat& binaryImage, Point2f* cornerPoint, uint bright_w, uint bright_h);

	BOOL WINAPI dilateImage(const Mat& inputImage, Mat& dst, int time, bool direct);

	int WINAPI Gettype(int nbpp, int nChannels);

	void WINAPI MatToCImage(cv::Mat& matsrc, cv::Mat& matdst);

	cv::Mat WINAPI MatToCImage(cv::Mat& matsrc);

	BOOL getCirclePoint(cv::Mat matsrc, int thresholdValue, Point& tPt, double DarkRatio);

	BOOL getRectCorners(cv::Mat matsrc, int thresholdValue, vector<cv::Point2f>& rect_Corners, double darkRadio);

	//void RoughBoundaryPointsDetection(Mat srcpic, Point ImageCenter, vector<Point2f>& border_Corners, double gradient, double DarkRatio, FovType type);

	BOOL RoughBoundaryRectDetection(Mat srcpic, vector<Point2f> Corners, vector<Point2f>& border_Corners, double gradient, double DarkRatio, FovType type);

	BOOL RoughBoundaryCircleDetection(Mat srcpic, Point2f center, Point2f Point, vector<Point2f>& border_Corners, double gradient, double DarkRatio);

	void RoughBoundaryPointsDetection(Mat srcpic, Point ImageCenter, vector<Point2f>& border_Corners, double gradient, double DarkRatio, FovType type);
	void calFOV(vector<Point2f> border_Corners, double dFovDist, double cameraDegrees, double& fovDegrees);

	BOOL TranspositionROI(Mat img, Mat& image);

	int OtsuAlgThreshold(const Mat image);

	void de_Gamma(cv::Mat& Src, double gamma);

	void SLR(std::vector<double>& Cen_Shifts, std::vector<double>& y_shifts, double& a, double& b);

	vector<double> CentroidFind(Mat& Src, vector<double>& y_shifts, double& CCoffset);

	std::vector<double> OverSampling(Mat& Src, double slope, double CCoffset, int height, int width, int& SamplingLen);

	std::vector<double> HammingWindows(std::vector<double>& deSampling, int SamplingLen);

	void DFT(vector<double>& data, int size);

	void ReduceRows(double slope, int& ImgHeight);

	BOOL AverageImage(int nWnd, int nHei, int nBpp, int nChannels, std::vector<uint16_t*> vcpData, uint16_t* dst);

	BOOL CalResolution(Mat img, double dRatio, double& dMoudulation);

	//offy����Ļ��COMS���ĵ�ƫ�����أ�d����Ļ��10-15%��w�� COMS��40%-50%��h��Ļ��40-50%��nStep��2����MAping��nMaxCount��Ĭ��20��
	BOOL EdgeFocusIndex(Mat img, int offy, int d, int w, int h, int nStep, int nMaxCount, double& dMoudulation);
};

vector<vector<float>> opencv_sg(vector<vector<float>>& vdata, int M, int N);

bool SplineInterpolation(vector<float>& vdX, vector<float>& vdY, double staX, double endX, double step, vector<float>& vsX, vector<float>& vsY);

void rectCornersPyrdownFaster(Mat img, int n_times, int smooth_size, vector<Point2f>& corners_img);

void getRectCornersOrdered(vector<Point2f> input, vector<Point2f>& rst);

void getRectWHfromProjectedCorners(vector<Point2f> input, float& width, float& height);

//template<typename T>
//���μ���
class haloCacl
{
public:
	/*haloCacl();
	~haloCacl();*/
	void initialSrc(int w, int h, int bpp, int channels, char* imgdata, int savePic, const char*debugPath, float exp, const char* luminFile,bool doCali);

	bool findEdge(cv::Mat& imgFromCut, int threadV, bool isAdaptive, int rect_w, int rect_h, vector<vector<cv::Point>>& haloContour);

	float calculateHalo(int x, int y, int rect_w, int rect_h, int outMOVE, int threadV, int haloSize,const char* name, ushort* gray, uint& pixNum);

	float calculateKey(int x, int y, int rect_w, int rect_h, int inMOVE, int threadV, const char* name, ushort* gray, uint& pixNum);

	int getHaloResult(int& w, int& h, int& bpp, int& channels, char* pData);

private:
	Mat srcM;
	//Mat brightChannel;
	Mat drawImage;
	bool srcIsNull = true;
	int savePic;
	string path;
	HANDLE caliH;
	float m_exp[3];
	bool m_doCali;
};

class ledCheck_qk
{
public:
	ledCheck_qk();
	~ledCheck_qk();

	int findLedPosition(int w, int h, int bpp, int channels, uchar* data, int ledNum_x, int ledNum_y, int threadV, int* cornerX, int* cornerY);

	int getLedCenterNum();

	int getBadPointNum();

	int getLedCenterPositions(PointInt* pArr, int& referenceRadius);

	int getBadPositions(PointInt* pArr);

	int getDrawImg(int& w, int& h, int& bpp, int& channels, uchar* data);

	//�����㷨��ץLED��������Ŀ�ù�
	static int findHighIndensityLed(int w, int h,int bpp,int channels, char* imgdata,  CVLED_COLOR color, const char* cfg_json, const char* positionFn, int& col, int& row, float& x_interval, float& y_interval, float& angle, double* pX, double* pY);

private:
	bool success;
	int m_referenceRadius;
	vector<cv::Point>vec_ledCenters;
	vector<cv::Point>vec_badPoints;
	Mat matDraw;
};



using freshCenter = std::function<int(PointInt*, int&)>;




class Ghost
{
public:
	Ghost();
	~Ghost();
	void  initialMat(int w, int h, int bpp, int channel, uchar* data);

	void  initialMat(string fn);

	int loadXyz(uchar* pXyz, int index);

	int loadXyz(string fn);

	void enableDebug(bool e, const char* debugPath);

	int findBright(int thresholdMin, int thresholdMax, int thresholdStep, int brightNumX, int brightNumY, Pattern patternType, int outRectSizeMin, float outRectSizeRate, int erodeKernel);

	int findGhost(int thresholdMin, int thresholdMax, int thresholdStep, int outRectSizeMin, float outRectSizeRate,
		int minGray, float grayRate, int erodeKernel, int erodeTime, int pixDistance);

	int getDrawMat(int& w, int& h, int& bpp, int& channel, uchar* data);

	int getBrightPointsCenter(PointInt* p, int& length);

	int getGhostPointsCenter(PointInt* p, int& length);

	int getBrightAverageY(float* pY, int& length);

	int getGhostAverageY(float* pY, int& length);

	void setDrawMatGain(float minRate, float maxRate);

	Mat getDrawMat();

	int enableCheckCloseBright(bool* bArr, int& len);




private:
	bool isCorrectBright(vector < vector<cv::Point>>& source, vector < vector<cv::Point>>& dst, int brightNumber, int outRectSizeMin, float outRectSizeRate);

	bool isCorrectGhost(vector <vector<cv::Point>>& source, vector <vector<cv::Point>>& dst, int outRectSizeMin, float outRectSizeRate, int minGray, float grayRate);

	Mat convertTo8bit(const Mat& src);

	bool revertDrawMat();

	void compressImgData(int w, int h, int bpp, int channel, uchar* d);

	bool calcOutRects(const vector < vector<cv::Point>>& vp);

	bool calcContoursInY(vector < vector<cv::Point>>& vp, float* pY, int& length, string tifName);

	void offsetLocation(const vector<cv::Point>& src, vector<cv::Point>& dst, Rect r);

	void squeenLocation(vector <vector<cv::Point>>& source, int cols, int rows, Pattern patternType, bool isGhost);

	bool filtGhost(vector <vector<cv::Point>>& source, int pixDistant/*, bool* indexArr, int& length*/);

	bool getContoursCenter(const vector < vector<cv::Point>>& source, PointInt* p, int& length);

	int getSrcType();

	void autoGain();

	freshCenter pFfreshCenter;
private:
	Mat mat_src;
	Mat mat_XYZ;
	Mat mat_draw;
	int _w;
	int _h;
	int _bpp = 16;
	int _channel;
	bool isDebug;
	string debugPath;

	int _brightNumX;

	int _brightNumY;

	vector < vector<cv::Point>>vec_contours;

	vector < vector<cv::Point>>vec_contoursBright;	//���

	vector < vector<cv::Point>>vec_contoursGhost;	//��Ӱ

	vector< Rect>vec_contoursOutRect;

	bool* bIngnore = nullptr;

	float _k = 0;
	float _b = 1;

	int threshold_bright;
	int threshold_ghost;
};





