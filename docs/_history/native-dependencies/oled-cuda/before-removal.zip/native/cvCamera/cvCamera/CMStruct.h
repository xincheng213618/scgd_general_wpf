#pragma once
#include <string>
#include <vector>
#include <memory>

#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

#define RGB_Triple 1

typedef char CHAR;
typedef short SHORT;
typedef long LONG;
typedef unsigned char BYTE;
typedef unsigned char byte;
typedef int BOOL;
typedef void* HANDLE;
typedef unsigned uint;
typedef unsigned short ushort;
typedef unsigned short USHORT;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef const CHAR* LPCCH, * PCCH;
typedef BYTE* PBYTE;
typedef BYTE* LPBYTE;
typedef HANDLE* PHANDLE;
typedef unsigned short WORD;
typedef unsigned char UCHAR;

enum class CoolerFlagMode
{
	COOLER_ON = 1,
	COOLER_OFF = 2,
	COOLER_MANU = 3,
	COOLER_AUTO = 4
};

enum class ImageChannelType
{
	CM_Unknown = -1,
	Gray_X = 0,
	Gray_Y = 1,
	Gray_Z = 2,
	Gray_N = 20,
	xCIE = 3,
	yCIE = 4,
	uCIE = 5,
	vCIE = 6,
	CIE_X = 7,
	CIE_Y = 8,
	CIE_Z = 9,
	CIE_LvCxCy = 10,
	LvCIE = 11
};

enum  ChannelTypeSimple
{
	BGR = 0,
	channel_R = 1,
	channel_G = 2,
	channel_B = 3,
	channel_X = 4,
	channel_Y = 5,
	channel_Z = 6
};

enum class CalibrationType
{
	DarkNoise = 0,
	DefectWPoint = 1,
	DefectBPoint = 2,
	DefectPoint = 3,
	DSNU = 4,
	Uniformity = 5,
	Luminance = 6,
	LumOneColor = 7,
	LumFourColor = 8,
	LumMultiColor = 9,
	LumColor = 10,
	Distortion = 11,
	ColorShift = 12,
	LineArity = 13,
	ColorDiff,
	AngleShift,
	Empty_Num,
};

enum class ConfigType
{
	Cfg_Camera = 0,
	Cfg_ExpTime = 1,
	Cfg_Calibration = 2,
	Cfg_Channels = 3,
	Cfg_SYSTEM = 4,
};

enum class PG_Type
{
	GX09C_LCM = 0,
	SKYCODE,
};

enum class Communicate_Type
{
	Communicate_Tcp = 0,
	Communicate_Serial,
};

typedef struct calibrationitem
{
	calibrationitem()
	{
		type = CalibrationType::Empty_Num;
		enable = false;
	}
	calibrationitem(CalibrationType ty, bool en, const char* ti, const char* fn)
	{
		type = ty;
		enable = en;
		title = ti;
		doc = fn;
	}
	CalibrationType type;
	bool enable;
	std::string title;
	std::string doc;
}CalibrationItemCfg;

typedef struct channelcheckcfg
{
	CalibrationItemCfg darkNoiseCheck;
	CalibrationItemCfg dsnuCheck;
	CalibrationItemCfg uniformityCheck;
	CalibrationItemCfg defectCheck;
	CalibrationItemCfg defectWPCheck;
	CalibrationItemCfg defectBPCheck;
	CalibrationItemCfg distortionCheck;
	CalibrationItemCfg colorShiftCheck;
}ChannelCheckCfg;

typedef struct channelcheckcfg_tcl
{
	CalibrationItemCfg dsnuCheck;
	CalibrationItemCfg uniformityCheck;
	CalibrationItemCfg defectCheck;
}ChannelCheckCfg_TCL;

typedef struct imagechannelcfg
{
	imagechannelcfg()
		: imgData(nullptr)
	{
		channelType = ImageChannelType::CM_Unknown;
		frameW = 0;
		frameH = 0;
		framebpp = 0;
		framechannels = 0;
		exp = 10;
		autoExp = 10;
		autoExpLast = -1;
		autoExpSaturation = 0;
		hasNextExp = false;
		cfwport = 0;
		index = 0;
	}
	virtual ~imagechannelcfg()
	{
		// 		if (imgData != nullptr)
		// 		{
		// 			delete[] imgData;
		// 			imgData = nullptr;
		// 		}
	}
	ImageChannelType channelType;
	ChannelCheckCfg channelCheck;
	uint16_t cfwport;
	uint16_t index;
	float exp;
	float autoExp;
	float autoExpLast;
	float autoExpLasttwice;
	uint32_t frameW;
	uint32_t frameH;
	uint32_t framebpp;
	uint32_t framechannels;
	uint16_t* imgData;
	std::shared_ptr<uint16_t> shimgData;
	bool hasNextExp;
	std::string dataFile;
	float autoExpSaturation;
	float autoExpLastSaturation;
	float autoExpLastTwiceSaturation;
}ImageChannelCfg;

typedef struct cie_picture_channel
{
	cie_picture_channel()
		: channelType(ImageChannelType::CM_Unknown)
		, frameW(0)
		, frameH(0)
		, frameBpp(0)
		, imageData(nullptr)
	{
		m_bMemory = false;
	}

	cie_picture_channel(ImageChannelType tp, uint32_t w, uint32_t h)
		: channelType(tp)
		, frameW(w)
		, frameH(h)
		, frameBpp(32)
	{
		m_bMemory = true;
		imageData = new float[frameW * frameH];
		memset(imageData, 0, sizeof(float) * frameW * frameH);
	}

	cie_picture_channel(ImageChannelType tp, uint32_t w, uint32_t h, float* pData)
		: channelType(tp)
		, frameW(w)
		, frameH(h)
		, frameBpp(32)
	{
		m_bMemory = false;
		imageData = pData;
		//memset(imageData, 0, sizeof(float) * frameW * frameH);
	}

	cie_picture_channel(cie_picture_channel&& other) noexcept
		: channelType(other.channelType)
		, frameW(other.frameW)
		, frameH(other.frameH)
		, frameBpp(other.frameBpp)
		, imageData(other.imageData)
	{
		m_bMemory = false;
		other.imageData = nullptr;
	}

	cie_picture_channel(const cie_picture_channel& other)
		: channelType(other.channelType)
		, frameW(other.frameW)
		, frameH(other.frameH)
		, frameBpp(other.frameBpp)
		, imageData(other.imageData)
	{
		m_bMemory = true;
		imageData = new float[frameW * frameH];
		memcpy(imageData, other.imageData, sizeof(float) * frameW * frameH);
	}

	cie_picture_channel& operator=(cie_picture_channel&& other) noexcept
	{
		if (this != &other)
		{
			channelType = other.channelType;
			frameW = other.frameW;
			frameH = other.frameH;
			frameBpp = other.frameBpp;

			if (imageData != nullptr)
			{
				delete[] imageData;
			}
			m_bMemory = false;
			imageData = other.imageData;
			other.imageData = nullptr;
		}

		return *this;
	}

	cie_picture_channel& operator=(const cie_picture_channel& other)
	{
		if (this != &other)
		{
			channelType = other.channelType;
			frameW = other.frameW;
			frameH = other.frameH;
			frameBpp = other.frameBpp;

			if (imageData != nullptr)
			{
				delete[] imageData;
			}
			m_bMemory = true;
			imageData = new float[frameW * frameH];
			memcpy(imageData, other.imageData, sizeof(float) * frameW * frameH);
		}

		return *this;
	}

	~cie_picture_channel()
	{
		if (imageData != nullptr && m_bMemory)
		{
			delete[] imageData;
			imageData = nullptr;
		}
	}

	ImageChannelType channelType;
	uint32_t frameW;
	uint32_t frameH;
	uint32_t frameBpp;
	float* imageData;
	bool m_bMemory;
}CIEPictureChannel;

typedef struct lumchroma_cfg
{
	lumchroma_cfg() {};
	lumchroma_cfg(double _texp_x, double _texp_y, double _texp_z, double _gain_x,
		double _gain_y, double _gain_z, double _a, double _b, double _c, double _d) {
		Texp_x = _texp_x;
		Texp_y = _texp_y;
		Texp_z = _texp_z;
		Gain_x = _gain_x;
		Gain_y = _gain_y;
		Gain_z = _gain_z;
		a = _a;
		b = _b;
		c = _c;
		d = _d;
	};
	void(*CalCalibrationVal)(void* cfg, double g[], CIEPictureChannel* ch[], int indx);
	double Texp_x;
	double Texp_y;
	double Texp_z;
	double Gain_x;
	double Gain_y;
	double Gain_z;
	double a;
	double b;
	double c;
	double d;
}LumChromaCfg;

typedef struct lumchroma_fourcolor_cfg
{
	lumchroma_fourcolor_cfg() {};
	lumchroma_fourcolor_cfg(double _texp_x, double _texp_y, double _texp_z, double _gain_x,
		double _gain_y, double _gain_z, double _a, double _b, double _c, double _d, double _e, double _f, double _g, double _h, double _i) {
		Texp_x = _texp_x;
		Texp_y = _texp_y;
		Texp_z = _texp_z;
		Gain_x = _gain_x;
		Gain_y = _gain_y;
		Gain_z = _gain_z;
		a = _a;
		b = _b;
		c = _c;
		d = _d;
		e = _e;
		f = _f;
		g = _g;
		h = _h;
		i = _i;
	};
	void(*CalCalibrationVal)(void* cfg, double g[], CIEPictureChannel* const ch[], int indx);
	double Texp_x;
	double Texp_y;
	double Texp_z;
	double Gain_x;
	double Gain_y;
	double Gain_z;
	double a;
	double b;
	double c;
	double d;
	double e;
	double f;
	double g;
	double h;
	double i;
}LumChromaFourColorCfg;

typedef struct lumchroma_multicolor_cfg
{
	void(*CalCalibrationVal)(void* cfg, double g[], CIEPictureChannel* const ch[], int indx);
	int N;
	double* pa;
	double* gain;
}LumChromaMultiColorCfg;


typedef struct picture_iqa
{
	double mean;
	double max;
	double min;
	double variance;//����
	double deviation;//��׼��
	double uniformity;
}PictureIQA;

typedef struct take_picture_cfg
{
	take_picture_cfg()
		: pImgCIE(nullptr)
	{
		vImageChannel.clear();
		lumChromaCfg = NULL;
		obL = 0;
		obR = 0;
		obT = 0;
		obB = 0;
		measureCount = 0;
		autoExpFlag = true;
		channelCount = 0;
		startBurst = 0;
		endBurst = 0;
		posBurst = 0;
		title = "";
		m_nVersionsNo = 0;
	};
	uint16_t channelCount;
	std::vector<ImageChannelCfg*> vImageChannel;
	//����ɫƬʱֻ������
	CalibrationItemCfg* lumChromaCfg;
	bool autoExpFlag;
	int measureCount;
	int obL;
	int obR;
	int obT;
	int obB;
	unsigned short startBurst;
	unsigned short endBurst;
	unsigned short posBurst;
	std::string title;
	BYTE* pImgCIE;
	std::shared_ptr<BYTE> shImgCIE;
	void* pThis;

	std::vector<CalibrationItemCfg> vCalibCfg;
	int	m_nVersionsNo;

}TakePictureCfg;

typedef struct autoExpParamV2
{
	float margin_RatioLeft;

	float margin_RatioRight;

	float margin_RatioTop;

	float margin_RatioBottom;
}RoiMarginRatio;

typedef struct exp_time_cfg
{
	//�Զ��ع�
	float autoExpTimeBegin;
	bool autoExpFlag;
	//�Զ�ͬ��Ƶ��
	float autoExpSyncFreq;
	float autoExpSaturation;
	uint16_t autoExpSatMaxAD;
	//
	float autoExpMaxPecentage;
	//���ֵ
	float autoExpSatDev;
	//���/С�ع�
	float maxExpTime;
	float minExpTime;
	//burst����ֵ
	float burstThreshold;

	int type;//�����ع�����ͣ�ԭʼ�汾Ϊ0;

	RoiMarginRatio Margin;


}ExpTimeCfg;



enum EvaFunc : int
{
	Variance = 0,
	Tenengrad = 1,
	Laplace,
	CalResol,
	EdgeFocus,
};

enum VID_Filter
{
	ENUM_blur,
	ENUM_medianBlur,
	ENUM_GaussianBlur,
	ENUM_filter2D,
	ENUM_bilateralFilter,
	ENUM_boxFilter,
};
enum FovPattern : int
{
	FovCircle = 0,
	FovRectangle,
};

enum FovType : int
{
	Horizontal = 0,
	Vertical,
	Leaning,
};

//����ɫ�������
enum calGamutType
{
	CIE1931_NTSC = 0,
	CIE1931_sRGB,
	CIE1931_Adobe_RGB,
	CIE1931_DCI_P3,
	CIE1931_BT_2020,
	CIE1931_PAL,

	CIE1976_NTSC,
	CIE1976_sRGB,
	CIE1976_Adobe_RGB,
	CIE1976_DCI_P3,
	CIE1976_BT_2020,
	CIE1976_PAL
};

typedef struct auto_focus_cfg
{
	double forwardparam;		//�����ڶ���Χ			�ڶ��εĲ��� ʵ�ʵڶ��β���Ϊ forwardparam * curtailparam
	double curtailparam;		//����ÿ������ϵ��			�ڶ��εĲ���ϵ��
	int curStep;				//Ŀǰʹ�ò���			��һ�εĲ���
	int stopStep;				//ֹͣ����				������
	int minPosition;			//����ƶ���������
	int maxPosition;			//����ƶ���������
	EvaFunc eEvaFunc;			//���ۺ�������
	double dMinValue;			//�������ֵ
}AutoFocusCfg;

typedef struct channel_cfg
{
	std::string title;
	uint16_t cfwport;
	ImageChannelType chtype;
}ChannelCfg;

typedef struct camera_cfg
{
	camera_cfg()
	{
		obL = 0;
		obR = 0;
		obT = 0;
		obB = 0;
		tempCtlChecked = false;
		targetTemp = 0.0f;
		usbTraffic = 0.0f;
		offset = 0;
		gain = 10;
		ex = 0;
		ey = 0;
		ew = 0;
		eh = 0;
	};
	int obL;
	int obR;
	int obB;
	int obT;
	bool tempCtlChecked;
	float targetTemp;
	float usbTraffic;
	int offset;
	int gain;
	int ex;
	int ey;
	int ew;
	int eh;
}CameraCfg;

enum class CameraType
{
	CV_Q = 0,	//��Ӧ��QHY ,CV, USB������,�ް忨;
	LV_Q,		//��Ӧ��QHY ,LV, USB������,�ް忨;
	BV_Q,		//��Ӧ��QHY ,BV, USB������,�ް忨;
	MIL_CL,
	MIL_CXP,
	BV_H,		//��Ӧ��HK ,BV, USB������,�ް忨;
	LV_H,		//��Ӧ��HK ,LV, USB������,�ް忨;
	HK_CXP,
	LV_MIL_CL,
	CV_MIL_CL,
	BV_MIL_CXP,
	BV_HK_CARD,
	LV_HK_CARD,
	CV_HK_CARD,
	CV_HK_USB,
	LV_TOUP_USB,
	Non_CameraType,
	CameraType_Total,
};

enum CVLED_COLOR
{
	BLUE = 0,
	GREEN = 1,
	RED = 2,
};

enum class CameraMode
{
	CV_MODE,					// CVģʽ
	BV_MODE,					// CVģʽ
	LV_MODE,					// LVģʽ
	LVTOBV_MODE,				// LVתBVģʽ
};

enum class CameraModel
{
	QHY_USB = 0,				//��Ӧ��QHY
	HK_USB,						//��Ӧ�̺��� USB
	HK_CARD,					//��Ӧ�̺�����
	MIL_CL_CARD,				//��Ӧ��MIL CL��
	MIL_CXP_CARD,				//��Ӧ��MIL CXP��
	NN_USB,
	TOUP_USB,
	HK_FG_CARD,					//��Ӧ�̺�������fgģʽ
	IKAP_CARD,
	CameraModel_Total,
};

enum class TakeImageMode
{
	Measure_Normal = 0,			// ��ͨȡͼģʽ
	Live,						// ��Ƶģʽ
	Measure_Fast,				// ����ȡͼģʽ
	Measure_FastEx,				// ������ȡͼģʽ
};

enum GoHome_WAY : int
{
	GoHome_Mode_1 = 1,
	GoHome_Mode_2,
	GoHome_Mode_3,
	GoHome_Mode_4,
	negative_limit = 17,
	positive_limit = 18,
	GoHome_limit_1,
	GoHome_limit_2,
	GoHome_limit_3,
	GoHome_limit_4,
	GoHome_positive_limit_1,
	GoHome_positive_limit_2,
	GoHome_positive_limit_3,
	GoHome_positive_limit_4,
	GoHome_negative_limit_1,
	GoHome_negative_limit_2,
	GoHome_negative_limit_3,
	GoHome_negative_limit_4,
};

struct HImage
{
	uint	iWid;
	uint	iHei;
	uint	iChls;
	uint	iBpp;
	BYTE* pData;
};

struct IImage
{
	uint iWid;
	uint iHei;
	uint iChls;
	uint iBpp;
	BYTE* pData;
	std::shared_ptr<unsigned char> pshData;
};

enum class FOCUS_COMMUN
{
	VID_SERIAL = 0,
	CANON_SERIAL,
	NED_SERIAL,
	LONGFOOT_SERIAL,
	TSM_SERIAL,
};

struct IRECT
{
	IRECT() {}

	IRECT(int tx, int ty, int tcx, int tcy) {
		this->x = tx;
		this->y = ty;
		this->cx = tcx;
		this->cy = tcy;
	}
	IRECT& operator=(const IRECT& i) {
		this->x = i.x;
		this->y = i.y;
		this->cx = i.cx;
		this->cy = i.cy;
		return *this;
	}
	int    x;
	int    y;
	int    cx;	//��
	int    cy;	//��
};



struct IObRECT
{
	int ob;
	int obR;
	int obB;
	int obT;

public:
	IObRECT(int iob, int iobR, int iobT, int iobB)
	{
		ob = iob;
		obR = iobR;
		obT = iobT;
		obB = iobB;
	}
};

enum CornerType	//�ǵ���ȡ����
{
	Circlepoint = 0,	//Բ����ȡ
	Checkerboard = 1,	//���̸�ǵ���ȡ
};
enum SlopeType	//б�ʼ��㷽��
{
	CenterPoint = 0,	//���ĵ�ŵ�ȡб��
	lb_Variance = 1,		//ȥ������ϴ�ĵ��ȡб��
};

enum LayoutType	//����㲼�㷽��
{
	SlopeIN = 0,	//����б�ʲ���
	SlopeOUT = 1,	//������б�ʲ���
};

enum DistortionType	//TV����H,V�������ѧ����ļ�ⷽ��
{
	OpticsDist = 0,
	TVDistH = 1,
	TVDistV = 2,
};

enum class Pattern {
	matrix = 0,
};


typedef struct Blob_Threshold_Params
{
	bool filterByColor; //�Ƿ�ʹ����ɫ����
	//unsigned char blobColor; //����255����0
	int blobColor; //����255����0
	float minThreshold; //��ֵÿ�μ��ֵ
	float thresholdStep; //�ߵ���С�Ҷ�
	float maxThreshold; //�ߵ����Ҷ�

	/*version-1�õ������⼸������*/
	bool ifDEBUG;
	float darkRatio;
	float contrastRatio;
	int bgRadius;
	/*   end*/

	float minDistBetweenBlobs; //�ߵ�������
	bool filterByArea; //�Ƿ�ʹ���������
	float minArea; //�ߵ���С���ֵ
	float maxArea;  //�ߵ�������ֵ
	int minRepeatability;  //�ظ������϶�
	bool filterByCircularity;  //��״���ƣ�Բ������
	float minCircularity;
	float maxCircularity;
	bool filterByConvexity;  //��״���ƣ����ڣ�
	float minConvexity;
	float maxConvexity;
	bool filterByInertia;  //��״���ƣ���Բ�ȣ�
	float minInertiaRatio;
	float maxInertiaRatio;

	Blob_Threshold_Params()
	{
		filterByColor = true;
		blobColor = 0;
		minThreshold = 10;
		thresholdStep = 10;
		maxThreshold = 220;
		minDistBetweenBlobs = 50;

		ifDEBUG = false;
		darkRatio = 0.01f;
		contrastRatio = 0.1f;
		bgRadius = 31;

		filterByArea = true;
		minArea = 200;
		maxArea = 10000;
		minRepeatability = 2;
		filterByCircularity = false;
		minCircularity = 0.9f;
		maxCircularity = (float)1e37;
		filterByConvexity = false;
		minConvexity = 0.9f;
		maxConvexity = (float)1e37;
		filterByInertia = false;
		minInertiaRatio = 0.1f;
		maxInertiaRatio = (float)1e37;
	}
}BlobThreParams;

struct ISIZE
{
	int  cx;
	int  cy;
};

struct DPOINT
{
	double x;
	double y;
};

struct PointInt
{
	int x;
	int y;
	PointInt& operator =(const PointInt& p1) {

		this->x = p1.x;
		this->y = p1.y;
		return *this;
	}
	int getDistance(const PointInt& p1) {
		double R2 = pow((x - p1.x), 2) + pow((y - p1.y), 2);
		return (int)sqrt(R2);
	}
};

//PointInt& PointInt::operator =(const PointInt& p1) {
//	//this->nummber = p1.nummber;
//	this->x = p1.x;
//	this->y = p1.y;
//	return *this;
//}

struct PartiCle
{
	double contrast;
	int area;
	int x;
	int y;
	int color;
};

struct IIntputData
{
	float iexp_x;
	float iexp_y;
	float iexp_z;
	float iCx;
	float iCy;
	float iLv;
};

struct ChromaInfo
{
	float fX;
	float fY;
	float fZ;
	float fx;
	float fy;
	float fu;
	float fv;
	float fCCT;
	float fWave;
	int	nMidPointX;
	int	nMidPointY;
};

enum DistortionPattern
{
	NOT_EXISTING,
	CHESSBOARD,
	CIRCLES_GRID,
	ASYMMETRIC_CIRCLES_GRID
};

struct DistortionParam
{
	DistortionPattern eDisPattern;
	int	nWinSize;
	ISIZE BoardSize;
	bool useFisheye;
};
//Horizontal = 0,
//Vertical,
//Leaning,
enum class Fov_parameters
{
	FOV_Radio = 0,
	FOV_Horizontal,
	FOV_Vertical,
	FOV_Leaning,
	FOV_Pattern,
	FOV_ThresholdValue,
	FOV_CornerValue,
	FOV_CutPicSize,
	FOV_dDist,
	FOV_cameraDegrees,
	FOV_p1_x,
	FOV_p1_y,
	FOV_p2_x,
	FOV_p2_y,
	FOV_END
};

struct OPTIC_DATA
{
	int shape;	//0������Բ��1��������
	int px;		//����x
	int py;		//����y
	int w_radius;	//����뾶
	int h;			//��������ʱ��Ч
	float X;		//��ѧ���̼�ֵX
	float Y;		//��ѧ���̼�ֵY,ͬʱҲ�������ȣ���λcd����ʹ�����ȼ�ʱ��ֻ�������ѧ����
	float Z;		//��ѧ���̼�ֵZ
	float cie_x;	//CIEɫ����x
	float cie_y;	//CIEɫ����y
	float cie_u;	//CIEɫ����u
	float cie_v;	//CIEɫ����v
	float CCT;		//ɫ��
	float dominantWave; //������

};
struct AoiParam
{
	BOOL filter_by_area;
	int max_area;
	int min_area;
	BOOL filter_by_contrast;
	float max_contrast;
	float min_contrast;
	float contrast_brightness;
	float contrast_darkness;
	int blur_size;
	int min_contour_size;
	int erode_size;
	int dilate_size;

	int left;
	int right;
	int top;
	int bottom;
};

struct BrightAreaParam
{
	BOOL bBinarize;
	int nBinarizeThresh;				// ��ֵ��

	BOOL bBlur;							// ��ֵ�˲�
	int nblur_size;

	BOOL bRoi;							// roi
	int nleft;
	int nright;
	int ntop;
	int nbottom;

	BOOL bErode;						// ��ʴ
	int nerode_size;

	BOOL bDilate;						// ����
	int ndilate_size;

	BOOL bFilterRect;					// ����
	int Widht;
	int Height;

	BOOL bFilterArea;					// ����
	int nMax_area;						// �����С
	int nMin_area;

public:
	BrightAreaParam()
	{
		bBinarize = FALSE;
		nBinarizeThresh = 0;

		bBlur = FALSE;
		nblur_size = 0;

		bRoi = FALSE;
		nleft = 0;
		nright = 0;
		ntop = 0;
		nbottom = 0;

		bErode = FALSE;
		nerode_size = 0;

		bDilate = FALSE;
		ndilate_size = 0;

		bFilterRect = FALSE;
		Widht = 0;
		Height = 0;

		bFilterArea = FALSE;
		nMax_area = 0;
		nMin_area = 0;
	}
};

typedef enum
{
	ImageType_RGB = 0,
	ImageType_RBG,
	ImageType_GRB,
	ImageType_GBR,
	ImageType_BRG,
	ImageType_BGR,

}ImageType;

#if ON_LINE_SDK

#else
typedef enum {
	E_SCGD_ImgType2_Unk = -1,
	E_SCGD_ImgType2_Mono, ///<Gray
	E_SCGD_ImgType2_RGB,
	E_SCGD_ImgType2_BGR,
	E_SCGD_ImgType2_Bayer_RG8,
	E_SCGD_ImgType2_Bayer_GR8,
	E_SCGD_ImgType2_Bayer_GB8,
	E_SCGD_ImgType2_Bayer_BG8,
	E_SCGD_ImgType2_RGB48,
}E_SCGD_ImgType2;


typedef int(__stdcall* FT_SCGDOnFrm)(E_SCGD_ImgType2 imgType,
	uint8_t* pData,
	int w,
	int h,
	int lss,
	int bpp,
	int channels,
	void* usrData);
#endif

typedef int(__stdcall* AutoFocus_CallBack)(void* operate_data,
	int w,
	int h,
	int bpp,
	int channels,
	BYTE* pData,
	int nPos,
	double evalua);

typedef int(__stdcall* AutoFocus_CallBackEx)(void* operate_data,
	int w,
	int h,
	int bpp,
	int channels,
	BYTE* pData);

typedef int(__stdcall* DeviceOnline_CallBack)(void* operate_data, BOOL bDeviceOnline, char* id);

typedef int(__stdcall* AutoTime_CallBack)(int _time, double _Spectum);

typedef int(__stdcall* Emission_CallBack)(char* strText, int nLen);


typedef void (*ReceiveCallback)(HANDLE, HANDLE, BYTE*, int);
typedef void (*ListenCallback)(HANDLE, HANDLE, BOOL);

typedef void (*MRegionCallback)(HANDLE, BOOL*, int);
typedef void (*DRegionCallback)(HANDLE, WORD*, int);

typedef enum
{
	SOFTWARE_SYNCHRONOUS,		//����ͬ��ģʽ
	SOFTWARE_ASYNCHRONOUS,		//�����첽ģʽ
	SOFTWARE_AUTO,				//�Զ�����ģʽ
	EXINT_RISING_EDGE,			//�����ش���
	EXINT_FALLING_EDGE,			//�½��ش���
	EXINT_HIGH_LEVEL,			//�ߵ�ƽ����ģʽ
	EXINT_LOW_LEVEL,			//�͵�ƽ����ģʽ
}TRIGGER_MODE;

struct COLOR_PARA
{
	float fCIEx = 0;		//std XYZ
	float fCIEy = 0;
	float fCIEz = 0;

	float fCIEx_2015 = 0;		
	float fCIEy_2015 = 0;
	float fCIEz_2015 = 0;

	float fx = 0;			//ɫ��x
	float fy = 0;			//ɫ��y
	float fu = 0;			//ɫ��u'
	float fv = 0;			//ɫ��v'

	float fx_2015 = 0;			//ɫ��x
	float fy_2015 = 0;			//ɫ��y
	float fu_2015 = 0;			//ɫ��u'
	float fv_2015 = 0;			//ɫ��v'

	float fCCT = 0;			//���ɫ��(K)
	float dC = 0;			//ɫ��dC
	float fLd = 0;			//������(nm)
	float fPur = 0;			//ɫ����(%)
	float fLp = 0;			//��ֵ����(nm)
	float fHW = 0;			//�벨��(nm)
	float fLav = 0;			//ƽ������(nm)
	float fRa = 0;			//��ɫ��ָ�� Ra
	float fRR = 0;			//��ɫ��
	float fGR = 0;			//��ɫ��
	float fBR = 0;			//��ɫ��
	float fRi[15] = { 0 };		//��ɫ��ָ�� R1-R15

	float fIp = 0;			//��ֵAD

	float fPh = 0;			//���ֵ,Ҳ��������
	float fPhe = 0;			//�����ֵ
	float fPlambda = 0;		//���Թ���ϴ��
	float fSpect1 = 0;		//��ʼ����
	float fSpect2 = 0;		//��������
	float fInterval = 0;
	float fPL[10000] = { 0 };	//��������
};

struct COLOR_PARA_EQE
{
	float fx = 0;			//ɫ��x
	float fy = 0;			//ɫ��y
	float fu = 0;			//ɫ��u'
	float fv = 0;			//ɫ��v'
	float fCCT = 0;			//���ɫ��(K)
	float dC = 0;			//ɫ��dC
	float fLd = 0;			//������(nm) 
	float fPur = 0;			//ɫ����(%)
	float fLp = 0;			//��ֵ����(nm)
	float fHW = 0;			//�벨��(nm)
	float fLav = 0;			//ƽ������(nm)
	float fRa = 0;			//��ɫ��ָ�� Ra
	float fRR = 0;			//��ɫ��
	float fGR = 0;			//��ɫ��
	float fBR = 0;			//��ɫ��

	float fIp = 0;			//��ֵAD

	float fPh = 0;			//���ֵ,Ҳ��������
	float fPhe = 0;			//�����ֵ
	float fPlambda = 0;		//���Թ���ϴ��
	float fSpect1 = 0;		//��ʼ����
	float fSpect2 = 0;		//��������
	float fInterval = 0;

	float fPL[4001] = { 0 };	//��������

	float dIm = 0;
	double dW = 0;
	double dEqe = 0;
	double dVoltage = 0;
	double dCurrent = 0;
	double dP = 0;
};

struct TargetMatchPoint
{
	double dCenter_x = 0;
	double dCenter_y = 0;
	double dLT_x = 0;
	double dLT_y = 0;
	double dRT_x = 0;
	double dRT_y = 0;
	double dRB_x = 0;
	double dRB_y = 0;
	double dLB_x = 0;
	double dLB_y = 0;
	double dScore = 0;
	double dAngle = 0;
};

typedef struct _BFResultDataDegree {
	/// <summary>
	/// ����
	/// </summary>
	float Radian;
	/// <summary>
	/// �Ƕ�/Degree
	/// </summary>
	float Degree;
	/// <summary>
	/// ��
	/// </summary>
	float AngDegree;
	/// <summary>
	/// ��
	/// </summary>
	float AngMinute;
	/// <summary>
	/// ��
	/// </summary>
	float AngSecond;

public:
	_BFResultDataDegree() {
		Radian = 0;
		Degree = 0;
		AngDegree = 0;
		AngMinute = 0;
		AngSecond = 0;
	};
}BFResultDataDegree;

/// <summary>
/// AR/VR˫Ŀ�ںϽ��
/// </summary>
struct BFResultData {
	DPOINT CrossMarkCenter;
	BFResultDataDegree XDegree;
	BFResultDataDegree YDegree;
	BFResultDataDegree ZDegree;
public:
	BFResultData() {
		CrossMarkCenter.x = 0;
		CrossMarkCenter.y = 0;
	};
};