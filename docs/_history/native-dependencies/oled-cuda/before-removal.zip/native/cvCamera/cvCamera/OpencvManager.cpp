#include "stdafx.h"
#include "OpencvManager.h"
#include "CMStruct.h"
#include <limits>
#include "cvErrorDefine.h"
#include <numeric>
#include <Eigen/Dense>
#include <unsupported/Eigen/Splines>
#include "cvCalibration.h"
#include <fstream>
#include "cvOled.h"

std::vector<std::vector<Point>> brightContours;

bool Trackbar(const Mat& image, float Harris_k, int& PointX, int& PointY, int edge)
{
	Mat dst, dst8u, dstshow/*, imageSource*/;
	dst = Mat::zeros(image.size(), CV_32FC1);
	//imageSource = image.clone();
	uchar maxdata = 0;

	bool testresult = false;
	while (!testresult)
	{
		cornerHarris(image, dst, 3, 3, Harris_k, BORDER_DEFAULT);
		normalize(dst, dst8u, 0, 255, 32);  //��һ��
		convertScaleAbs(dst8u, dstshow);
		//imshow("dst", dstshow);  //dst��ʾ

		for (int i = edge; i < image.rows - edge; i++)
		{
			for (int j = edge; j < image.cols - edge; j++)
			{
				if (dstshow.at<uchar>(i, j) > maxdata)
				{
					maxdata = dstshow.at<uchar>(i, j);
					PointX = j;
					PointY = i;
				}
			}
		}
		if (maxdata != 0)
		{
			testresult = true;
		}
		else
		{
			Harris_k = Harris_k - 0.01;
			if (Harris_k < 0)
			{
				LOGD("�ǵ������BUG��");
				return false;
			}
		}
	}

	return true;
}

BOOL WINAPI OpencvManager::findExactCornerPoint(Mat& srcImage, Point2f* cornerPoint, double qualityLevel, const int cutWidth, const int edge)
{
	Mat fourPartImage[4];		//��ȡ�Ľ����򣬽��Ҿ�ȷ�ǵ��������С
	//const int width = 400;			//��ȡ�������ı߳�

	for (int i = 0; i < 4; i++) {

		if (cornerPoint[i].x < cutWidth / 2 + 1 || cornerPoint[i].y < cutWidth / 2 + 1
			|| cornerPoint[i].x > srcImage.cols - cutWidth / 2 - 1 ||
			cornerPoint[i].y > srcImage.rows - cutWidth / 2 - 1) {
			return CV_ERR_ALG_WRONG_CONTOURS_LOCAL;
		}
	}
	//���ĸ��ǵ�Ϊ���ģ��г�4��Сͼ
	fourPartImage[0] = srcImage(Rect(cornerPoint->x - cutWidth / 2, cornerPoint->y - cutWidth / 2, cutWidth, cutWidth));
	fourPartImage[1] = srcImage(Rect((cornerPoint + 1)->x - cutWidth / 2, (cornerPoint + 1)->y - cutWidth / 2, cutWidth, cutWidth));
	fourPartImage[2] = srcImage(Rect((cornerPoint + 2)->x - cutWidth / 2, (cornerPoint + 2)->y - cutWidth / 2, cutWidth, cutWidth));
	fourPartImage[3] = srcImage(Rect((cornerPoint + 3)->x - cutWidth / 2, (cornerPoint + 3)->y - cutWidth / 2, cutWidth, cutWidth));

	//float Harris_k = 0.04;
	//int edge = 10;
	//�ֱ���4��Сͼ���ҽǵ�
	for (int i = 0; i < 4; i++) {
		/*vector<Point2f>cornerVector;
		goodFeaturesToTrack(fourPartImage[i], cornerVector, 3, qualityLevel, 10, noArray(), 3, true);*/
		int Px = 0, Py = 0;
		bool suceess = Trackbar(fourPartImage[i], qualityLevel, Px, Py, edge);
		//Trackbar(regionPic, Harris_k, i, px, py, edge);
		//cout << "corner.size: " << cornerVector.size() << endl;		//test
		if (suceess) {
			cornerPoint[i].x = (cornerPoint + i)->x + Px - cutWidth / 2;
			cornerPoint[i].y = (cornerPoint + i)->y + Py - cutWidth / 2;
		}

	}
	return CV_ERR_SUCCESS;
}

int WINAPI OpencvManager::findExactCornerPoint(Mat& srcImage, vector<Point2f>& cornerPoint, double qualityLevel, const int cutWidth, const int edge) {

	Mat fourPartImage[4];		//��ȡ�Ľ����򣬽��Ҿ�ȷ�ǵ��������С
	//const int width = 400;			//��ȡ�������ı߳�

	for (int i = 0; i < 4; i++) {

		if (cornerPoint[i].x < cutWidth / 2 + 1 || cornerPoint[i].y < cutWidth / 2 + 1
			|| cornerPoint[i].x > srcImage.cols - cutWidth / 2 - 1 ||
			cornerPoint[i].y > srcImage.rows - cutWidth / 2 - 1) {
			return CV_ERR_ALG_WRONG_CONTOURS_LOCAL;
		}
	}
	//���ĸ��ǵ�Ϊ���ģ��г�4��Сͼ
	fourPartImage[0] = srcImage(Rect(cornerPoint[0].x - cutWidth / 2, cornerPoint[0].y - cutWidth / 2, cutWidth, cutWidth));
	fourPartImage[1] = srcImage(Rect(cornerPoint[1].x - cutWidth / 2, cornerPoint[1].y - cutWidth / 2, cutWidth, cutWidth));
	fourPartImage[2] = srcImage(Rect(cornerPoint[2].x - cutWidth / 2, cornerPoint[2].y - cutWidth / 2, cutWidth, cutWidth));
	fourPartImage[3] = srcImage(Rect(cornerPoint[3].x - cutWidth / 2, cornerPoint[3].y - cutWidth / 2, cutWidth, cutWidth));

	//float Harris_k = 0.04;
	int resultPoint = 0;
	//�ֱ���4��Сͼ���ҽǵ�
	for (int i = 0; i < 4; i++) {

		int Px = 0, Py = 0;
		bool suceess = Trackbar(fourPartImage[i], qualityLevel, Px, Py, edge);

		if (suceess) {
			cornerPoint[i].x = cornerPoint[i].x + Px - cutWidth / 2;
			cornerPoint[i].y = cornerPoint[i].y + Py - cutWidth / 2;
			resultPoint++;

		}

	}
	/*Mat showExactConer = srcImage;
	if (srcImage.channels()==1)
	{
		cvtColor(srcImage, showExactConer, COLOR_GRAY2BGR);
	}
	for (int i=0;i<4;i++)
	{
		circle(showExactConer, cornerPoint[i], 3, Scalar(0, 0, 60000), -1);
	}
	imwrite("TIFF\\showExactConer.tif", showExactConer);*/
	LOGFMTI("�ɹ�����λ%d���ǵ�", resultPoint);
	return resultPoint;
}

BOOL WINAPI OpencvManager::sortCornerPoints(vector< cv::Point2f>& cornerPoints) {
	if (cornerPoints.size() < 4)
	{
		return CV_ERR_ALG_WRONG_CONTOURS_SIZE;
	}

	//cv::Point2f* cornerPoints;

	//��Ӿ��η��ص��ĸ���������˳ʱ���Ų��ģ�ͨ���ж���һ������ڶ�����Ĺ�ϵ�����ж���������½ǻ������Ͻ�
	int chazhi = -1;

	if (cornerPoints[1].x - cornerPoints[0].x > abs(cornerPoints[0].y - cornerPoints[1].y)) {
		chazhi = 1;
	}
	else if (cornerPoints[0].y - cornerPoints[1].y > abs(cornerPoints[0].x - cornerPoints[1].x)) {
		chazhi = 2;
	}
	else if (cornerPoints[0].x - cornerPoints[1].x > abs(cornerPoints[0].y - cornerPoints[1].y)) {
		chazhi = 3;
	}
	else {
		chazhi = 4;
	}

	vector< cv::Point2f>temoVectorPoints = cornerPoints;

	switch (chazhi) {
	case 1:
		temoVectorPoints[0] = cv::Point2f(cornerPoints[0].x, cornerPoints[0].y);
		temoVectorPoints[1] = cv::Point2f(cornerPoints[1].x, cornerPoints[1].y);
		temoVectorPoints[2] = cv::Point2f(cornerPoints[2].x, cornerPoints[2].y);
		temoVectorPoints[3] = cv::Point2f(cornerPoints[3].x, cornerPoints[3].y);
		break;
	case 2:
		temoVectorPoints[0] = cv::Point2f(cornerPoints[1].x, cornerPoints[1].y);
		temoVectorPoints[1] = cv::Point2f(cornerPoints[2].x, cornerPoints[2].y);
		temoVectorPoints[2] = cv::Point2f(cornerPoints[3].x, cornerPoints[3].y);
		temoVectorPoints[3] = cv::Point2f(cornerPoints[0].x, cornerPoints[0].y);
		break;
	case 3:
		temoVectorPoints[0] = cv::Point2f(cornerPoints[2].x, cornerPoints[2].y);
		temoVectorPoints[1] = cv::Point2f(cornerPoints[3].x, cornerPoints[3].y);
		temoVectorPoints[2] = cv::Point2f(cornerPoints[0].x, cornerPoints[0].y);
		temoVectorPoints[3] = cv::Point2f(cornerPoints[1].x, cornerPoints[1].y);
		break;
	case 4:
		temoVectorPoints[0] = cv::Point2f(cornerPoints[3].x, cornerPoints[3].y);
		temoVectorPoints[1] = cv::Point2f(cornerPoints[0].x, cornerPoints[0].y);
		temoVectorPoints[2] = cv::Point2f(cornerPoints[1].x, cornerPoints[1].y);
		temoVectorPoints[3] = cv::Point2f(cornerPoints[2].x, cornerPoints[2].y);
		break;
	default:
		return CV_ERR_ALG_WRONG_CONTOURS_CHAZHI;
	}
	cornerPoints = temoVectorPoints;
	return CV_ERR_SUCCESS;
}

// �ҳ����Ͷ����ͼƬ
BOOL WINAPI OpencvManager::pickHighSaturationImage(Mat* imgArr, Mat& dst, int n)
{
	if (n <= 0) {
		return CV_ERR_ALG_IMG_CHANNEL;
	}

	float maxSaturation = numeric_limits<float>::lowest();
	for (int i = 0; i < n; i++)
	{
		float saturation = caclSaturation(imgArr[i]);
		if (maxSaturation < saturation) {
			maxSaturation = saturation;
			dst = imgArr[i];
		}
	}

	return CV_ERR_SUCCESS;
}

float WINAPI OpencvManager::caclSaturation(Mat& images)
{
	int top1 = (int)images.total();
	double minVal = 0, maxVal = 0;
	minMaxIdx(images, &minVal, &maxVal);
	maxVal += 1;
	MatND histogram;
	// 65536������Χ��0��65535.
	const int histSize = (maxVal - minVal) + 1;
	float range[] = { minVal, maxVal };
	const float* ranges[] = { range };
	const int channels = 0;
	calcHist(&images, 1, &channels, Mat(), histogram, 1, &histSize, &ranges[0], true, false);
	float* h = (float*)histogram.data;
	int maxIdx = histogram.rows;
	//std::stringstream strStream;
	double sum = 0;
	int cnt = 0;
	int ln = 0;
	int valNum = 0;

	int grayVal = 0;
	for (int i = maxIdx - 1; i >= 0; i--)
	{
		grayVal = i + minVal;
		valNum = h[i];
		if (valNum > 0) {
			//ln++;
			int reCnt = top1 - cnt;

			if (reCnt >= valNum) {
				sum += (double)valNum * (double)grayVal;
				cnt += valNum;
			}
			else
			{
				sum += (double)reCnt * (double)grayVal;
				cnt += reCnt;
			}
			if (top1 == cnt)
				break;
		}
		else
			continue;
	}

	float mean = sum; /// top1;
	float saturation = mean;// maxSatVal * 100.0f;

	return saturation;
}

BOOL WINAPI OpencvManager::OtsuAlgThresholdTEST(const Mat& image, int& otsu)
{
	if (image.channels() != 1)
	{
		LOGE("������Ҷ�ͼ");
		return CV_ERR_ALG_IMG_CHANNEL;
	}
	int T = 0; //Otsu�㷨��ֵ
	double varValue = 0; //��䷽���м�ֵ����
	double w0 = 0; //ǰ�����ص�����ռ����
	double w1 = 0; //�������ص�����ռ����
	double u0 = 0; //ǰ��ƽ���Ҷ�
	double u1 = 0; //����ƽ���Ҷ�
	double Histogram[256] = { 0 }; //�Ҷ�ֱ��ͼ���±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ�����ص�����
	uchar* data = image.data;
	double totalNum = image.rows * image.cols; //��������
	//����Ҷ�ֱ��ͼ�ֲ���Histogram�����±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ���ص���
	for (int i = 0; i < image.rows; i++)   //Ϊ������������û�а�rows��cols���������
	{
		for (int j = 0; j < image.cols; j++)
		{
			Histogram[data[i * image.step + j]]++;
		}
	}
	for (int i = 0; i < 255; i++)
	{
		//ÿ�α���֮ǰ��ʼ��������
		w1 = 0;		u1 = 0;		w0 = 0;		u0 = 0;
		//***********����������ֵ����**************************
		for (int j = 0; j <= i; j++) //�������ָ�ֵ����
		{
			w1 += Histogram[j];  //�����������ص�����
			u1 += j * Histogram[j]; //�������������ܻҶȺ�
		}
		if (w1 == 0) //�����������ص���Ϊ0ʱ�˳�
		{
			continue;
		}
		u1 = u1 / w1; //��������ƽ���Ҷ�
		w1 = w1 / totalNum; // �����������ص�����ռ����
		//***********����������ֵ����**************************

		//***********ǰ��������ֵ����**************************
		for (int k = i + 1; k < 255; k++)
		{
			w0 += Histogram[k];  //ǰ���������ص�����
			u0 += k * Histogram[k]; //ǰ�����������ܻҶȺ�
		}
		if (w0 == 0) //ǰ���������ص���Ϊ0ʱ�˳�
		{
			break;
		}
		u0 = u0 / w0; //ǰ������ƽ���Ҷ�
		w0 = w0 / totalNum; // ǰ���������ص�����ռ����
		//***********ǰ��������ֵ����**************************

		//***********��䷽�����******************************
		double varValueI = w0 * w1 * (u1 - u0) * (u1 - u0); //��ǰ��䷽�����
		if (varValue < varValueI)
		{
			varValue = varValueI;
			T = i;
		}
	}
	otsu = T;
	return CV_ERR_SUCCESS;
}

double WINAPI OpencvManager::binarize(const Mat& inputImage, Mat& outputImage, const double thresh)
{
	return threshold(inputImage, outputImage, thresh, 255, THRESH_BINARY);
}

double WINAPI OpencvManager::binarize(Mat inputImage, double thresh)
{
	return threshold(inputImage, inputImage, thresh, 255, THRESH_BINARY);
}

void WINAPI OpencvManager::Dilate(const Mat& src, Mat& dst, int size)
{
	Mat kernel = getStructuringElement(MORPH_RECT, Size(size, size));
	dilate(src, dst, kernel);
}

void WINAPI OpencvManager::Dilate(Mat& src, int size)
{
	Mat kernel = getStructuringElement(MORPH_RECT, Size(size, size));
	dilate(src, src, kernel);
}

void WINAPI OpencvManager::Erode(const Mat& src, Mat& dst, int size)
{
	Mat kernel = getStructuringElement(MORPH_RECT, Size(size, size));
	erode(src, dst, kernel);
}

void WINAPI OpencvManager::Erode(Mat& src, int size)
{
	Mat kernel = getStructuringElement(MORPH_RECT, Size(size, size));
	erode(src, src, kernel);
}


BOOL WINAPI OpencvManager::findBrightCornerPoint(Mat& binaryImage, Point2f* cornerPoint, uint bright_w, uint bright_h)
{
	brightContours.clear();

	//connePointָ�򷢹������ĸ��ǵ�
	//����С��Ӿ�
	findContours(binaryImage, brightContours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

	if (brightContours.size() < 1)
	{
		LOGD("fail to findcontours!");
		return CV_ERR_ALG_WRONG_CONTOURS;
	}

	RotatedRect outRect;

	for (int i = 0; i < brightContours.size(); i++)
	{
		//��Ҫ��ð����㼯��С����ľ���,��������ǿ�����ƫת�Ƕȵģ�������ͼ��ı߽粻ƽ��
		outRect = minAreaRect(Mat(brightContours[i]));
		if (outRect.size.width > bright_w && outRect.size.height > bright_h)//ɸѡ��һ����Χ�ڵ�����
		{
			break;
		}
	}

	Point2f fourPoint[4];

	outRect.points(fourPoint);

	int chazhi = -1;
	if (fourPoint[1].x - fourPoint[0].x > abs(fourPoint[0].y - fourPoint[1].y)) {
		chazhi = 1;
	}
	else if (fourPoint[0].y - fourPoint[1].y > abs(fourPoint[0].x - fourPoint[1].x)) {
		chazhi = 2;
	}
	else if (fourPoint[0].x - fourPoint[1].x > abs(fourPoint[0].y - fourPoint[1].y)) {
		chazhi = 3;
	}
	else {
		chazhi = 4;
	}

	switch (chazhi) {
	case 1:
		cornerPoint[0] = cv::Point2f(fourPoint[0].x, fourPoint[0].y);
		cornerPoint[1] = cv::Point2f(fourPoint[1].x, fourPoint[1].y);
		cornerPoint[2] = cv::Point2f(fourPoint[2].x, fourPoint[2].y);
		cornerPoint[3] = cv::Point2f(fourPoint[3].x, fourPoint[3].y);
		break;
	case 2:
		cornerPoint[0] = cv::Point2f(fourPoint[1].x, fourPoint[1].y);
		cornerPoint[1] = cv::Point2f(fourPoint[2].x, fourPoint[2].y);
		cornerPoint[2] = cv::Point2f(fourPoint[3].x, fourPoint[3].y);
		cornerPoint[3] = cv::Point2f(fourPoint[0].x, fourPoint[0].y);
		break;
	case 3:
		cornerPoint[0] = cv::Point2f(fourPoint[2].x, fourPoint[2].y);
		cornerPoint[1] = cv::Point2f(fourPoint[3].x, fourPoint[3].y);
		cornerPoint[2] = cv::Point2f(fourPoint[0].x, fourPoint[0].y);
		cornerPoint[3] = cv::Point2f(fourPoint[1].x, fourPoint[1].y);
		break;
	case 4:
		cornerPoint[0] = cv::Point2f(fourPoint[3].x, fourPoint[3].y);
		cornerPoint[1] = cv::Point2f(fourPoint[0].x, fourPoint[0].y);
		cornerPoint[2] = cv::Point2f(fourPoint[1].x, fourPoint[1].y);
		cornerPoint[3] = cv::Point2f(fourPoint[2].x, fourPoint[2].y);
		break;
	default:
		return CV_ERR_ALG_WRONG_CONTOURS_CHAZHI;
	}

	return CV_ERR_SUCCESS;
}

BOOL WINAPI OpencvManager::dilateImage(const Mat& inputImage, Mat& dst, int timeProcess, bool direct)
{
	dst = inputImage.clone();

	int time = 0;
	if (direct) {

		while (time < timeProcess)
		{
			dilate(dst, dst, Mat());
			time++;
		}

		time = 0;

		while (time < timeProcess)
		{
			erode(dst, dst, Mat());
			time++;
		}
	}
	else
	{
		while (time < timeProcess)
		{
			erode(dst, dst, Mat());
			time++;
		}
		time = 0;
		while (time < timeProcess)
		{
			dilate(dst, dst, Mat());
			time++;
		}
	}

	return CV_ERR_SUCCESS;
}

int WINAPI OpencvManager::Gettype(int nbpp, int nChannels)
{
	int ntype = CV_MAKETYPE(CV_8U, nChannels);

	switch (nbpp)
	{
	case 8:
		ntype = CV_MAKETYPE(CV_8U, nChannels);
		break;
	case 16:
		ntype = CV_MAKETYPE(CV_16U, nChannels);
		break;
	case 32:
		ntype = CV_MAKETYPE(CV_32F, nChannels);
		break;
	case 64:
		ntype = CV_MAKETYPE(CV_64F, nChannels);
		break;
	default:
		LOGD("ibpp ���ݲ��ԣ�ͼƬ��ʽ����");
		return CV_ERR_ALG_IMG_TYPE;
	}

	return ntype;
}

void WINAPI OpencvManager::MatToCImage(cv::Mat& matsrc, cv::Mat& matdst)
{
	int nImgHei = matsrc.rows;
	int nImgWid = matsrc.cols;
	int nChannels = matsrc.channels();
	int nBpp = int(matsrc.step.buf[1] * 8 / nChannels);

	cv::Mat mattemp;

	if (nChannels == 1)
	{
		mattemp = cv::Mat(nImgHei, nImgWid, CV_8UC1);
	}
	else if (nChannels == 3)
	{
		mattemp = cv::Mat(nImgHei, nImgWid, CV_8UC3);
	}

	BYTE* pbDestRow = reinterpret_cast<BYTE*>(mattemp.data);

	if (nBpp == 32)
	{
		float* pbSrcRow = reinterpret_cast<float*>(matsrc.data);

		for (int h = 0; h < nImgHei; h++)
		{
			for (int w(0); w < mattemp.step.buf[0]; w++)
			{
				int nValue = int(pbSrcRow[w] * 255);

				if (nValue > 255)
				{
					pbDestRow[w] = 255;
				}
				else if (nValue < 0)
				{
					pbDestRow[w] = 0;
				}
				else
				{
					pbDestRow[w] = nValue;
				}
			}

			pbDestRow += mattemp.step.buf[0];
			pbSrcRow += matsrc.step.buf[0] / sizeof(float);
		}
	}
	else if (nBpp == 16)
	{
		float* pbSrcRow = reinterpret_cast<float*>(matsrc.data);

		for (int h = 0; h < nImgHei; h++)
		{
			for (int w(0); w < nImgWid * nChannels; w++)
			{
				mattemp.at<BYTE>(h, w) = matsrc.at<ushort>(h, w) / 256;
			}
		}
	}
	else
	{
		mattemp = NULL;
		mattemp = matsrc;
	}

	matdst = mattemp;

}

cv::Mat OpencvManager::MatToCImage(cv::Mat& matsrc)
{
	int nImgHei = matsrc.rows;
	int nImgWid = matsrc.cols;
	int nChannels = matsrc.channels();
	int nBpp = int(matsrc.step.buf[1] * 8 / nChannels);

	cv::Mat matdst;

	if (nChannels == 1)
	{
		matdst = cv::Mat(nImgHei, nImgWid, CV_8UC1);
	}
	else if (nChannels == 3)
	{
		matdst = cv::Mat(nImgHei, nImgWid, CV_8UC3);
	}

	BYTE* pbDestRow = reinterpret_cast<BYTE*>(matdst.data);

	if (nBpp == 32)
	{
		float* pbSrcRow = reinterpret_cast<float*>(matsrc.data);

		for (int h = 0; h < nImgHei; h++)
		{
			for (int w(0); w < matdst.step.buf[0]; w++)
			{
				int nValue = int(pbSrcRow[w] * 255);

				if (nValue > 255)
				{
					pbDestRow[w] = 255;
				}
				else if (nValue < 0)
				{
					pbDestRow[w] = 0;
				}
				else
				{
					pbDestRow[w] = nValue;
				}
			}

			pbDestRow += matdst.step.buf[0];
			pbSrcRow += matsrc.step.buf[0] / sizeof(float);
		}
	}
	else if (nBpp == 16)
	{
		float* pbSrcRow = reinterpret_cast<float*>(matsrc.data);

		for (int h = 0; h < nImgHei; h++)
		{
			for (int w(0); w < nImgWid * nChannels; w++)
			{
				matdst.at<BYTE>(h, w) = matsrc.at<ushort>(h, w) / 256;
			}
		}
	}
	else
	{
		matdst = NULL;
		matdst = matsrc;
	}

	return matdst;
}

vector<vector<Point>> gCircleContours_getCirclePoint;
BOOL OpencvManager::getCirclePoint(cv::Mat matsrc, int thresholdValue, cv::Point& tPt, double DarkRatio)
{
	cv::Mat single8bit = matsrc.clone();

	Point ImageCenter;
	ImageCenter.x = matsrc.cols / 2;
	ImageCenter.y = matsrc.rows / 2;

	int temp = 0;
	double grayThreshold = 0.0;
	for (int i = -5; i < 5; i++)
	{
		for (int j = -5; j < 5; j++)
		{
			temp = (int)single8bit.at<uchar>(ImageCenter.y + i, ImageCenter.x + j);
			grayThreshold = grayThreshold + temp;
		}
	}
	grayThreshold = grayThreshold / 100.0;
	int grayDThreshold = (int)(grayThreshold * DarkRatio);

	threshold(single8bit, single8bit, grayDThreshold, 255, THRESH_BINARY);

	gCircleContours_getCirclePoint.clear();
	findContours(single8bit, gCircleContours_getCirclePoint, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

	if (gCircleContours_getCirclePoint.size() == 0)
	{
		LOGE("No circle be checked.");
		return CV_ERR_ALG_FOV_NOCIRCLE;
	}

	RotatedRect outRect;
	int key = -1;
	float minLenth = 0;
	if (single8bit.rows > single8bit.cols) {
		minLenth = single8bit.cols;
	}
	else
	{
		minLenth = single8bit.rows;
	}
	int rectMax = -1;
	for (int i = 0; i < gCircleContours_getCirclePoint.size(); i++)
	{
		outRect = minAreaRect(Mat(gCircleContours_getCirclePoint[i]));
		//if (outRect.size.width > 0.15 * minLenth && outRect.size.height > 0.15 * minLenth)//ɸѡ��һ����Χ�ڵ�����
		//{
		//	key = i;
		//	break;
		//}

		//////update:20230815 choose the biggest rect in the pic
		if (outRect.size.width * outRect.size.height > rectMax)
		{
			key = i;
			rectMax = outRect.size.width * outRect.size.height;
		}
	}
	if (key == -1)
	{
		LOGE("No correct circle be checked.");
		return CV_ERR_ALG_FOV_NOCIRCLE;
	}

	RotatedRect box = fitEllipse(gCircleContours_getCirclePoint[key]);	////fitEllipse����������Բ����С��Ӿ��Σ�RotatedRect��opencv�Դ�����
	tPt.x = box.center.x;
	tPt.y = box.center.y;
	single8bit.release();
	return CV_ERR_SUCCESS;
}

vector<vector<Point>> gCircleContours_getRectCorners;
BOOL OpencvManager::getRectCorners(cv::Mat matsrc, int thresholdValue, vector<cv::Point2f>& rect_Corners, double DarkRatio)
{
	cv::Mat single8bit = matsrc.clone();
	Point ImageCenter;
	ImageCenter.x = matsrc.cols / 2;
	ImageCenter.y = matsrc.rows / 2;

	int temp = 0;
	double grayThreshold = 0.0;
	int centreRect = 5;
	for (int i = -centreRect; i < centreRect; i++)
	{
		for (int j = -centreRect; j < centreRect; j++)
		{
			temp = (int)single8bit.at<uchar>(ImageCenter.y + i, ImageCenter.x + j);
			grayThreshold += temp;
		}
	}
	grayThreshold = grayThreshold / (centreRect * centreRect * 4);
	int grayDThreshold = (int)(grayThreshold * DarkRatio);

	rect_Corners.clear();
	threshold(single8bit, single8bit, grayDThreshold, 255, THRESH_BINARY);

	imwrite("TIFF\\fov-threshold.tif", single8bit);
	gCircleContours_getRectCorners.clear();
	findContours(single8bit, gCircleContours_getRectCorners, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

	if (gCircleContours_getRectCorners.size() == 0)
	{
		return CV_ERR_ALG_FOV_NOCIRCLE;
	}

	RotatedRect outRect;
	RotatedRect box;
	int key = -1;
	float minLenth = 0;
	if (single8bit.rows > single8bit.cols) {
		minLenth = single8bit.cols;
	}
	else
	{
		minLenth = single8bit.rows;
	}
	int rectMax = -1;
	for (int i = 0; i < gCircleContours_getRectCorners.size(); i++)
	{
		outRect = minAreaRect(Mat(gCircleContours_getRectCorners[i]));
		//if (outRect.size.width > 0.15 * minLenth && outRect.size.height > 0.15 * minLenth)//ɸѡ��һ����Χ�ڵ�����
		//{
		//	key = i;
		//	box = outRect;
		//	break;
		//}

		//////update:20230815 choose the biggest rect in the pic
		if (outRect.size.width * outRect.size.height > rectMax)
		{
			key = i;
			box = outRect;
			rectMax = outRect.size.width * outRect.size.height;
		}
	}
	if (key == -1)
	{
		//LOGE("No correct circle be checked.");
		return CV_ERR_ALG_FOV_NOCIRCLE;
	}

	Point2f pt[4];
	box.points(pt);
	vector<Point2f>vecTemp;	//�������£����£����ϣ����ϵ�˳�����4�����νǵ�
	for (int i = 0; i < 4; i++)
	{
		vecTemp.push_back(pt[i]);
	}
	BOOL ret = sortCornerPoints(vecTemp);
	if (ret != CV_ERR_SUCCESS) {
		return ret;
	}
	/*float max = 0.;
	float min = 9999999;
	vector<Point2f> vec;
	int m = -1;
	int n = -1;
	for (int i = 0; i < 4; i++)
	{
		if (sqrt(pt[i].x * pt[i].x + pt[i].y * pt[i].y) > max)
		{
			max = sqrt(pt[i].x * pt[i].x + pt[i].y * pt[i].y);
			pts[0].x = pt[i].x;
			pts[0].y = pt[i].y;
			m = i;
		}
		if (sqrt(pt[i].x * pt[i].x + pt[i].y * pt[i].y) < min)
		{
			min = sqrt(pt[i].x * pt[i].x + pt[i].y * pt[i].y);
			pts[2].x = pt[i].x;
			pts[2].y = pt[i].y;
			n = i;
		}
	}
	for (int i = 0; i < 4; i++)
	{
		if (i != m && i != n)
		{
			vec.push_back(pt[i]);
		}
	}
	if (vec[0].x > vec[1].x)
	{
		pts[1].x = vec[1].x;
		pts[1].y = vec[1].y;
		pts[3].x = vec[0].x;
		pts[3].y = vec[0].y;
	}
	else
	{
		pts[1].x = vec[0].x;
		pts[1].y = vec[0].y;
		pts[3].x = vec[1].x;
		pts[3].y = vec[1].y;
	}*/

	rect_Corners.resize(4);
	rect_Corners[0] = vecTemp[2];
	rect_Corners[1] = vecTemp[3];
	rect_Corners[2] = vecTemp[0];
	rect_Corners[3] = vecTemp[1];

	/*findExactCornerPoint(single8bit, rect_Corners, 0.04, 400, 10);
	Mat sm = single8bit.clone();
	if (single8bit.channels() == 1)
	{
		cv::cvtColor(single8bit, sm, COLOR_GRAY2BGR);
	}
	for (int i = 0; i < rect_Corners.size(); i++)
	{
		circle(sm, rect_Corners[i], 3, Scalar(0, 0, 60000), -1);
	}
	imwrite("TIFF\\fovCorner.tif", sm);*/
	single8bit.release();
	return CV_ERR_SUCCESS;
}

BOOL OpencvManager::RoughBoundaryRectDetection(Mat srcpic, vector<Point2f> Corners, vector<Point2f>& border_Corners, double gradient, double DarkRatio, FovType type)
{
	Mat dstpic = srcpic.clone();
	border_Corners.clear();
	Point ImageCenter;
	ImageCenter.x = (int)((Corners[0].x + Corners[1].x + Corners[2].x + Corners[3].x) / 4);
	ImageCenter.y = (int)((Corners[0].y + Corners[1].y + Corners[2].y + Corners[3].y) / 4);

	double grayThreshold = 0.0;
	int temp = 0;
	const int centreRect = 5;//��ȡ��������Ҷȵ�ȡ����С
	if (ImageCenter.x - centreRect<0 || ImageCenter.x + centreRect> dstpic.rows || ImageCenter.y - centreRect<0 || ImageCenter.y + centreRect> dstpic.rows)
	{
		return CV_ERR_ALG_IMG_SIZE;
	}
	for (int i = -centreRect; i < centreRect; i++)
	{
		for (int j = -centreRect; j < centreRect; j++)
		{
			temp = (int)dstpic.at<uchar>(ImageCenter.y + i, ImageCenter.x + j);
			grayThreshold = grayThreshold + temp;
		}
	}
	grayThreshold = grayThreshold / (centreRect * centreRect * 4);
	double grayLThreshold = grayThreshold * 0.4;
	double grayDThreshold = grayThreshold * DarkRatio;
	int nCount = 0;

	if (type == Horizontal)
	{
		Point2f leftPoint;
		Point leftCorner;
		Point2f rightPoint;
		Point rightCorner;

		if ((Corners[1].x + Corners[2].x) - (Corners[0].x + Corners[3].x) <= 0)
		{
			leftPoint.x = (Corners[1].x + Corners[2].x) / 2;
			leftPoint.y = (Corners[1].y + Corners[2].y) / 2;
			rightPoint.x = (Corners[0].x + Corners[3].x) / 2;
			rightPoint.y = (Corners[0].y + Corners[3].y) / 2;
		}
		else
		{
			rightPoint.x = (Corners[1].x + Corners[2].x) / 2;
			rightPoint.y = (Corners[1].y + Corners[2].y) / 2;
			leftPoint.x = (Corners[0].x + Corners[3].x) / 2;
			leftPoint.y = (Corners[0].y + Corners[3].y) / 2;
		}
		double leftTemp = 0.;
		double rightTemp = 0.;
		float slop = (ImageCenter.y - leftPoint.y) / (ImageCenter.x - leftPoint.x);
		nCount = 0;
		for (int i = ImageCenter.x; i > 4; i--)
		{
			int y0 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 0)));
			int y1 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 1)));
			int y2 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 2)));
			int y3 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 3)));
			int y4 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 4)));
			int y5 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 1)));
			int y6 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 2)));
			int y7 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 3)));
			int y8 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 4)));
			if ((int)dstpic.at<uchar>(y4, i - 4) < grayDThreshold && (int)dstpic.at<uchar>(y3, i - 3) < grayDThreshold && (int)dstpic.at<uchar>(y2, i - 2) < grayDThreshold && (int)dstpic.at<uchar>(y1, i - 1) < grayDThreshold)
			{
				//cout << "Success searched the image left border" << endl;
				break;
			}
			double temp = (1.0 * ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) + (int)dstpic.at<uchar>(y5, i + 1)) / ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)));
			double temp0 = ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)) / 4.0;
			if ((temp > gradient) && (temp > leftTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				leftTemp = temp;
				leftCorner = Point(i, y0);
				nCount++;
			}
			if (nCount == 0)
			{
				leftCorner = Point(0, y4);
			}
		}

		nCount = 0;
		for (int i = ImageCenter.x; i < dstpic.cols - 4; i++)
		{
			int y0 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 0)));
			int y1 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 1)));
			int y2 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 2)));
			int y3 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 3)));
			int y4 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 4)));
			int y5 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 1)));
			int y6 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 2)));
			int y7 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 3)));
			int y8 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 4)));
			if ((int)dstpic.at<uchar>(y8, i + 4) < grayDThreshold && (int)dstpic.at<uchar>(y7, i + 3) < grayDThreshold && (int)dstpic.at<uchar>(y6, i + 2) < grayDThreshold && (int)dstpic.at<uchar>(y5, i + 1) < grayDThreshold)
			{
				//cout << "Success searched the image right border" << endl;
				break;
			}

			double temp, temp0;
			temp = 1.0 * ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)) / ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) + (int)dstpic.at<uchar>(y5, i + 1));

			temp0 = ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) * 1.0 + (int)dstpic.at<uchar>(y5, i + 1)) / 4.0;

			if ((temp > gradient) && (temp > rightTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				rightTemp = temp;
				rightCorner = Point(i, y0);
				nCount++;
			}
			if (nCount == 0)
			{
				rightCorner = Point(dstpic.cols - 1, y8);
			}
		}

		border_Corners.push_back(leftCorner);
		border_Corners.push_back(rightCorner);
		LOGFMTD("FovLeftCorner x: %d, y : %d", leftCorner.x, leftCorner.y);
		LOGFMTD("FovRightCorner x: %d, y : %d", rightCorner.x, rightCorner.y);
	}

	else if (type == Vertical)
	{
		Point2f upPoint;
		Point upCorner;
		Point2f downPoint;
		Point downCorner;

		if ((Corners[0].y + Corners[1].y) - (Corners[2].y + Corners[3].y) <= 0)
		{
			upPoint.x = (Corners[0].x + Corners[1].x) / 2;
			upPoint.y = (Corners[0].y + Corners[1].y) / 2;
			downPoint.x = (Corners[2].x + Corners[3].x) / 2;
			downPoint.y = (Corners[2].y + Corners[3].y) / 2;
		}
		else
		{
			downPoint.x = (Corners[0].x + Corners[1].x) / 2;
			downPoint.y = (Corners[0].y + Corners[1].y) / 2;
			upPoint.x = (Corners[2].x + Corners[3].x) / 2;
			upPoint.y = (Corners[2].y + Corners[3].y) / 2;
		}
		double upTemp = 0.;
		double downTemp = 0.;
		float slop = (ImageCenter.x - upPoint.x) / (ImageCenter.y - upPoint.y);
		nCount = 0;
		for (int i = ImageCenter.y; i > 4; i--)
		{
			int x0 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 0)));
			int x1 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 1)));
			int x2 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 2)));
			int x3 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 3)));
			int x4 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 4)));
			int x5 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 1)));
			int x6 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 2)));
			int x7 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 3)));
			int x8 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 4)));
			if ((int)dstpic.at<uchar>(i - 4, x4) < grayDThreshold && (int)dstpic.at<uchar>(i - 3, x3) < grayDThreshold && (int)dstpic.at<uchar>(i - 2, x2) < grayDThreshold && (int)dstpic.at<uchar>(i - 1, x1) < grayDThreshold)
			{
				//cout << "Success searched the image left border" << endl;
				break;
			}
			double temp = (1.0 * ((int)dstpic.at<uchar>(i + 4, x8) + (int)dstpic.at<uchar>(i + 3, x7) + (int)dstpic.at<uchar>(i + 2, x6) + (int)dstpic.at<uchar>(i + 1, x5)) / ((int)dstpic.at<uchar>(i - 4, x4) + (int)dstpic.at<uchar>(i - 3, x3) + (int)dstpic.at<uchar>(i - 2, x2) + (int)dstpic.at<uchar>(i - 1, x1)));
			double temp0 = ((int)dstpic.at<uchar>(i - 4, x4) + (int)dstpic.at<uchar>(i - 3, x3) + (int)dstpic.at<uchar>(i - 2, x2) + (int)dstpic.at<uchar>(i - 1, x1)) / 4.0;
			if ((temp > gradient) && (temp > upTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				upTemp = temp;
				upCorner = Point(x0, i);
				nCount++;
			}
			if (nCount == 0)
			{
				upCorner = Point(x4, 0);
			}
		}

		nCount = 0;
		for (int i = ImageCenter.y; i < dstpic.rows - 4; i++)
		{
			int x0 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 0)));
			int x1 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 1)));
			int x2 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 2)));
			int x3 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 3)));
			int x4 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 4)));
			int x5 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 1)));
			int x6 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 2)));
			int x7 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 3)));
			int x8 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 4)));
			if ((int)dstpic.at<uchar>(i + 4, x8) < grayDThreshold && (int)dstpic.at<uchar>(i + 3, x7) < grayDThreshold && (int)dstpic.at<uchar>(i + 2, x6) < grayDThreshold && (int)dstpic.at<uchar>(i + 1, x5) < grayDThreshold)
			{
				//cout << "Success searched the image right border" << endl;
				break;
			}

			double temp, temp0;
			temp = 1.0 * ((int)dstpic.at<uchar>(i - 4, x4) + (int)dstpic.at<uchar>(i - 3, x3) + (int)dstpic.at<uchar>(i - 2, x2) + (int)dstpic.at<uchar>(i - 1, x1)) / ((int)dstpic.at<uchar>(i + 4, x8) + (int)dstpic.at<uchar>(i + 3, x7) + (int)dstpic.at<uchar>(i + 2, x6) + (int)dstpic.at<uchar>(i + 1, x5));

			temp0 = ((int)dstpic.at<uchar>(i + 4, x8) + (int)dstpic.at<uchar>(i + 3, x7) + (int)dstpic.at<uchar>(i + 2, x6) + (int)dstpic.at<uchar>(i + 1, x5)) / 4.0;

			if ((temp > gradient) && (temp > downTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				downTemp = temp;
				downCorner = Point(x0, i);
				nCount++;
			}
			if (nCount == 0)
			{
				downCorner = Point(x8, dstpic.rows - 1);
			}
		}

		border_Corners.push_back(upCorner);
		border_Corners.push_back(downCorner);
		LOGFMTD("FovUpCorner x: %d, y : %d", upCorner.x, upCorner.y);
		LOGFMTD("FovDownCorner x: %d, y : %d", downCorner.x, downCorner.y);
	}

	else
	{
		Point2f leftPoint;
		Point leftCorner;
		Point2f rightPoint;
		Point rightCorner;

		////��������������Ӧ�÷�������۵ģ�������������Ӧ�ò�����б�߶����������
		if (Corners[1].x - Corners[3].x <= 0)
		{
			leftPoint.x = Corners[1].x;
			leftPoint.y = Corners[1].y;
			rightPoint.x = Corners[3].x;
			rightPoint.y = Corners[3].y;
		}
		else
		{
			rightPoint.x = Corners[1].x;
			rightPoint.y = Corners[1].y;
			leftPoint.x = Corners[3].x;
			leftPoint.y = Corners[3].y;
		}
		double leftTemp = 0.;
		double rightTemp = 0.;
		float slop = (ImageCenter.y - leftPoint.y) / (ImageCenter.x - leftPoint.x);
		nCount = 0;
		for (int i = ImageCenter.x; i > 4; i--)
		{
			int y0 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 0)));
			int y1 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 1)));
			int y2 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 2)));
			int y3 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 3)));
			int y4 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 4)));
			int y5 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 1)));
			int y6 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 2)));
			int y7 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 3)));
			int y8 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 4)));
			if ((int)dstpic.at<uchar>(y4, i - 4) < grayDThreshold && (int)dstpic.at<uchar>(y3, i - 3) < grayDThreshold && (int)dstpic.at<uchar>(y2, i - 2) < grayDThreshold && (int)dstpic.at<uchar>(y1, i - 1) < grayDThreshold)
			{
				//cout << "Success searched the image left border" << endl;
				break;
			}
			double temp = (1.0 * ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) + (int)dstpic.at<uchar>(y5, i + 1)) / ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)));
			double temp0 = ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)) / 4.0;
			if ((temp > gradient) && (temp > leftTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				leftTemp = temp;
				leftCorner = Point(i, y0);
				nCount++;
			}
			if (nCount == 0)
			{
				leftCorner = Point(0, y4);
			}
		}
		nCount = 0;
		for (int i = ImageCenter.x; i < dstpic.cols - 4; i++)
		{
			int y0 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 0)));
			int y1 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 1)));
			int y2 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 2)));
			int y3 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 3)));
			int y4 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 4)));
			int y5 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 1)));
			int y6 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 2)));
			int y7 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 3)));
			int y8 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 4)));
			if ((int)dstpic.at<uchar>(y8, i + 4) < grayDThreshold && (int)dstpic.at<uchar>(y7, i + 3) < grayDThreshold && (int)dstpic.at<uchar>(y6, i + 2) < grayDThreshold && (int)dstpic.at<uchar>(y5, i + 1) < grayDThreshold)
			{
				//cout << "Success searched the image right border" << endl;
				break;
			}

			double temp, temp0;
			temp = 1.0 * ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)) / ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) + (int)dstpic.at<uchar>(y5, i + 1));

			temp0 = ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) * 1.0 + (int)dstpic.at<uchar>(y5, i + 1)) / 4.0;

			if ((temp > gradient) && (temp > rightTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				rightTemp = temp;
				rightCorner = Point(i, y0);
				nCount++;
			}
			if (nCount == 0)
			{
				rightCorner = Point(dstpic.cols - 1, y8);
			}
		}

		border_Corners.push_back(leftCorner);
		border_Corners.push_back(rightCorner);
		LOGFMTD("FovLean1Corner x: %d, y : %d", leftCorner.x, leftCorner.y);
		LOGFMTD("FovLean2Corner x: %d, y : %d", rightCorner.x, rightCorner.y);

	}
	dstpic.release();
	return CV_ERR_SUCCESS;
}

BOOL OpencvManager::RoughBoundaryCircleDetection(Mat srcpic, Point2f center, Point2f Point, vector<Point2f>& border_Corners, double gradient, double DarkRatio)
{
	if (center == Point)
	{
		LOGE("FOVʧ�ܣ��Խ���FOV�����������ͬ");
	}
	Mat dstpic = srcpic.clone();
	border_Corners.clear();
	Point2i ImageCenter;
	ImageCenter.x = (int)(center.x);
	ImageCenter.y = (int)(center.y);

	double grayThreshold = 0.0;
	int temp = 0;
	const int centreRect = 5;//��ȡ��������Ҷȵ�ȡ����С
	if (ImageCenter.x - centreRect<0 || ImageCenter.x + centreRect> dstpic.rows || ImageCenter.y - centreRect<0 || ImageCenter.y + centreRect> dstpic.rows)
	{
		return CV_ERR_ALG_IMG_SIZE;
	}
	for (int i = -centreRect; i < centreRect; i++)
	{
		for (int j = -centreRect; j < centreRect; j++)
		{
			temp = (int)dstpic.at<uchar>(ImageCenter.y + i, ImageCenter.x + j);
			grayThreshold = grayThreshold + temp;
		}
	}
	grayThreshold = grayThreshold / 100.0;
	double grayLThreshold = grayThreshold * 0.4;
	double grayDThreshold = grayThreshold * DarkRatio;

	if (abs(Point.y - center.y) / abs(Point.x - center.x) <= (srcpic.rows / srcpic.cols))
	{
		int nCount = 0;
		Point2f leftPoint;
		Point2i leftCorner;
		Point2f rightPoint;
		Point2i rightCorner;
		float slop = (Point.y - center.y) / (Point.x - center.x);
		double leftTemp = 0.;
		double rightTemp = 0.;
		nCount = 0;
		for (int i = ImageCenter.x; i > 4; i--)
		{
			int y0 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 0)));
			int y1 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 1)));
			int y2 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 2)));
			int y3 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 3)));
			int y4 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 4)));
			int y5 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 1)));
			int y6 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 2)));
			int y7 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 3)));
			int y8 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 4)));
			if ((int)dstpic.at<uchar>(y4, i - 4) < grayDThreshold && (int)dstpic.at<uchar>(y3, i - 3) < grayDThreshold && (int)dstpic.at<uchar>(y2, i - 2) < grayDThreshold && (int)dstpic.at<uchar>(y1, i - 1) < grayDThreshold)
			{
				//cout << "Success searched the image left border" << endl;
				break;
			}
			double temp = (1.0 * ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) + (int)dstpic.at<uchar>(y5, i + 1)) / ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)));
			double temp0 = ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)) / 4.0;
			if ((temp > gradient) && (temp > leftTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				leftTemp = temp;
				leftCorner = Point2i(i, y0);
				nCount++;
			}
			if (nCount == 0)
			{
				leftCorner = Point2i(0, y4);
			}
		}
		nCount = 0;
		for (int i = ImageCenter.x; i < dstpic.cols - 4; i++)
		{
			int y0 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 0)));
			int y1 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 1)));
			int y2 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 2)));
			int y3 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 3)));
			int y4 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i - 4)));
			int y5 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 1)));
			int y6 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 2)));
			int y7 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 3)));
			int y8 = (int)(ImageCenter.y - slop * (ImageCenter.x - (i + 4)));
			if ((int)dstpic.at<uchar>(y8, i + 4) < grayDThreshold && (int)dstpic.at<uchar>(y7, i + 3) < grayDThreshold && (int)dstpic.at<uchar>(y6, i + 2) < grayDThreshold && (int)dstpic.at<uchar>(y5, i + 1) < grayDThreshold)
			{
				//cout << "Success searched the image right border" << endl;
				break;
			}

			double temp, temp0;
			temp = 1.0 * ((int)dstpic.at<uchar>(y4, i - 4) + (int)dstpic.at<uchar>(y3, i - 3) + (int)dstpic.at<uchar>(y2, i - 2) + (int)dstpic.at<uchar>(y1, i - 1)) / ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) + (int)dstpic.at<uchar>(y5, i + 1));

			temp0 = ((int)dstpic.at<uchar>(y8, i + 4) + (int)dstpic.at<uchar>(y7, i + 3) + (int)dstpic.at<uchar>(y6, i + 2) * 1.0 + (int)dstpic.at<uchar>(y5, i + 1)) / 4.0;

			if ((temp > gradient) && (temp > rightTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				rightTemp = temp;
				rightCorner = Point2i(i, y0);
				nCount++;
			}
			if (nCount == 0)
			{
				rightCorner = Point2i(dstpic.cols - 1, y8);
			}
		}
		border_Corners.push_back(leftCorner);
		border_Corners.push_back(rightCorner);
		LOGFMTD("FovLean1Corner x: %d, y : %d", leftCorner.x, leftCorner.y);
		LOGFMTD("FovLean2Corner x: %d, y : %d", rightCorner.x, rightCorner.y);
	}

	else
	{
		int nCount = 0;
		Point2f upPoint;
		Point2i upCorner;
		Point2f downPoint;
		Point2i downCorner;
		float slop = (Point.x - center.x) / (Point.y - center.y);
		double leftTemp = 0.;
		double rightTemp = 0.;
		nCount = 0;
		for (int i = ImageCenter.y; i > 4; i--)
		{
			int x0 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 0)));
			int x1 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 1)));
			int x2 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 2)));
			int x3 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 3)));
			int x4 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 4)));
			int x5 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 1)));
			int x6 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 2)));
			int x7 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 3)));
			int x8 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 4)));
			if ((int)dstpic.at<uchar>(i - 4, x4) < grayDThreshold && (int)dstpic.at<uchar>(i - 3, x3) < grayDThreshold && (int)dstpic.at<uchar>(i - 2, x2) < grayDThreshold && (int)dstpic.at<uchar>(i - 1, x1) < grayDThreshold)
			{
				//cout << "Success searched the image left border" << endl;
				break;
			}
			double temp = (1.0 * ((int)dstpic.at<uchar>(i + 4, x8) + (int)dstpic.at<uchar>(i + 3, x7) + (int)dstpic.at<uchar>(i + 2, x6) + (int)dstpic.at<uchar>(i + 1, x5)) / ((int)dstpic.at<uchar>(i - 4, x4) + (int)dstpic.at<uchar>(i - 3, x3) + (int)dstpic.at<uchar>(i - 2, x2) + (int)dstpic.at<uchar>(i - 1, x1)));
			double temp0 = ((int)dstpic.at<uchar>(i - 4, x4) + (int)dstpic.at<uchar>(i - 3, x3) + (int)dstpic.at<uchar>(i - 2, x2) + (int)dstpic.at<uchar>(i - 1, x1)) / 4.0;
			if ((temp > gradient) && (temp > leftTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				leftTemp = temp;
				upCorner = Point2i(x0, i);
				nCount++;
			}
			if (nCount == 0)
			{
				upCorner = Point2i(x4, 0);
			}
		}
		nCount = 0;
		for (int i = ImageCenter.y; i < dstpic.rows - 4; i++)
		{
			int x0 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 0)));
			int x1 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 1)));
			int x2 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 2)));
			int x3 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 3)));
			int x4 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i - 4)));
			int x5 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 1)));
			int x6 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 2)));
			int x7 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 3)));
			int x8 = (int)(ImageCenter.x - slop * (ImageCenter.y - (i + 4)));
			if ((int)dstpic.at<uchar>(i + 4, x8) < grayDThreshold && (int)dstpic.at<uchar>(i + 3, x7) < grayDThreshold && (int)dstpic.at<uchar>(i + 2, x6) < grayDThreshold && (int)dstpic.at<uchar>(i + 1, x5) < grayDThreshold)
			{
				//cout << "Success searched the image right border" << endl;
				break;
			}

			double temp, temp0;
			temp = 1.0 * ((int)dstpic.at<uchar>(i - 4, x4) + (int)dstpic.at<uchar>(i - 3, x3) + (int)dstpic.at<uchar>(i - 2, x2) + (int)dstpic.at<uchar>(i - 1, x1)) / ((int)dstpic.at<uchar>(i + 4, x8) + (int)dstpic.at<uchar>(i + 3, x7) + (int)dstpic.at<uchar>(i + 2, x6) + (int)dstpic.at<uchar>(i + 1, x5));

			temp0 = ((int)dstpic.at<uchar>(i + 4, x8) + (int)dstpic.at<uchar>(i + 3, x7) + (int)dstpic.at<uchar>(i + 2, x6) * 1.0 + (int)dstpic.at<uchar>(i + 1, x5)) / 4.0;

			if ((temp > gradient) && (temp > rightTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				rightTemp = temp;
				downCorner = Point2i(x0, i);
				nCount++;
			}
			if (nCount == 0)
			{
				downCorner = Point2i(x8, dstpic.rows - 1);
			}
		}
		border_Corners.push_back(upCorner);
		border_Corners.push_back(downCorner);
		LOGFMTD("FovLean1Corner x: %d, y : %d", upCorner.x, upCorner.y);
		LOGFMTD("FovLean2Corner x: %d, y : %d", downCorner.x, downCorner.y);
	}
	dstpic.release();
	return CV_ERR_SUCCESS;
}

void OpencvManager::RoughBoundaryPointsDetection(Mat srcpic, Point ImageCenter, vector<Point2f>& border_Corners, double gradient, double DarkRatio, FovType type)
{
	Mat dstpic = srcpic.clone();

	border_Corners.clear();
	double grayThreshold = 0.0;
	int temp = 0;
	const int centreRect = 5;//��ȡ��������Ҷȵ�ȡ����С
	for (int i = -centreRect; i < centreRect; i++)
	{
		for (int j = -centreRect; j < centreRect; j++)
		{
			temp = (int)dstpic.at<uchar>(ImageCenter.y + i, ImageCenter.x + j);
			grayThreshold = grayThreshold + temp;
		}
	}
	grayThreshold = grayThreshold / 100.0;
	double grayLThreshold = grayThreshold * 0.4;
	double grayDThreshold = grayThreshold * DarkRatio;
	int nCount = 0;
	if (type == Horizontal)
	{
		Point2f leftPoint;
		Point2f rightPoint;
		double rightTemp = 0.0;

		for (int i = ImageCenter.x; i < dstpic.cols - 4; i++)
		{
			if (((int)dstpic.at<uchar>(ImageCenter.y, i + 3) + (int)dstpic.at<uchar>(ImageCenter.y, i + 2) + (int)dstpic.at<uchar>(ImageCenter.y, i + 1)) == 0)
			{
				//cout << "Success searched the image right border" << endl;
				break;
			}

			double temp, temp0;
			temp = ((int)dstpic.at<uchar>(ImageCenter.y, i - 4) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i - 3) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i - 2) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i - 1) * 1.0) / ((int)dstpic.at<uchar>(ImageCenter.y, i + 4) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 3) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 2) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 1) * 1.0);

			temp0 = ((int)dstpic.at<uchar>(ImageCenter.y, i + 4) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 3) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 2) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 1) * 1.0) / 4.0;

			if ((temp > gradient) && (temp > rightTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				rightTemp = temp;
				rightPoint = Point(i, ImageCenter.y);
				nCount++;
			}
		}
		if (nCount == 0)
		{
			rightPoint = Point(dstpic.cols - 1, ImageCenter.y);
		}
		double leftTemp = 0.0;
		nCount = 0;
		for (int i = ImageCenter.x; i > 4; i--)
		{
			if (((int)dstpic.at<uchar>(ImageCenter.y, i - 3) + (int)dstpic.at<uchar>(ImageCenter.y, i - 2) + (int)dstpic.at<uchar>(ImageCenter.y, i - 1)) == 0)
			{
				//cout << "Success searched the image left border" << endl;
				break;
			}
			double temp = (((int)dstpic.at<uchar>(ImageCenter.y, i + 4) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 3) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 2) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i + 1) * 1.0) / ((int)dstpic.at<uchar>(ImageCenter.y, i - 4) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i - 3) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i - 2) * 1.0 + (int)dstpic.at<uchar>(ImageCenter.y, i - 1) * 1.0));
			double temp0 = ((int)dstpic.at<uchar>(ImageCenter.y, i - 4) + (int)dstpic.at<uchar>(ImageCenter.y, i - 3) + (int)dstpic.at<uchar>(ImageCenter.y, i - 2) + (int)dstpic.at<uchar>(ImageCenter.y, i - 1)) / 4.0;

			if (temp > gradient && temp > leftTemp && temp0 <= grayLThreshold && temp0 >= grayDThreshold)
			{
				leftTemp = temp;
				leftPoint = Point(i, ImageCenter.y);
				nCount++;
			}
		}
		if (nCount == 0)
		{
			leftPoint = Point(0, ImageCenter.y);
		}
		border_Corners.push_back(leftPoint);
		border_Corners.push_back(rightPoint);
		LOGFMTD("FovLeftPoint x: %f, y : %f", leftPoint.x, leftPoint.y);
		LOGFMTD("FovRightPoint x: %f, y : %f", rightPoint.x, rightPoint.y);
	}
	if (type == Vertical)
	{
		Point2f upPoint;
		Point2f downPoint;
		double downTemp = 0.0;
		nCount = 0;
		for (int i = ImageCenter.y; i < dstpic.rows - 4; i++)
		{
			if (((int)dstpic.at<uchar>(i + 3, ImageCenter.x) + (int)dstpic.at<uchar>(i + 2, ImageCenter.x) + (int)dstpic.at<uchar>(i + 1, ImageCenter.x)) == 0)
			{
				//cout << "Success searched the image down border" << endl;
				break;
			}

			double temp, temp0;
			temp = ((int)dstpic.at<uchar>(i - 4, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i - 3, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i - 2, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i - 1, ImageCenter.x) * 1.0) / ((int)dstpic.at<uchar>(i + 4, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 3, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 2, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 1, ImageCenter.x) * 1.0);

			temp0 = ((int)dstpic.at<uchar>(i + 4, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 3, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 2, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 1, ImageCenter.x) * 1.0) / 4.0;
			if (temp0 < grayLThreshold)
			{
				nCount++;
			}
			if ((temp > gradient) && (temp > downTemp) && (temp0 < grayLThreshold) && (temp0 > grayDThreshold))
			{
				downTemp = temp;
				downPoint = Point(ImageCenter.x, i);
			}
		}
		if (nCount == 0)
		{
			downPoint = Point(ImageCenter.x, dstpic.rows - 1);
		}

		nCount = 0;
		double upTemp = 0.0;
		for (int i = ImageCenter.y; i > 4; i--)
		{
			if (((int)dstpic.at<uchar>(i - 3, ImageCenter.x) + (int)dstpic.at<uchar>(i - 2, ImageCenter.x) + (int)dstpic.at<uchar>(i - 1, ImageCenter.x)) == 0)
			{
				//cout << "Success searched the image up border" << endl;
				break;
			}
			double temp = (((int)dstpic.at<uchar>(i + 4, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 3, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 2, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i + 1, ImageCenter.x) * 1.0) / ((int)dstpic.at<uchar>(i - 4, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i - 3, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i - 2, ImageCenter.x) * 1.0 + (int)dstpic.at<uchar>(i - 1, ImageCenter.x) * 1.0));
			double temp0 = ((int)dstpic.at<uchar>(i - 4, ImageCenter.x) + (int)dstpic.at<uchar>(i - 3, ImageCenter.x) + (int)dstpic.at<uchar>(i - 2, ImageCenter.x) + (int)dstpic.at<uchar>(i - 1, ImageCenter.x)) / 4.0;

			if (temp > gradient && temp > upTemp && temp0 <= grayLThreshold && temp0 >= grayDThreshold)
			{
				upTemp = temp;
				upPoint = Point(ImageCenter.x, i);
				nCount++;
			}
		}
		if (nCount == 0)
		{
			upPoint = Point(ImageCenter.x, 0);
		}
		border_Corners.push_back(upPoint);
		border_Corners.push_back(downPoint);

		LOGFMTD("FovUpPoint x: %f, y : %f", upPoint.x, upPoint.y);
		LOGFMTD("FovDownPoint x: %f, y : %f", downPoint.x, downPoint.y);
	}
	dstpic.release();
}



void OpencvManager::calFOV(vector<Point2f> border_Corners, double dFovDist, double cameraDegrees, double& fovDegrees)
{
	double dist0 = sqrt((border_Corners[1].y - border_Corners[0].y) * (border_Corners[1].y - border_Corners[0].y) + (border_Corners[1].x - border_Corners[0].x) * (border_Corners[1].x - border_Corners[0].x));
	double dist1 = dFovDist;
	double ratio = dist0 / dist1;
	fovDegrees = 2 * atan(tan(cameraDegrees * CV_PI / (2 * 180)) * ratio) * 57.3;
}

BOOL OpencvManager::TranspositionROI(Mat img, Mat& image)
{
	if (img.rows < 45 || img.cols < 45)
	{
		return CV_ERR_ALG_IMG_SIZE;
	}
	Mat imageGray;
	if (img.channels() != 1)
	{
		cvtColor(img, imageGray, COLOR_BGR2GRAY);
	}
	else
	{
		imageGray = img.clone();
	}

	if (imageGray.depth() != CV_8U)
	{
		imageGray.convertTo(imageGray, CV_8UC1, 1.0 / 256, 0);
	}
	int otsuNum = OtsuAlgThreshold(imageGray);
	Mat dst;
	threshold(imageGray, dst, otsuNum, 255, THRESH_BINARY);
	int k = 0;
	while (k < 4)
	{
		int srcRows = dst.rows;
		int srcCols = dst.cols;
		int r1 = 0;
		int r2 = 0;
		int r3 = 0;
		int r4 = 0;
		int r5 = 0;
		int r6 = 0;
		int r7 = 0;
		int r8 = 0;
		int r9 = 0;
		int r10 = 0;
		for (int i = 0; i < dst.rows; i++)
		{
			if (((int)(dst.at<uchar>(i, 0))) == 0)
			{
				r1++;
			}
			if (((int)(dst.at<uchar>(i, 1))) == 0)
			{
				r2++;
			}
			if (((int)(dst.at<uchar>(i, 2))) == 0)
			{
				r3++;
			}
			if (((int)(dst.at<uchar>(i, 3))) == 0)
			{
				r4++;
			}
			if (((int)(dst.at<uchar>(i, 4))) == 0)
			{
				r5++;
			}
			if (((int)(dst.at<uchar>(i, dst.cols - 1))) == 255)
			{
				r6++;
			}
			if (((int)(dst.at<uchar>(i, dst.cols - 2))) == 255)
			{
				r7++;
			}
			if (((int)(dst.at<uchar>(i, dst.cols - 3))) == 255)
			{
				r8++;
			}
			if (((int)(dst.at<uchar>(i, dst.cols - 4))) == 255)
			{
				r9++;
			}
			if (((int)(dst.at<uchar>(i, dst.cols - 5))) == 255)
			{
				r10++;
			}
		}
		double value1 = r1 * 1.0 / dst.rows;
		double value2 = r2 * 1.0 / dst.rows;
		double value3 = r3 * 1.0 / dst.rows;
		double value4 = r4 * 1.0 / dst.rows;
		double value5 = r5 * 1.0 / dst.rows;
		double value6 = r6 * 1.0 / dst.rows;
		double value7 = r7 * 1.0 / dst.rows;
		double value8 = r8 * 1.0 / dst.rows;
		double value9 = r9 * 1.0 / dst.rows;
		double value10 = r10 * 1.0 / dst.rows;
		if (value1 >= 0.98 && value2 >= 0.98 && value3 >= 0.98 && value4 >= 0.98 && value5 >= 0.98 && value6 >= 0.98 && value7 >= 0.98 && value8 >= 0.98 && value9 >= 0.98 && value10 >= 0.98)
		{
			break;
		}
		else
		{
			transpose(dst, dst);
			flip(dst, dst, 1);
			k++;
		}
	}
	//cout << " k = " << k << endl;
	switch (k)
	{
	case 0:
		image = imageGray.clone();
		break;
	case 1:
		transpose(imageGray, image);
		flip(image, image, 1);
		break;
	case 2:
		flip(imageGray, image, -1);
		break;
	case 3:
		transpose(imageGray, image);
		flip(image, image, 0);
		break;
	default:
		LOGE("unavailable roi input.");
		//cout << "unavailable roi input " << endl;
		return CV_ERR_ALG_WRONG_ROI;
		break;
	}
	return CV_ERR_SUCCESS;
}

int OpencvManager::OtsuAlgThreshold(const Mat image)
{
	if (image.channels() != 1)
	{
		LOGE("������Ҷ�ͼ");
		return CV_ERR_ALG_IMG_TYPE;
	}
	int T = 0; //Otsu�㷨��ֵ
	double varValue = 0; //��䷽���м�ֵ����
	double w0 = 0; //ǰ�����ص�����ռ����
	double w1 = 0; //�������ص�����ռ����
	double u0 = 0; //ǰ��ƽ���Ҷ�
	double u1 = 0; //����ƽ���Ҷ�
	double Histogram[256] = { 0 }; //�Ҷ�ֱ��ͼ���±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ�����ص�����
	uchar* data = image.data;
	double totalNum = image.rows * image.cols; //��������
	//����Ҷ�ֱ��ͼ�ֲ���Histogram�����±��ǻҶ�ֵ�����������ǻҶ�ֵ��Ӧ���ص���
	for (int i = 0; i < image.rows; i++)   //Ϊ������������û�а�rows��cols���������
	{
		for (int j = 0; j < image.cols; j++)
		{
			Histogram[data[i * image.step + j]]++;
		}
	}
	for (int i = 0; i < 255; i++)
	{
		//ÿ�α���֮ǰ��ʼ��������
		w1 = 0;		u1 = 0;		w0 = 0;		u0 = 0;
		//***********����������ֵ����**************************
		for (int j = 0; j <= i; j++) //�������ָ�ֵ����
		{
			w1 += Histogram[j];  //�����������ص�����
			u1 += j * Histogram[j]; //�������������ܻҶȺ�
		}
		if (w1 == 0) //�����������ص���Ϊ0ʱ�˳�
		{
			continue;
		}
		u1 = u1 / w1; //��������ƽ���Ҷ�
		w1 = w1 / totalNum; // �����������ص�����ռ����
		//***********����������ֵ����**************************

		//***********ǰ��������ֵ����**************************
		for (int k = i + 1; k < 255; k++)
		{
			w0 += Histogram[k];  //ǰ���������ص�����
			u0 += k * Histogram[k]; //ǰ�����������ܻҶȺ�
		}
		if (w0 == 0) //ǰ���������ص���Ϊ0ʱ�˳�
		{
			break;
		}
		u0 = u0 / w0; //ǰ������ƽ���Ҷ�
		w0 = w0 / totalNum; // ǰ���������ص�����ռ����
		//***********ǰ��������ֵ����**************************

		//***********��䷽�����******************************
		double varValueI = w0 * w1 * (u1 - u0) * (u1 - u0); //��ǰ��䷽�����
		if (varValue < varValueI)
		{
			varValue = varValueI;
			T = i;
		}
	}
	return T;
}

void OpencvManager::de_Gamma(cv::Mat& Src, double gamma)
{
	if (Src.channels() != 1)
	{
		LOGE("ROI is wrong!");
		//cout << "ROI is wrong!" << endl;
		return;
	}
	//imshow("test1", Src);
	//waitKey(0);
	//destroyAllWindows();

	Mat gammaimage1 = Src.clone();
	Mat src, src1, gamma_image;
	gamma_image.create(gammaimage1.size(), CV_64F);
	gammaimage1.convertTo(src, CV_64F, 1.0 / 255, 0);
	gamma_image.create(src.size(), CV_64F);
	for (int i = 0; i < Src.rows; i++)
	{
		for (int j = 0; j < Src.cols; j++)
		{
			gamma_image.at<double>(i, j) = pow(src.at<double>(i, j), gamma);
			//cout << "gamma_image.at<double>(i, j)" << gamma_image.at<double>(i, j) << endl;
		}
	}
	gamma_image.convertTo(Src, CV_8UC1, 255, 0);
	//imshow("test2", Src);
	//waitKey(0);
	//destroyAllWindows();

	LOGD("Gamma worked.");
}

void OpencvManager::SLR(std::vector<double>& Cen_Shifts, std::vector<double>& y_shifts, double& a, double& b)
{
	//a -> intercept, b->slope of slanted edge

	int y_size = y_shifts.size();
	//using simple linear regression to solve equation and get slope and intercept
	double xsquare = 0, xavg = 0, yavg = 0;
	int i;
	for (i = 0; i < y_size; ++i)
	{
		yavg += y_shifts[i];
		xavg += Cen_Shifts[i];
		//xavg += y_shifts[i];
		//yavg += Cen_Shifts[i];
	}
	xavg /= (double)y_size;
	yavg /= (double)y_size;
	//cout << "xavg : " << xavg << " yavg : " << yavg << endl;

	//simple linear regession
	for (i = 0; i < y_size; ++i)
	{
		double temp = (Cen_Shifts[i] - xavg);
		b += temp * (y_shifts[i] - yavg);
		xsquare += temp * temp;
		//double temp = (y_shifts[i] - xavg);
		//b += temp * (Cen_Shifts[i] - yavg);
		//xsquare += temp * temp;
	}

	//cout << "xavg : " << xavg << " yavg : " << yavg << endl;
	b /= xsquare;
	a = yavg - b * xavg;
	//cout << "b = " << b << endl;
	//cout << "a = " << a << endl;
	//cout << "SLR worked" << endl;
	LOGD("Gamma worked.");
}

vector<double> OpencvManager::CentroidFind(Mat& Src, vector<double>& y_shifts, double& CCoffset)
{
	//ofstream fout("C:\\Users\\ColorVision\\Desktop\\SFR\\test.txt");
	std::vector<double> Cen_Shifts(Src.rows);
	int height = Src.rows;
	int width = Src.cols;
	//cout << "height = " << height << "width = " << width << endl;
	//cout << "Src.type : " << Src.type() << endl;

	//tempSrc = Src.clone();
	//There maybe somemistake below.
	Mat tempSrc(Src.size(), CV_8UC1);
	//cout << "tempSrc.size : " << tempSrc.size() << endl;
	LOGFMTI("tempSrc.size() : %d", tempSrc.size());

	//Do the bilaterFilter on template ROI image to make sure we can find the slanted edge more acurrate
	cv::bilateralFilter(Src, tempSrc, 3, 200, 200);

	//calculate the centroid of every row in ROI
	//centroid formuld: Total moments/Total amount
	//should provide the range of centroid between 1/5 and 5times

   //int k1 = 0;
   //int k2 = 0;
	for (int i = 0; i < height; ++i)
	{
		uchar* tempSrcPtr = tempSrc.ptr<uchar>(i);
		if (((double)tempSrcPtr[width - 1] / (double)tempSrcPtr[0]) >= 0.2 && ((double)tempSrcPtr[width - 1] / (double)tempSrcPtr[0]) <= 5)
		{
			//cout << "tempSrcPtr[width] = " << (double)tempSrcPtr[width - 1] << endl;
			//cout << "tempSrcPtr[0] = " << (double)tempSrcPtr[0] << endl;
			continue;
		}
		else
		{
			//k1 = i;
			break;
		}
	}
	for (int i = height - 1; i > 0; i--)
	{
		uchar* tempSrcPtr = tempSrc.ptr<uchar>(i);
		if (((double)tempSrcPtr[width - 1] / (double)tempSrcPtr[0]) >= 0.2 && ((double)tempSrcPtr[width - 1] / (double)tempSrcPtr[0]) <= 5)
		{
			continue;
		}
		else
		{
			//k2 = i;
			break;
		}
	}
	for (int i = 0; i < height; ++i)
	{
		double molecule = 0, denominator = 0, temp = 0;
		uchar* tempSrcPtr = tempSrc.ptr<uchar>(i);
		for (int j = 0; j < width - 1; ++j)
		{
			temp = (double)tempSrcPtr[j + 1] - (double)tempSrcPtr[j];
			molecule += temp * j;
			denominator += temp;
		}
		Cen_Shifts[i] = molecule / denominator;
		//fout << "molecule = " << molecule << "," << "denominator = " << denominator << "," << "Cen_Shifts[i] = " << Cen_Shifts[i] << endl;
	}
	for (int i = 0; i < height; ++i)
		//for (int i = k1; i < k2; ++i)
	{
		double y = i;
		int x = Cen_Shifts[i];
		Point p1 = Point(x, y);
		circle(tempSrc, p1, 2, Scalar(0, 255, 0), -1, 8, 0);
	}

	//Eliminate the noise far from slant edge(+/- 10 pixels)
	tempSrc = Src.clone();
	//imshow("test3", tempSrc);
	//waitKey(0);
	//destroyAllWindows();
	cv::GaussianBlur(Src, Src, cv::Size(3, 3), 0);
	for (int i = 0; i < height; ++i)
		//for (int i = k1; i < k2; ++i)
	{
		uchar* SrcPtr = Src.ptr<uchar>(i);
		uchar* tempPtr = tempSrc.ptr<uchar>(i);
		for (int j = int(Cen_Shifts[i]) - 10; j < int(Cen_Shifts[i]) + 10; ++j)
		{
			SrcPtr[j] = tempPtr[j];
		}
	}


	int half_ySize = height / 2;
	//int half_ySize = (k2+k1) / 2;
	int CC = Cen_Shifts[half_ySize]; //Centroid of image center
	CCoffset = CC;
	for (int i = 0; i < height; ++i)
	{
		Cen_Shifts[i] -= CC; //Calculate the Shifts between Centroids and Centroid of image center
		y_shifts[i] = i - half_ySize; //Calculate the shifts between height of image center and each row
	}
	LOGD("CentroidFind worked.");
	// cout << "CentroidFind worked" << endl;
	return Cen_Shifts;
}


std::vector<double> OpencvManager::OverSampling(Mat& Src, double slope, double CCoffset, int height, int width, int& SamplingLen)
{

	std::vector<double> RowShifts(height, 0);

	int i, j, k;
	int halfY = height / 2;

	for (i = 0; i < height; ++i)
	{
		RowShifts[i] = (double)(i - halfY) / slope + CCoffset;
	}

	//DataMap -> to record the index of pixel after shift
	//Datas -> to record the original pixel value
	//calculate the ESF
	std::vector<double> DataMap(height * width, 0);
	std::vector<double> Datas(height * width, 0);

	for (i = 0, k = 0; i < height; ++i)
	{
		int baseindex = width * i;
		for (j = 0; j < width; ++j)
		{
			DataMap[baseindex + j] = j - RowShifts[i];
			Datas[baseindex + j] = int(Src.at<uchar>(i, j));
		}
	}

	std::vector<double> SamplingBar(SamplingLen, 0);
	std::vector<int> MappingCount(SamplingLen, 0);

	//Start to mapping the original data to 4x sampling data and record the count of each pixel in 4x sampling data
	for (i = 0; i < height * width; ++i)
	{
		int MappingIndex = static_cast<int>(4 * DataMap[i]);//seems 4xsampling could involved the mistakes��
		if (MappingIndex >= 0 && MappingIndex < SamplingLen)
		{
			SamplingBar[MappingIndex] = SamplingBar[MappingIndex] + Datas[i];
			MappingCount[MappingIndex]++;
		}
	}

	for (i = 0; i < SamplingLen; ++i) {
		j = 0;
		k = 1;
		if (MappingCount[i] == 0) {

			if (i == 0) {
				while (!j)
				{
					if (MappingCount[i + k] != 0)
					{
						SamplingBar[i] = SamplingBar[i + k] / ((double)MappingCount[i + k]);
						j = 1;
					}
					else ++k;
				}
			}
			else {
				while (!j && ((i - k) >= 0))
				{
					if (MappingCount[i - k] != 0)
					{
						SamplingBar[i] = SamplingBar[i - k];   /* Don't divide by counts since it already happened in previous iteration */
						j = 1;
					}
					else ++k;
				}
				if ((i - k) < 0)
				{
					k = 1;
					while (!j)
					{
						if (MappingCount[i + k] != 0)
						{
							SamplingBar[i] = SamplingBar[i + k] / ((double)MappingCount[i + k]);
							j = 1;
						}
						else ++k;
					}
				}
			}
		}
		else
		{
			SamplingBar[i] = (SamplingBar[i]) / ((double)MappingCount[i]);
		}
	}

	// reduce the length of sampling data 
	// because the datas at the edge are only matters, we truncate the data close to the two side of sampling data
	// which has very small contribution to the result

	//truncating the data smaller than 10% and bigger than 90% of original length--->>do not know what means!Maybe HammingWindows` length in here.
	int originalSamplingLen = SamplingLen;
	//SamplingLen = SamplingLen * 1;
	SamplingLen = SamplingLen * 0.8;

	std::vector<double> deSampling(SamplingLen, 0);

	for (i = originalSamplingLen * 0.1, j = 1; i < originalSamplingLen, j < SamplingLen; ++i, ++j)
	{
		deSampling[j] = SamplingBar[i + 1] - SamplingBar[i];
		//deSampling[i] = SamplingBar[i + 0.5] + SamplingBar[i-0.5] - 2*SamplingBar[i]; // compared with sfrmat3

	}

	return deSampling;
}


std::vector<double> OpencvManager::HammingWindows(std::vector<double>& deSampling, int SamplingLen)
{
	int i, j;
	std::vector<double> tempData(SamplingLen);

	//We want to shift the peak data to the center of line spread function data
	//Because we will do the hamming window later, this will keep the important data away from filtering
	//In case there are two peaks, we use two variable to record the peak data position
	int L_location = -1, R_location = -1;

	double SamplingMax = 0;
	for (i = 0; i < SamplingLen; ++i)
	{
		if (fabs(deSampling[i]) > fabs(SamplingMax))
			SamplingMax = deSampling[i];
	}

	for (i = 0; i < SamplingLen; ++i)
	{
		if (deSampling[i] == SamplingMax)
		{
			if (L_location < 0) { L_location = i; }
			R_location = i;
		}
	}

	//the shift amount 
	int PeakOffset = (R_location + L_location) / 2 - SamplingLen / 2;

	if (PeakOffset)
	{
		for (i = 0; i < SamplingLen; ++i)
		{
			int newIndex = i - PeakOffset;
			if (newIndex >= 0 && newIndex < SamplingLen) { tempData[newIndex] = deSampling[i]; }
		}
	}
	else
	{
		for (i = 0; i < SamplingLen; ++i) { tempData[i] = deSampling[i]; }
	}

	//do the hamming window filtering
	for (int i = 0; i < SamplingLen; ++i)
	{
		tempData[i] = tempData[i] * (0.54 - 0.46 * cos(2 * CV_PI * i / (SamplingLen - 1)));
	}

	return tempData;
}

void OpencvManager::DFT(vector<double>& data, int size)
{
	int i, j;
	std::complex<double>* arr = new std::complex<double>[size];
	for (i = 0; i < size; ++i)
	{
		arr[i] = std::complex<double>(data[i], 0);
	}

	for (i = 0; i < size / 2.0; ++i)
	{
		std::complex<double> temp = 0;
		for (j = 0; j < size; ++j)
		{
			double w = 2 * CV_PI * i * j / size;
			std::complex<double> deg(cos(w), -sin(w));
			temp += arr[j] * deg;
		}
		data[i] = sqrt(temp.real() * temp.real() + temp.imag() * temp.imag());
	}
}

void OpencvManager::ReduceRows(double slope, int& ImgHeight)
{
	double tempSlope = fabs(slope);
	int cycs = (ImgHeight) / tempSlope;
	if (tempSlope * cycs < ImgHeight)
	{
		ImgHeight = tempSlope * cycs;
	}
	LOGD("ReduceRows worked.");
	//cout << "ReduceRows worked" << endl;
}

BOOL OpencvManager::AverageImage(int nWnd, int nHei, int nBpp, int nChannels, std::vector<uint16_t*> vcpData, uint16_t* pdstData)
{
	if (vcpData.size() == 0)
	{
		LOGD("nCount ���ݲ���");
		return CV_ERR_ALG_IMG_SIZE;
	}

	StreamingImageAverage average;
	for (uint16_t* data : vcpData)
	{
		if (!average.Add(nWnd, nHei, nBpp, nChannels, data))
		{
			LOGD("ibpp ���ݲ��ԣ�ͼƬ��ʽ����");
			return CV_ERR_ALG_IMG_TYPE;
		}
	}

	return average.WriteAverage(pdstData) ? CV_ERR_SUCCESS : CV_ERR_ALG_IMG_TYPE;
}

BOOL OpencvManager::CalResolution(Mat img, double dRatio, double& dMoudulation)
{
	if (img.empty())
	{
		return CV_ERR_ALG_IMG_SIZE;
	}
	Mat tempImg = img.clone();
	int top1 = (int)(tempImg.total() * dRatio);
	int bom1 = (int)(tempImg.total() * dRatio);

	const int channels[] = { 0 };	//�����ͨ���ǻҶ�ͨ��
	Mat histogram;
	int dims = 1;	//ֱ��ͼά������Ϊ1
	double minVal = 0, maxVal = 0;
	minMaxIdx(tempImg, &minVal, &maxVal);	//ȡͼ���лҶ����ֵ����Сֵ
	maxVal += 1;
	const int histSize = (maxVal - minVal) + 1;	//ֱ��ͼÿһ��ά�ȷ����������Ŀ
	float range[] = { minVal, maxVal };
	const float* ranges[] = { range };//ֱ��ͼȡֵ�ռ�
	bool uniform = true;	//��ֱ��ͼ����������ݹ�һ��
	bool accumulate = false;	//��ͼ��ʱ�����ۼƼ�������ֵ�ĸ���

	calcHist(&tempImg, 1, channels, cv::Mat(), histogram, dims, &histSize, &ranges[0], uniform, accumulate);

	float* h = (float*)histogram.data;
	int maxIdx = histogram.rows;
	double sum = 0;
	int cnt = 0;
	int ln = 0;
	int valNum = 0;
	int grayVal = 0;
	for (int i = maxIdx - 1; i >= 0; i--)
	{
		grayVal = i + minVal;
		valNum = h[i];
		if (valNum > 0.00000001)
		{
			int reCnt = top1 - cnt;

			if (reCnt >= valNum)
			{
				sum += (double)valNum * (double)grayVal;
				cnt += valNum;
			}
			else
			{

				sum += (double)reCnt * (double)grayVal;
				cnt += reCnt;
			}
			if (top1 <= cnt)
				break;
		}
		else
			continue;
	}
	float Imax = sum / top1;

	sum = 0;
	cnt = 0;
	ln = 0;
	valNum = 0;
	grayVal = 0;
	for (int i = 1; i < maxIdx - 1; i++)
	{
		grayVal = i + minVal - 1;
		valNum = h[i];
		if (valNum > 0.00000001)
		{
			int reCnt = bom1 - cnt;

			if (reCnt >= valNum)
			{
				sum += (double)valNum * (double)grayVal;
				cnt += valNum;
			}
			else
			{

				sum += (double)reCnt * (double)grayVal;
				cnt += reCnt;
			}
			if (bom1 <= cnt)
				break;
		}
		else
			continue;
	}
	float Imin = sum / bom1;
	dMoudulation = (Imax - Imin) / (Imax + Imin);

	return CV_ERR_SUCCESS;
}

BOOL OpencvManager::EdgeFocusIndex(Mat img, int offy, int d, int w, int h, int nStep, int nMaxCount, double& dMoudulation)
{
	if (img.empty())
	{
		return CV_ERR_ALG_IMG_SIZE;
	}

	cv::Mat srcMat64;

	img.convertTo(srcMat64, CV_64F);

	int x1 = 0;
	int x2 = img.cols - w;
	int y1 = img.rows / 2 - offy - d;
	int y2 = img.rows / 2 - offy + d;

	Mat imc1 = Mat(srcMat64(Rect(x1, y1, w, h))) - Mat(srcMat64(Rect(x1 + nStep, y1, w, h)));
	Mat imc2 = Mat(srcMat64(Rect(x1, y2, w, h))) - Mat(srcMat64(Rect(x1 + nStep, y2, w, h)));
	Mat imc3 = Mat(srcMat64(Rect(x2, y1, w, h))) - Mat(srcMat64(Rect(x2 - nStep, y1, w, h)));
	Mat imc4 = Mat(srcMat64(Rect(x2, y2, w, h))) - Mat(srcMat64(Rect(x2 - nStep, y2, w, h)));

	vector<double> limc1(imc1.cols, 0.0);
	vector<double> limc2(imc2.cols, 0.0);
	vector<double> limc3(imc3.cols, 0.0);
	vector<double> limc4(imc4.cols, 0.0);

	for (int i = 0; i < imc1.cols; i++)
	{
		limc1[i] = abs(sum(imc1.col(i))[0]);
		limc2[i] = abs(sum(imc2.col(i))[0]);
		limc3[i] = abs(sum(imc3.col(i))[0]);
		limc4[i] = abs(sum(imc4.col(i))[0]);
	}

	sort(limc1.begin(), limc1.end(), greater<double>());
	sort(limc2.begin(), limc2.end(), greater<double>());
	sort(limc3.begin(), limc3.end(), greater<double>());
	sort(limc4.begin(), limc4.end(), greater<double>());

	dMoudulation = accumulate(limc1.begin(), limc1.begin() + nMaxCount, 0.0) +
		accumulate(limc2.begin(), limc2.begin() + nMaxCount, 0.0) +
		accumulate(limc3.begin(), limc3.begin() + nMaxCount, 0.0) +
		accumulate(limc4.begin(), limc4.begin() + nMaxCount, 0.0);

	return TRUE;
}

Mat Generalized_inverse(Mat& X)
{
	Mat Xt = X.t();

	Mat Xt_X = Xt * X;

	Mat inverse_Xt_X;
	invert(Xt_X, inverse_Xt_X, DECOMP_LU);		//����LU�ֽ�,�������

	return inverse_Xt_X * Xt;
}

vector<vector<float>> opencv_sg(vector<vector<float>>& vdata, int M, int N)
{
	// SGƽ����������	
	Mat move_box(2 * M + 1, N, CV_32F);
	for (int i = -M; i <= M; ++i)
	{
		for (int j = 0; j < N; ++j)
		{
			move_box.at<float>(i + M, j) = pow(i, j);
		}
	}

	Mat gen_inv = Generalized_inverse(move_box);	// ����move_box �Ĺ�����

	vector<vector<float>> test_data_clone = vdata;

	if (vdata[0].size() <= 2 * M + 1)
	{
		//qDebug() << "the length of the input_data is too short!";
	}

	if (2 * M + 1 <= N)
	{
		//qDebug() << "box size is too small!";
	}

	for (int i = M; i < vdata[0].size() - M; ++i)
	{
		Mat y_box_value(2 * M + 1, 1, CV_32F);
		for (int j = -M; j <= M; ++j)
		{
			y_box_value.at<float>(j + M, 0) = vdata[1][i + j];
		}

		Mat ls_sol = gen_inv * y_box_value;					// ��С���˽�
		Mat result = move_box * ls_sol;						// sg�˲�ֵ
		test_data_clone[1][i] = result.at<float>(M, 0);
	}

	return test_data_clone;
}

bool SplineInterpolation(vector<float>& vdX, vector<float>& vdY, double staX, double endX, double step, vector<float>& vsX, vector<float>& vsY)
{
	if (vsX.size() != vsY.size())
		return false;

	Eigen::VectorXd wavelengths(vsX.size());
	Eigen::VectorXd values(vsX.size());

	for (int i = 0; i < vsX.size(); i++)
	{
		wavelengths[i] = vsX[i];
		values[i] = vsY[i];
	}

	Eigen::Spline<double, 1> spline = Eigen::SplineFitting<Eigen::Spline<double, 1>>::Interpolate(values.transpose(), 3, wavelengths);

	for (double x = staX; x <= endX; x += step)
	{
		double y = spline(x)(0);

		vdX.push_back(x);
		vdY.push_back(y);
	}

	return true;
}

void rectCornersPyrdownFaster(Mat img, int n_times, int smooth_size, vector<Point2f>& corners_img)
{
	clock_t begin = clock();
	int pow2n = pow(2, n_times);
	int applied_size = round(smooth_size / pow2n);

	if (applied_size < 3 || applied_size>7) {
		applied_size = 3;
	}

	Mat imghalf = img;

	for (int i = 0; i < n_times; i++)
	{
		pyrDown(imghalf, imghalf);
	}

	goodFeaturesToTrack(imghalf, corners_img, 4, 0.3, 50, noArray(), applied_size);

	for (int i = 0; i < corners_img.size(); i++)
	{
		corners_img[i] = corners_img[i] * pow2n;
	}
}

void getRectCornersOrdered(vector<Point2f> input, vector<Point2f>& rst)
{
	Point2f pt_average;
	pt_average.x = (input[0].x + input[1].x + input[2].x + input[3].x) / 4;
	pt_average.y = (input[0].y + input[1].y + input[2].y + input[3].y) / 4;
	Point2f tmpdelta;
	vector<Point2f> atanrst;
	for (int i = 0; i < 4; i++)
	{
		tmpdelta = input[i] - pt_average;
		if (tmpdelta.x == 0 && tmpdelta.y == 0)
		{
			cout << "ERROR: �нǵ��4��ƽ��ֵ��ȫ�غϣ��޷���˳ʱ�뷽������" << endl;
			return;
		}
		atanrst.push_back(Point2f(i, atan2f(-tmpdelta.y, tmpdelta.x)));  // ������������ϵ���أ�y������Ҫ���ԣ�-1��
	}
	sort(atanrst.begin(), atanrst.end(), [](Point2f& a, Point2f& b) { return a.y > b.y; });
	for (int i = 0; i < 4; i++)
	{
		rst.push_back(input[atanrst[i].x]);
	}
}

void getRectWHfromProjectedCorners(vector<Point2f> input, float& width, float& height)
{
	vector<double> len_edges;
	if (input.size() < 4)
	{
		return;
	}
	for (int i = 1; i < 4; i++)
	{
		float distsq = (input[i - 1].x - input[i].x) * (input[i - 1].x - input[i].x) + (input[i - 1].y - input[i].y) * (input[i - 1].y - input[i].y);
		len_edges.push_back(sqrtf(distsq));
	}
	len_edges.push_back(sqrtf((input[3].x - input[0].x) * (input[3].x - input[0].x) + (input[3].y - input[0].y) * (input[3].y - input[0].y)));
	float len_ac_longer = max(len_edges[0], len_edges[2]);
	float len_bd_longer = max(len_edges[1], len_edges[3]);
	float diff_ac = abs(len_edges[0] - len_edges[2]);
	float diff_bd = abs(len_edges[1] - len_edges[3]);
	width = (diff_bd / len_bd_longer + 1) * len_ac_longer;
	height = (diff_ac / len_ac_longer + 1) * len_bd_longer;
}

void haloCacl::initialSrc(int w, int h, int bpp, int channels, char* imgdata, int savePic, const char* debugPath, float exp, const char* luminFile, bool doCali) {

	int depth = CV_16U;
	if (bpp == 8)
	{
		depth = CV_8U;
	}
	if (bpp == 32)
	{
		depth = CV_32F;
	}

	int type = CV_MAKETYPE(depth, channels);

	srcM = cv::Mat(h, w, type, imgdata);	//ԭʼͼ

	/*if (channels == 1) {
		brightChannel = srcM;
	}
	else
	{
		Mat arr[3];
		split(srcM, arr);
		Scalar m = mean(srcM);
		if (m[0] > m[1]) {
			if (m[2] > m[0]) {
				brightChannel = arr[2];
			}
			else
			{
				brightChannel = arr[0];
			}
		}

		else
		{
			if (m[2] > m[1]) {
				brightChannel = arr[2];
			}
			else
			{
				brightChannel = arr[1];
			}
		}
	}*/
	if (depth == CV_8U)
	{
		drawImage = srcM.clone();
	}
	else
	{
		OpencvManager::MatToCImage(srcM, drawImage);

	}

	if (channels == 1)
	{
		cvtColor(drawImage, drawImage, COLOR_GRAY2BGR);
	}
	srcIsNull = false;
	this->savePic = savePic;
	this->path = string(debugPath);

	this->m_doCali = doCali;
	if (m_doCali)
	{
		m_exp[0] = m_exp[1] = m_exp[2] = exp;		//���ǲ�ɫ����˴������
		caliH = CreatCalibrationManage();
		int res = CM_SetCalibParam(caliH, CalibrationType::Luminance, true, luminFile);
		if (res != 1)
		{
			LOGE("read luminance file ERROR!");
		}
	}
}

vector<vector<cv::Point>>halo_allContours;		//���е�����
bool haloCacl::findEdge(cv::Mat& imgFromCut, int threadV, bool isAdaptive, int rect_w, int rect_h, vector<vector<cv::Point>>& haloContour) {

	if (imgFromCut.channels() == 3) {
		cvtColor(imgFromCut, imgFromCut, COLOR_BGR2GRAY);
	}
	Mat img8;
	Mat binaryImg;
	if (isAdaptive)
	{

		OpencvManager::MatToCImage(imgFromCut, img8);
		try
		{
			adaptiveThreshold(img8, binaryImg, 255, ADAPTIVE_THRESH_GAUSSIAN_C, THRESH_BINARY, 3, -5);
			if (savePic != 0)
			{
				imwrite(path + "_adaptiveThreshold.tif", binaryImg);
			}
		}
		catch (const std::exception&)
		{
			return false;
		}


		for (int i = 5; i < binaryImg.rows - 5; i++)
		{
			int whiteNum = 0;
			for (int j = 5; j < binaryImg.rows - 5; j++)
			{
				if (binaryImg.ptr<uchar>(j, i)[0] == 255)
				{
					whiteNum++;
				}
			}
			//float rate = (float)whiteNum / (float)binaryImg.cols;
			if ((float)whiteNum / (float)binaryImg.cols > 0.05)
			{
				line(binaryImg, Point(50, i), Point(binaryImg.cols - 50, i), Scalar(255));
			}
		}
		if (savePic != 0)
		{
			imwrite(path + "_adaptiveThreshold2.tif", binaryImg);
		}

	}
	else
	{
		cv::threshold(imgFromCut, imgFromCut, threadV/* cv::THRESH_OTSU*/, 65535, cv::THRESH_BINARY);
		OpencvManager::MatToCImage(imgFromCut, binaryImg);
	}

	if (savePic != 0)
	{
		cv::imwrite(path + "_threashold.tif", imgFromCut);
	}
	try
	{

		//Ѱ������
		cv::findContours(binaryImg, halo_allContours, cv::RETR_CCOMP, cv::CHAIN_APPROX_SIMPLE);
		if (halo_allContours.size() < 1)
		{
			cout << "fail to findContours\n";
			return false;
		}


		//ɸѡ����
		for (int i = 0; i < halo_allContours.size(); i++) {
			cv::Rect tempRect = cv::boundingRect(halo_allContours[i]);

			if (abs(float(tempRect.width - rect_w) / rect_w) < 0.2f && abs(float(tempRect.height - rect_h) / rect_h) < 0.2f)		//��������С��ԭʼ����бȽ�
			{
				haloContour.push_back(halo_allContours[i]);
			}
		}

		if (haloContour.size() == 0)
		{
			cout << "fail to find fix contours\n";
			return false;
		}
		//���ܻ�ɸѡ����������������������ȥ��1��
		if (haloContour.size() > 1) {
			if (cv::contourArea(haloContour[0]) < cv::contourArea(haloContour[1])) {
				haloContour.pop_back();
			}
			else {
				vector<vector<cv::Point>>::iterator first = haloContour.begin();
				haloContour.erase(first);
			}
		}
	}
	catch (const std::exception&)
	{
		return false;

	}

	return true;
}

float haloCacl::calculateHalo(int x, int y, int rect_w, int rect_h, int outMOVE, int threadV, int haloSize, const char* name, ushort* gray, uint& pixNum) {

	if (srcIsNull)
	{
		return -99;
	}
	string pathStr = this->path + string(name);
	int x_out = x - outMOVE, y_out = y - outMOVE, width_out = rect_w + 2 * outMOVE, height_out = rect_h + 2 * outMOVE;
	//��������ͨ��ץȡ
	cv::Mat imgFromCut = Mat(srcM, Rect(x_out, y_out, width_out, height_out)).clone();							//��ȡ��ͼƬ	
	cv::Mat originalMat = imgFromCut.clone();
	if (savePic != 0)
	{
		cv::imwrite(pathStr + ".tif", imgFromCut);
	}

	const int zeroRetract = 25;//����һ�����򣬽��ַ����ð�
	cv::Rect originalRect(outMOVE + zeroRetract, outMOVE + zeroRetract, rect_w - 2 * zeroRetract, rect_h - 2 * zeroRetract);	//ԭʼ��


	cv::rectangle(imgFromCut, originalRect, cv::Scalar::all(threadV), -1);//���ַ���������
	if (savePic != 0)
	{
		cv::imwrite(pathStr + "_setZero.tif", imgFromCut);
	}



	vector<vector<cv::Point>> haloContour;			//��������


	bool res = findEdge(imgFromCut, threadV, false, rect_w, rect_h, haloContour);
	if (!res)
	{
		res = findEdge(imgFromCut, threadV, true, rect_w, rect_h, haloContour);
	}
	if (!res)
	{
		line(drawImage, Point(x, y), Point(x + rect_w, y + rect_h), Scalar(0, 0, 60000), 4);
		line(drawImage, Point(x, y + rect_h), Point(x + rect_w, y), Scalar(0, 0, 60000), 4);
		return -99;
	}
	//������������һ��͹��
	vector<cv::Point>hullContours;
	cv::convexHull(haloContour[0], hullContours);
	vector<cv::Point>drawContour;
	drawContour = hullContours;
	for (int j = 0; j < hullContours.size(); j++)
	{
		drawContour[j].x += x_out;
		drawContour[j].y += y_out;
	}

	haloContour.clear();
	haloContour.push_back(drawContour);
	drawContours(drawImage, haloContour, -1, cv::Scalar(65535, 65535, 65535), 1);

	//
	int nummber = 0;			//���������Ĺ��ε�����
	uint64_t sumValue_0 = 0;		//�ۼƻҽ�ֵ
	uint64_t sumValue_1 = 1;
	uint64_t sumValue_2 = 2;
	vector<cv::Point>haloPoint;
	for (int r = 0; r < imgFromCut.rows; r++) {
		for (int c = 0; c < imgFromCut.cols; c++) {
			cv::Point p(c, r);
			if (!originalRect.contains(p)) {
				double distance = fabs(cv::pointPolygonTest(hullContours, p, true));
				int out = cv::pointPolygonTest(hullContours, p, false);//�������������λ�ù�ϵ

				if (distance <= haloSize && out == -1) {
					nummber++;
					sumValue_0 += originalMat.ptr<ushort>(r, c)[0];
					sumValue_1 += originalMat.ptr<ushort>(r, c)[1];
					sumValue_2 += originalMat.ptr<ushort>(r, c)[2];
					haloPoint.push_back(p);
				}
			}
		}
	}

	for (int i = 0; i < haloPoint.size(); i++)
	{
		drawImage.ptr<Vec3w>(haloPoint[i].y + y_out, haloPoint[i].x + x_out)[0] = { 100,200,100 };
	}
	pixNum = nummber;
	double averageValue = (double)sumValue_0 / nummber;		//ƽ���Ҷ�
	gray[0] = (ushort)averageValue;

	averageValue = (double)sumValue_1 / nummber;		//ƽ���Ҷ�
	gray[1] = (ushort)averageValue;

	averageValue = (double)sumValue_2 / nummber;		//ƽ���Ҷ�
	gray[2] = (ushort)averageValue;
	if (m_doCali)
	{
		BYTE* pSrcData = (BYTE*)&gray;
		BYTE pLum[4];
		CM_SCGD_SDP_Luminance(caliH, 1, 1, 16, 1, pSrcData, pLum, m_exp);
		float* pY = (float*)pLum;
		return *pY;
	}
	return 0;
}

vector < vector<cv::Point>>halo_vec_Key;
float haloCacl::calculateKey(int x, int y, int rect_w, int rect_h, int inMOVE, int threadV, const char* name, ushort* gray, uint& pixNum) {

	if (srcIsNull)
	{
		return -99;
	}
	string pathStr = path + string(name);
	int tempThread = threadV;
	if (tempThread>255)
	{
		tempThread /= 256;
	}

	Mat roi = Mat(srcM, Rect(x + inMOVE, y + inMOVE, rect_w - 2 * inMOVE, rect_h - 2 * inMOVE)).clone();
	Mat mask;
	if (roi.channels() == 3)
	{
		cvtColor(roi, mask, COLOR_BGR2GRAY);
	}
	else
	{
		mask = roi.clone();
	}
	if (mask.depth() != CV_8U)
	{
		mask.convertTo(mask, CV_8UC1, 1.0 / 255, 0);
		
	}

	cv::threshold(mask, mask, tempThread, 255, THRESH_BINARY);
	if (savePic != 0) {
		imwrite(pathStr + "_mask.tif", mask);
	}

	try
	{

		cv::findContours(mask, halo_vec_Key, cv::RETR_CCOMP, cv::CHAIN_APPROX_SIMPLE);
		if (!halo_vec_Key.empty())
		{
			int off_x = x + inMOVE;
			int off_y = y + inMOVE;
			for (int i = 0; i < halo_vec_Key.size(); i++)
			{
				for (int j = 0; j < halo_vec_Key[i].size(); j++)
				{
					halo_vec_Key[i][j].x += off_x;
					halo_vec_Key[i][j].y += off_y;
				}
			}
			drawContours(drawImage, halo_vec_Key, -1, cv::Scalar(0, 255, 255), 1);
		}
		if (savePic != 0) {
			imwrite(pathStr + "_Threshold.tif", mask);
		}

		pixNum = cv::countNonZero(mask);
		if (savePic != 0) {
			imwrite(pathStr + "_roi.tif", roi);
		}
		Scalar m = mean(roi, mask);
		gray[0] = (ushort)m[0];
		gray[1] = (ushort)m[1];
		gray[2] = (ushort)m[2];

		if (m_doCali)
		{
			BYTE* pSrcData = (BYTE*)&gray;
			BYTE pLum[4];
			CM_SCGD_SDP_Luminance(caliH, 1, 1, 16, 1, pSrcData, pLum, m_exp);
			float* pY = (float*)pLum;
			return *pY;
		}
		return 0;
	}
	catch (const std::exception&)
	{
		return -99;
	}

}

int haloCacl::getHaloResult(int& w, int& h, int& bpp, int& channels, char* pData) {
	if (srcIsNull)
	{
		return 0;
	}
	w = drawImage.cols;
	h = drawImage.rows;
	if (drawImage.depth() == CV_8U)
	{
		bpp = 8;
	}
	else
	{
		bpp = 16;
	}
	channels = drawImage.channels();
	memcpy(pData, drawImage.data, w * h * 3);
	return 1;
}



ledCheck_qk::ledCheck_qk() :
	success(false),
	m_referenceRadius(0)
{
}
int ledCheck_qk::findLedPosition(int w, int h, int bpp, int channels, uchar* data, int ledNum_x, int ledNum_y, int threadV, int* cornerX, int* cornerY) {
	int depth = CV_16U;
	if (bpp == 8)
	{
		depth = CV_8U;
	}
	int type = CV_MAKE_TYPE(depth, channels);
	Mat src(h, w, type, data);

	if (depth == CV_16U)
	{
		cv::Mat  tmp;
		cv::Mat m8 = cv::Mat::zeros(src.size(), CV_8U);
		normalize(src, tmp, 0, 255, cv::NORM_MINMAX);
		convertScaleAbs(tmp, matDraw);
		src = matDraw.clone();
	}
	Scalar scalarDrawLed(0, 215, 255);
	Scalar scalarDrawBad(0, 0, 255);
	Mat channelMat = src;
	if (channels == 3)
	{
		Mat arr[3];
		split(src, arr);
		int meanGray[3];
		meanGray[0] = mean(arr[0])[0];
		meanGray[1] = mean(arr[1])[0];
		meanGray[2] = mean(arr[2])[0];
		int max = 0;
		int index = 0;
		for (int i = 0; i < 3; i++) {
			if (meanGray[i] > max)
			{
				max = meanGray[i];
				index = i;
			}
		}
		if (max == 0)
		{
			return -1;
		}
		channelMat = arr[index];
	}

	int tThosld = threadV;
	if (tThosld > 256)
	{
		tThosld /= 256;
	}
	if (tThosld < 15)
	{
		tThosld = 15;
	}

	cv::threshold(channelMat, channelMat, tThosld, 255, cv::THRESH_BINARY);

	//imwrite("TIFF\\binaryMat.tif", channelMat);
	vector<vector<cv::Point>>allContours;		//���е�����
	cv::findContours(channelMat, allContours, cv::RETR_LIST, cv::CHAIN_APPROX_SIMPLE);
	if (allContours.size() < ledNum_x * ledNum_y * 0.5)
	{
		success = false;
		LOGE("the contours nummber is too less!");
		return -1;
	}

	drawContours(matDraw, allContours, -1, scalarDrawLed, 1);

	int sampleNum = 10;
	int insertD = allContours.size() / sampleNum;
	int averageR = 0;
	sampleNum = 0;
	vec_ledCenters.clear();
	for (int i = 0; i < allContours.size(); i++)
	{
		Moments m = moments(allContours[i]);
		int px = m.m10 / m.m00;
		int py = m.m01 / m.m00;
		if (px > 0)
		{
			vec_ledCenters.push_back(Point(px, py));
			if (i % insertD == 0)
			{
				Point2f tPoint;
				float r = 0;
				minEnclosingCircle(allContours[i], tPoint, r);
				averageR += (int)r;
				sampleNum++;
			}
		}
		else
		{
			cv::RotatedRect outRect = cv::minAreaRect(allContours[i]);
			px = outRect.center.x;
			py = outRect.center.y;
			if (px > 10 && py > 10 && px < w - 10 && py < h - 10)
			{
				vec_ledCenters.push_back(Point(px, py));
			}

		}


		//	circle(matDraw, Point(m.m10 / m.m00, m.m01 / m.m00), 1, Scalar(0, 255, 0),-1);
	}
	averageR /= sampleNum;
	m_referenceRadius = averageR;
	//cout << "averageR:" << averageR << endl;
	reverse(vec_ledCenters.begin(), vec_ledCenters.end());
	//for (int i = 0; i < allContours.size()/*/3*/; i++)
	//{
	//	cout << vec_ledCenters[i] << endl;
	//	circle(matDraw, vec_ledCenters[i], 2, Scalar(0, 0, 255), -1);
	//}


	int brightRectW = (cornerX[1] - cornerX[0] + cornerX[2] - cornerX[3]) / 2;
	int brightRectH = (cornerY[3] - cornerY[0] + cornerY[2] - cornerY[1]) / 2;
	int ym = (abs(cornerY[1] - cornerY[0]) + abs(cornerY[2] - cornerY[3])) / 2;
	int xm = (abs(cornerX[3] - cornerX[0]) + abs(cornerX[2] - cornerX[1])) / 2;
	brightRectW = sqrt(brightRectW * brightRectW + ym * ym);
	brightRectH = sqrt(brightRectH * brightRectH + xm * xm);


	int ledDistanceX = brightRectW / (ledNum_x - 1);
	int ledDistanceY = brightRectH / (ledNum_y - 1);
	int rectOffsetX = ledDistanceX * 0.4;
	int rectOffsetY = ledDistanceY * 0.4;
	int rectNumX = brightRectW / rectOffsetX;
	int rectNumY = brightRectH / rectOffsetY;
	Point* pRectDetectCAD = new Point[rectNumX * rectNumY];
	int index = 0;
	int startX = 0, startY = 0;
	for (int i = 0; i < rectNumY; i++)
	{
		startX = 0;
		for (int j = 0; j < rectNumX; j++)
		{
			pRectDetectCAD[index].x = startX;
			pRectDetectCAD[index].y = startY;
			startX += rectOffsetX;
			index++;
		}
		startY += rectOffsetY;
	}


	vector<cv::Point> mapFourPoint;			//map��4���ǵ�
	mapFourPoint.push_back(Point(0, 0));
	mapFourPoint.push_back(Point(brightRectW, 0));
	mapFourPoint.push_back(Point(brightRectW, brightRectH));
	mapFourPoint.push_back(Point(0, brightRectH));

	vector<cv::Point>imageFourPoint;			//image��4���ǵ�
	for (int i = 0; i < 4; i++) {
		cv::Point temp(Point(cornerX[i], cornerY[i]));
		imageFourPoint.push_back(temp);
	}

	Mat	mappingMatrix = cv::findHomography(mapFourPoint, imageFourPoint);
	Mat inverseMatrix;
	double det = cv::invert(mappingMatrix, inverseMatrix, cv::DECOMP_LU);



	cv::Point3d transformedCorner;

	for (int i = 0; i < rectNumX * rectNumY; i++)
	{
		transformedCorner = cv::Point3d(cv::Mat(mappingMatrix * cv::Mat(cv::Point3d(pRectDetectCAD[i].x, pRectDetectCAD[i].y, 1.0))));
		pRectDetectCAD[i] = cv::Point2f(transformedCorner.x / transformedCorner.z, transformedCorner.y / transformedCorner.z);
	}
	/*for (int i=0;i<4;i++)
	{
		transformedCorner = cv::Point3d(cv::Mat(inverseMatrix * cv::Mat(cv::Point3d(imageFourPoint[i].x, imageFourPoint[i].y, 1.0))));
		Point tp = cv::Point2f(transformedCorner.x / transformedCorner.z, transformedCorner.y / transformedCorner.z);
		int wait = 0;
	}*/
	vector<cv::Point>vec_CadLedCenters;
	for (int i = 0; i < vec_ledCenters.size(); i++)
	{
		transformedCorner = cv::Point3d(cv::Mat(inverseMatrix * cv::Mat(cv::Point3d(vec_ledCenters[i].x, vec_ledCenters[i].y, 1.0))));
		Point tp = cv::Point2f(transformedCorner.x / transformedCorner.z, transformedCorner.y / transformedCorner.z);
		vec_CadLedCenters.push_back(tp);
		//circle(matDraw, tp, 3, Scalar(0, 255, 0),-1);
	}




	Mat rectMat;
	int rectW = ledDistanceX * 0.8;
	int rectH = ledDistanceY * 0.8;
	int pToLeft = rectW / 2;
	int pToTop = rectH / 2;
	vec_badPoints.clear();
	for (int i = 0; i < rectNumX * rectNumY; i++)
	{
		rectMat = Mat(channelMat, Rect(pRectDetectCAD[i].x - pToLeft, pRectDetectCAD[i].y - pToTop, rectW, rectH));

		if (mean(rectMat)[0] == 0) {
			int arigalX = pRectDetectCAD[i].x - pToLeft;
			int arigalY = pRectDetectCAD[i].y - pToTop;
			Rect tempRect(arigalX, arigalY, rectW, rectH);
			int offsetNum = 0;
			while (offsetNum < ledDistanceX / 2)
			{
				tempRect.x -= 2;
				Mat tmpMat = Mat(channelMat, tempRect);
				if (mean(tmpMat)[0] > 0)
				{
					pRectDetectCAD[i].x -= (offsetNum * 2 + pToLeft + averageR - ledDistanceX);
					break;
				}
				offsetNum++;
			}

			tempRect = Rect(arigalX, arigalY, rectW, rectH);
			offsetNum = 0;
			while (offsetNum < ledDistanceY / 2)
			{
				tempRect.y -= 2;
				Mat tmpMat = Mat(channelMat, tempRect);
				if (mean(tmpMat)[0] > 0)
				{
					pRectDetectCAD[i].y -= (offsetNum * 2 + pToTop + averageR - ledDistanceY);
					break;
				}
				offsetNum++;
			}
			vec_badPoints.push_back(pRectDetectCAD[i]);
			circle(channelMat, pRectDetectCAD[i], averageR, Scalar(255, 255, 255), -1);		//����
			//circle(matDraw, pRectDetectCAD[i], averageR, Scalar(255, 255, 255), -1);
			line(matDraw, Point(pRectDetectCAD[i].x - ledDistanceX / 2, pRectDetectCAD[i].y - ledDistanceY / 2), Point(pRectDetectCAD[i].x + ledDistanceX / 2, pRectDetectCAD[i].y + ledDistanceY / 2), scalarDrawBad, 1);
			line(matDraw, Point(pRectDetectCAD[i].x - ledDistanceX / 2, pRectDetectCAD[i].y + ledDistanceY / 2), Point(pRectDetectCAD[i].x + ledDistanceX / 2, pRectDetectCAD[i].y - ledDistanceY / 2), scalarDrawBad, 1);
		}
	}
	success = true;
	delete[]pRectDetectCAD;
	if (vec_CadLedCenters.size() == ledNum_x * ledNum_y)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

int ledCheck_qk::getLedCenterNum() {
	if (!success || vec_ledCenters.size() < 1)
	{
		return -1;
	}
	return vec_ledCenters.size();
}

int ledCheck_qk::getBadPointNum() {
	if (!success || vec_badPoints.size() < 1)
	{
		return -1;
	}
	return vec_badPoints.size();
}

int ledCheck_qk::getLedCenterPositions(PointInt* pArr, int& referenceRadius) {
	if (!success)
	{
		LOGE("never find LED success!");
		return FALSE;
	}
	for (int i = 0; i < vec_ledCenters.size(); i++)
	{
		pArr[i].x = vec_ledCenters[i].x;
		pArr[i].y = vec_ledCenters[i].y;
	}
	referenceRadius = m_referenceRadius;
	return TRUE;
}

int ledCheck_qk::getBadPositions(PointInt* pArr) {
	if (!success)
	{
		LOGE("never find LED success!");
		return FALSE;
	}
	for (int i = 0; i < vec_badPoints.size(); i++)
	{
		pArr[i].x = vec_badPoints[i].x;
		pArr[i].y = vec_badPoints[i].y;
	}
	return TRUE;
}

int ledCheck_qk::getDrawImg(int& w, int& h, int& bpp, int& channels, uchar* data) {
	if (!success)
	{
		LOGE("never find LED success!");
		return FALSE;
	}
	w = matDraw.cols;
	h = matDraw.rows;
	bpp = 8;
	channels = matDraw.channels();
	memcpy(data, matDraw.data, w * h * channels);
	return TRUE;
}

int ledCheck_qk::findHighIndensityLed(int w, int h, int bpp, int channels, char* imgdata, CVLED_COLOR color, const char* cfg_json, const char* positionFn, int& col, int& row, float& x_interval, float& y_interval, float& angle, double* pX, double* pY) {
	int srcType = CV_MAKE_TYPE(CV_16U, channels);
	if (bpp == 32) {
		srcType = CV_MAKE_TYPE(CV_32F, channels);
	}
	int res = findDotsArrayLowPitchMemPtsMemReturnMemImp(w, h, (uint8_t*)imgdata, srcType, color, cfg_json, col, row, x_interval, y_interval, angle, pX, pY);
	if (res != 0) {
		LOGE("Failed to findDotsArrayLowPitchMemPtsMemReturnMemImp");
		return FALSE;
	}
	return TRUE;
}
ledCheck_qk::~ledCheck_qk()
{
}

Ghost::Ghost() :
	isDebug(false)
{

}

Ghost::~Ghost() {
	if (bIngnore != nullptr)
	{
		delete[]bIngnore;
	}
}

void Ghost::enableDebug(bool e, const char* Path) {
	isDebug = e;
	debugPath = string(Path);
}

void  Ghost::initialMat(int w, int h, int bpp, int channel, uchar* data) {
	int depth = CV_16U;
	if (bpp == 32) {
		depth = CV_32F;
	}

	if (bpp == 8) {
		depth = CV_8U;
	}

	int type = CV_MAKE_TYPE(depth, channel);
	mat_src = Mat(h, w, type, data);
	if (!mat_src.empty()) {
		_w = w;
		_h = h;
		_bpp = bpp;
		_channel = channel;
	}

	//revertDrawMat();
}

void  Ghost::initialMat(string fn) {
	mat_src = imread(fn, IMREAD_UNCHANGED);
	if (!mat_src.empty()) {
		_w = mat_src.cols;
		_h = mat_src.rows;
		_bpp = 16;
		if (mat_src.depth() == CV_8U) {
			_bpp = 8;
		}
		_channel = mat_src.channels();
	}

	//revertDrawMat();
}

int Ghost::loadXyz(uchar* pXyz, int index) {
	if (mat_src.empty()) {
		//log
		return 0;
	}
	//int index = 0;
	if (_channel == 3) {
		index *= _w * _h * 4;
	}
	mat_XYZ = Mat(_h, _w, CV_32FC1, pXyz + index);
	return 1;
}

int Ghost::loadXyz(string fn) {
	mat_XYZ = imread(fn, IMREAD_UNCHANGED);
	if (mat_XYZ.depth() != CV_32F) {
		mat_XYZ = Mat::zeros(Size(0, 0), 0);
		return 0;
	}
	return 1;
}

int Ghost::findBright(int thresholdMin, int thresholdMax, int thresholdStep, int brightNumX, int brightNumY, Pattern patternType, int outRectSizeMin, float outRectSizeRate, int erodeKernel) {

	Mat binaryMatSrc;
	if (_channel == 3) {
		cvtColor(mat_src, binaryMatSrc, cv::COLOR_BGR2GRAY);
	}
	else
	{
		binaryMatSrc = mat_src.clone();
	}
	Mat tBinaryMat;
	int maxValue = 65535;

	if (_bpp == 8)
	{
		maxValue = 255;
	}

	bool isSuccess = false;
	for (int i = thresholdMin; i < thresholdMax + 1; i += thresholdStep)
	{
		cv::threshold(binaryMatSrc, tBinaryMat, i, maxValue, cv::THRESH_BINARY);
		if (_bpp == 16)
		{
			tBinaryMat = convertTo8bit(tBinaryMat);
		}

		if (erodeKernel > 1 && erodeKernel < 6) {
			Mat kernel = cv::getStructuringElement(0, cv::Size(erodeKernel, erodeKernel));
			erode(tBinaryMat, tBinaryMat, kernel);

		}

		findContours(tBinaryMat, vec_contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

		isSuccess = isCorrectBright(vec_contours, vec_contoursBright, brightNumX * brightNumY, outRectSizeMin, outRectSizeRate);

		if (isSuccess) {
			threshold_bright = i;
			break;
		}
	}
	if (!isSuccess) {
		//log
		return 0;
	}
	_brightNumX = brightNumX;
	_brightNumY = brightNumY;
	squeenLocation(vec_contoursBright, _brightNumX, _brightNumY, patternType, false);
	return 1;
}

int Ghost::findGhost(int thresholdMin, int thresholdMax, int thresholdStep, int outRectSizeMin, float outRectSizeRate
	, int minGray, float grayRate, int erodeKernel, int erodeTime, int pixDistance) {
	Mat binaryMatSrc;
	if (_channel == 3) {
		cvtColor(mat_src, binaryMatSrc, cv::COLOR_BGR2GRAY);
	}
	else
	{
		binaryMatSrc = mat_src.clone();
	}
	Mat tBinaryMat;
	int maxValue = 65535;

	if (_bpp == 8)
	{
		maxValue = 255;
	}


	drawContours(binaryMatSrc, vec_contoursBright, -1, Scalar(0), FILLED);
	if (isDebug) {
		imwrite(debugPath + "eraserBright.tif", binaryMatSrc);
	}

	bool isSuccess = false;
	for (int i = thresholdMin; i < thresholdMax + 1; i += thresholdStep)
	{
		cv::threshold(binaryMatSrc, tBinaryMat, i, maxValue, cv::THRESH_BINARY);

		if (_bpp == 16)
		{
			tBinaryMat = convertTo8bit(tBinaryMat);
		}


		if (erodeKernel > 0 && erodeKernel <= 5) {
			Mat kernel = cv::getStructuringElement(0, cv::Size(erodeKernel, erodeKernel));
			while (erodeTime > 0)
			{
				erode(tBinaryMat, tBinaryMat, kernel);
				erodeTime--;
			}

		}

		findContours(tBinaryMat, vec_contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
		isSuccess = isCorrectGhost(vec_contours, vec_contoursGhost, outRectSizeMin, outRectSizeRate, minGray, grayRate);
		if (isSuccess)
		{
			if (isDebug)
			{
				//imwrite(debugPath + "binaryMatSrc.tif", tBinaryMat);
				imwrite(debugPath + "binaryGhost.tif", tBinaryMat);
			}
			threshold_ghost = i;
			autoGain();
			break;
		}
	}

	if (!isSuccess) {
		return 0;
	}
	/*int brightNum = _brightNumX * _brightNumY;*/
	filtGhost(vec_contoursGhost, pixDistance);
	squeenLocation(vec_contoursGhost, _brightNumX, _brightNumY, Pattern::matrix, true);
	return 1;
}

Mat Ghost::getDrawMat() {
	revertDrawMat();
	drawContours(mat_draw, vec_contoursGhost, -1, Scalar(0, 0, 255), 1);
	drawContours(mat_draw, vec_contoursBright, -1, Scalar(0, 255, 0), 2);
	return mat_draw;
}

int Ghost::getDrawMat(int& w, int& h, int& bpp, int& channel, uchar* data) {
	revertDrawMat();
	if (bpp / 8 * w * h * channel < mat_draw.cols * mat_draw.rows * mat_draw.channels()) {
		w = mat_draw.cols;
		h = mat_draw.rows;
		bpp = 8;
		channel = 3;
		return 0;
	}
	w = mat_draw.cols;
	h = mat_draw.rows;
	bpp = 8;
	channel = 3;
	drawContours(mat_draw, vec_contoursGhost, -1, Scalar(0, 0, 255), 1);
	drawContours(mat_draw, vec_contoursBright, -1, Scalar(0, 255, 0), 2);
	memcpy(data, mat_draw.data, w * h * channel);
	return 1;
}

bool Ghost::getContoursCenter(const vector < vector<cv::Point>>& source, PointInt* p, int& length) {
	if (length < source.size()) {
		//log
		length = source.size();
		return 0;
	}

	length = source.size();
	for (int i = 0; i < source.size(); i++)
	{
		Moments mom;
		mom = moments(source[i]);
		p[i].x = cvRound(mom.m10 / mom.m00);
		p[i].y = cvRound(mom.m01 / mom.m00);
	}
	return 1;
}

int Ghost::getBrightPointsCenter(PointInt* p, int& length) {
	if (getContoursCenter(vec_contoursBright, p, length))
	{
		return 1;
	}

	return 0;
}

int Ghost::getGhostPointsCenter(PointInt* p, int& length) {
	if (getContoursCenter(vec_contoursGhost, p, length))
	{
		return 1;
	}

	return 0;
}

bool Ghost::calcContoursInY(vector < vector<cv::Point>>& vp, float* pY, int& length, string tifName) {
	vector<Point>vec_offset;
	for (int i = 0; i < vec_contoursOutRect.size(); i++) {
		//imwrite("mat_XYZ.tif", mat_XYZ);
		Mat rectM = Mat(mat_XYZ, vec_contoursOutRect[i]);
		Mat mask = Mat::zeros(rectM.size(), CV_8UC1);
		offsetLocation(vp[i], vec_offset, vec_contoursOutRect[i]);
		vector<vector<Point>>dv;
		dv.push_back(vec_offset);
		drawContours(mask, dv, -1, Scalar(255), FILLED);
		if (isDebug)
		{
			imwrite(debugPath + to_string(i) + tifName, mask);
		}
		/*imwrite("rectM.tif", rectM);
		imwrite("TIFF\\mask.tif", mask);*/
		Scalar mean_val = mean(rectM, mask);
		pY[i] = (float)mean_val[0];
	}
	length = vec_contoursOutRect.size();
	return true;
}

int Ghost::getBrightAverageY(float* pY, int& length) {
	if (!calcOutRects(vec_contoursBright))
	{
		//log
		return 0;
	}
	if (length < vec_contoursOutRect.size()) {
		length = vec_contoursOutRect.size();
		return 0;
	}
	calcContoursInY(vec_contoursBright, pY, length, "bright.tif");

	return 1;
}

int Ghost::getGhostAverageY(float* pY, int& length) {
	if (!calcOutRects(vec_contoursGhost))
	{
		//log
		return 0;
	}
	if (length < vec_contoursOutRect.size()) {
		length = vec_contoursOutRect.size();
		return 0;
	}
	calcContoursInY(vec_contoursGhost, pY, length, "ghost.tif");
	return 1;
}

int Ghost::enableCheckCloseBright(bool* bArr, int& len) {
	if (len < vec_contoursBright.size())
	{
		len = vec_contoursBright.size();
		return 0;
	}
	len = vec_contoursBright.size();
	if (bIngnore != nullptr)
	{
		delete[]bIngnore;
	}
	bIngnore = new bool[len];
	for (int i = 0; i < len; i++)
	{
		bIngnore[i] = bArr[i];
	}
	return 1;
}

bool Ghost::isCorrectBright(vector < vector<cv::Point>>& source, vector < vector<cv::Point>>& dst, int brightNumber, int outRectSizeMin, float outRectSizeRate) {
	dst.clear();
	for (int i = 0; i < source.size(); i++) {
		cv::RotatedRect outRect;
		outRect = cv::minAreaRect(source[i]);
		if (outRect.size.width > outRectSizeMin && outRect.size.width < outRectSizeMin * outRectSizeRate
			&& outRect.size.height > outRectSizeMin && outRect.size.height < outRectSizeMin * outRectSizeRate)
		{
			dst.push_back(source[i]);
		}
	}

	if (dst.size() == brightNumber) {
		return true;
	}
	if (dst.size() < brightNumber) {
		//log
		return false;
	}

	else
	{
		int* averageGray = new int[dst.size()];
		for (int i = 0; i < dst.size(); i++)
		{
			//������ƽ���Ҷ�
			Rect r = boundingRect(dst[i]);
			Mat rectM = Mat(mat_src, r);
			Scalar m = mean(rectM);
			averageGray[i] = (m[0] + m[1] + m[2]) / 3;
		}
		int* indexMaxToMin = new int[dst.size()];

		for (int i = 0; i < dst.size(); i++)
		{
			indexMaxToMin[i] = i;
		}

		for (int i = 1; i < dst.size(); i++)
		{
			//���򣬻�ȡǰN��
			for (int j = i; j > 0; j--)
			{
				if (averageGray[j] > averageGray[j - 1]) {
					int t = indexMaxToMin[j];
					indexMaxToMin[j] = indexMaxToMin[j - 1];
					indexMaxToMin[j - 1] = t;
				}
			}
		}
		vector < vector<cv::Point>>tVec;

		for (int i = 0; i < brightNumber; i++)
		{
			tVec.push_back(dst[indexMaxToMin[i]]);
		}

		dst.clear();
		dst = tVec;
		delete[]averageGray;
		delete[]indexMaxToMin;
		return true;
	}
}

bool Ghost::isCorrectGhost(vector <vector<cv::Point>>& source, vector <vector<cv::Point>>& dst, int outRectSizeMin, float outRectSizeRate, int minGray, float grayRate) {
	dst.clear();
	for (int i = 0; i < source.size(); i++) {
		cv::RotatedRect outRect;
		outRect = cv::minAreaRect(source[i]);
		if (outRect.size.width > outRectSizeMin && outRect.size.width < outRectSizeMin * outRectSizeRate
			&& outRect.size.height > outRectSizeMin && outRect.size.height < outRectSizeMin * outRectSizeRate)
		{
			dst.push_back(source[i]);
		}
	}
	if (dst.size() < 1) {
		return false;
	}

	return true;
}

bool Ghost::filtGhost(vector <vector<cv::Point>>& source, int pixDistant) {

	int tl = vec_contoursBright.size();
	PointInt* pCenterBright = new PointInt[vec_contoursBright.size()];
	getContoursCenter(vec_contoursBright, pCenterBright, tl);

	PointInt* pCenterGhost = new PointInt[source.size()];
	int lGhostLength = source.size();
	getContoursCenter(source, pCenterGhost, lGhostLength);

	vector <vector<cv::Point>>tV;
	for (int i = 0; i < lGhostLength; i++)
	{
		if (bIngnore == nullptr)
		{
			break;
		}
		bool isG = true;
		for (int j = 0;j < tl;j++)
		{
			if (pCenterGhost[i].getDistance(pCenterBright[j]) < pixDistant && !bIngnore[j])
			{
				isG = false;
				break;
			}
		}
		if (isG)
		{
			tV.push_back(source[i]);
		}
	}
	source = tV;
	delete[]pCenterBright;
	delete[]pCenterGhost;
	return true;
}

Mat Ghost::convertTo8bit(const Mat& src) {
	if (src.depth() == CV_16U)
	{

		cv::Mat  tmp;
		cv::Mat m8 = cv::Mat::zeros(src.size(), CV_8U);
		normalize(src, tmp, 0, 255, cv::NORM_MINMAX);
		convertScaleAbs(tmp, m8);
		return m8;
	}
	Mat t = src.clone();
	return t;
}

void Ghost::setDrawMatGain(float minRate, float maxRate) {

	_b = minRate;
	float base = 65535;
	if (_bpp == 8) {
		base = 255;
	}
	_k = (maxRate - minRate) / base;
}

void Ghost::compressImgData(int w, int h, int bpp, int channel, uchar* d) {
	if (bpp == 16)
	{
		ushort rela[65536];
		for (int i = 0; i < 65536; i++)
		{
			ushort g = (_k * i + _b) * i;
			if (g > 65535)
			{
				g = 65535;
			}
			rela[i] = g;
		}
		ushort* td = (ushort*)d;
		for (int i = 0; i < w * h * channel; i++)
		{
			td[i] = rela[td[i]];
		}
	}
	else
	{
		uchar rela[256];
		for (int i = 0; i < 256; i++)
		{
			ushort g = (_k * i + _b) * i;
			if (g > 255)
			{
				g = 255;
			}
			rela[i] = g;
		}

		for (int i = 0; i < w * h * channel; i++)
		{
			d[i] = rela[d[i]];
		}
	}
}

bool Ghost::revertDrawMat() {
	if (mat_src.empty()) {
		//log
		return false;
	}
	uchar* td = new uchar[_bpp / 8 * _w * _h * _channel];
	memcpy(td, mat_src.data, _bpp / 8 * _w * _h * _channel);

	mat_draw = Mat(_h, _w, getSrcType(), td);
	//Mat tm = mat_src.clone();
	compressImgData(_w, _h, _bpp, _channel, td);


	if (_bpp == 16) {
		mat_draw = convertTo8bit(mat_draw);
	}
	else
	{
		//mat_draw = tm.clone();
	}

	if (_channel == 1) {
		cvtColor(mat_draw, mat_draw, COLOR_GRAY2BGR);
	}
	return true;
}

bool Ghost::calcOutRects(const vector < vector<cv::Point>>& vp) {
	if (vp.size() < 1) {
		//log
		return false;
	}
	vec_contoursOutRect.clear();
	for (int i = 0; i < vp.size(); i++)
	{
		vec_contoursOutRect.push_back(boundingRect(vp[i]));
	}
	return true;
}

void Ghost::offsetLocation(const vector<cv::Point>& src, vector<cv::Point>& dst, Rect r) {
	if (src.size() < 1)
	{
		return;
	}
	dst.clear();

	for (int i = 0; i < src.size(); i++)
	{
		Point tp;
		tp.x = src[i].x - r.x;
		tp.y = src[i].y - r.y;
		dst.push_back(tp);
	}
}


void Ghost::squeenLocation(vector <vector<cv::Point>>& source, int cols, int rows, Pattern patternType, bool isGhost) {

	PointInt* pCenter = new PointInt[source.size()];
	int pLength = source.size();
	if (pLength < cols * rows) {
		return;
	}
	if (isGhost) {
		pFfreshCenter = std::bind(&Ghost::getGhostPointsCenter, this, std::placeholders::_1, std::placeholders::_2);
	}
	else
	{
		pFfreshCenter = std::bind(&Ghost::getBrightPointsCenter, this, std::placeholders::_1, std::placeholders::_2);

	}
	pFfreshCenter(pCenter, pLength);
	/*PointInt tp[9];*/
	//getBrightPointsCenter(tp, pLength);

	for (int i = 0; i < source.size(); i++)
	{
		for (int j = 0; j < source.size() - i - 1; j++)
		{
			if (pCenter[j].y > pCenter[j + 1].y) {

				auto v = source[j];
				source[j] = source[j + 1];
				source[j + 1] = v;
				pFfreshCenter(pCenter, pLength);
			}
		}
	}

	int start = 0;

	while (start < rows * cols)
	{
		for (int i = start;i < start + cols;i++)
		{
			for (int j = start; j < start + cols - 1; j++)
			{
				if (pCenter[j].x > pCenter[j + 1].x) {

					auto v = source[j];
					source[j] = source[j + 1];
					source[j + 1] = v;
					pFfreshCenter(pCenter, pLength);
				}
			}
		}
		start += cols;
	}

	//getBrightPointsCenter(pCenter, pLength);

	/*pFfreshCenter(tp, pLength);*/

	delete[]pCenter;
}

int Ghost::getSrcType() {
	int d = CV_8U;
	if (_bpp == 16)
	{
		d = CV_16U;
	}
	if (_bpp == 32)
	{
		d = CV_32F;
	}
	return CV_MAKE_TYPE(d, _channel);
}

void Ghost::autoGain() {
	int base = 65535;
	if (_bpp == 8)
	{
		base = 255;
	}
	float minGain = base * 0.28 / threshold_ghost;
	setDrawMatGain(minGain, 0.85);

}
